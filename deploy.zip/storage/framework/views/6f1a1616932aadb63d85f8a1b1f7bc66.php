<?php if (isset($component)) { $__componentOriginal9ac128a9029c0e4701924bd2d73d7f54 = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginal9ac128a9029c0e4701924bd2d73d7f54 = $attributes; } ?>
<?php $component = App\View\Components\AppLayout::resolve([] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('app-layout'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\App\View\Components\AppLayout::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes([]); ?>
<?php \Livewire\Features\SupportCompiledWireKeys\SupportCompiledWireKeys::processComponentKey($component); ?>

     <?php $__env->slot('header', null, []); ?> 
        <nav class="breadcrumbs">
            <a href="<?php echo e(route('admin.dashboard')); ?>">Administración</a>
            <span class="breadcrumb-sep">&rsaquo;</span>
            <span><?php echo e($modo === 'reclutamiento' ? 'Vacantes' : 'Servicios solicitados'); ?></span>
        </nav>
        <div class="toolbar-wrap" style="align-items:flex-start; gap:16px;">
            <div>
                <h1 class="page-title"><?php echo e($modo === 'reclutamiento' ? 'Vacantes y reclutamiento' : 'Servicios solicitados'); ?></h1>
                <p class="page-subtitle">
                    <?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if BLOCK]><![endif]--><?php endif; ?><?php if($modo === 'reclutamiento'): ?>
                        Solicitudes de contratación de personal. Los candidatos se postulan y se gestionan desde aquí.
                    <?php else: ?>
                        Capacitaciones, coaching, consultoría y otros servicios que requieren asignación a un interno.
                    <?php endif; ?><?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if ENDBLOCK]><![endif]--><?php endif; ?>
                </p>
            </div>
            <a href="<?php echo e(route('admin.vacantes.crear')); ?>" class="btn btn-primary">+ Nueva solicitud</a>
        </div>
     <?php $__env->endSlot(); ?>

    <?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if BLOCK]><![endif]--><?php endif; ?><?php if(session('success')): ?>
        <div class="alert alert-success mb-4"><?php echo e(session('success')); ?></div>
    <?php endif; ?><?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if ENDBLOCK]><![endif]--><?php endif; ?>
    <?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if BLOCK]><![endif]--><?php endif; ?><?php if(session('error')): ?>
        <div class="alert alert-danger mb-4"><?php echo e(session('error')); ?></div>
    <?php endif; ?><?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if ENDBLOCK]><![endif]--><?php endif; ?>

    <div class="toolbar-wrap" style="margin-bottom:20px; border-bottom:2px solid var(--border); padding-bottom:8px;">
        <a href="<?php echo e(route('admin.vacantes', ['modo' => 'reclutamiento'])); ?>"
           style="padding:10px 20px; border-radius:8px 8px 0 0; font-size:14px; font-weight:600; text-decoration:none;
                  background:<?php echo e($modo === 'reclutamiento' ? 'var(--accent)' : 'transparent'); ?>;
                  color:<?php echo e($modo === 'reclutamiento' ? '#fff' : 'var(--text-muted)'); ?>;
                  border-bottom:<?php echo e($modo === 'reclutamiento' ? '3px solid var(--accent)' : 'none'); ?>;">
            Vacantes
            <?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if BLOCK]><![endif]--><?php endif; ?><?php if($statsReclutamiento['pendientes'] > 0): ?>
                <span style="margin-left:6px; background:rgba(255,255,255,0.3); color:#fff; border-radius:20px; padding:1px 7px; font-size:11px;"><?php echo e($statsReclutamiento['pendientes']); ?></span>
            <?php endif; ?><?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if ENDBLOCK]><![endif]--><?php endif; ?>
        </a>
        <a href="<?php echo e(route('admin.vacantes', ['modo' => 'servicios'])); ?>"
           style="padding:10px 20px; border-radius:8px 8px 0 0; font-size:14px; font-weight:600; text-decoration:none;
                  background:<?php echo e($modo === 'servicios' ? 'var(--accent)' : 'transparent'); ?>;
                  color:<?php echo e($modo === 'servicios' ? '#fff' : 'var(--text-muted)'); ?>;
                  border-bottom:<?php echo e($modo === 'servicios' ? '3px solid var(--accent)' : 'none'); ?>;">
            Servicios solicitados
            <?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if BLOCK]><![endif]--><?php endif; ?><?php if($statsServicios['pendientes'] > 0): ?>
                <span style="margin-left:6px; background:rgba(255,255,255,0.3); color:#fff; border-radius:20px; padding:1px 7px; font-size:11px;"><?php echo e($statsServicios['pendientes']); ?></span>
            <?php endif; ?><?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if ENDBLOCK]><![endif]--><?php endif; ?>
        </a>
        <div class="toolbar-end">
            <a href="<?php echo e(route('admin.tareas.kanban')); ?>" class="btn btn-secondary" style="font-size:13px;">Ir al Kanban</a>
        </div>
    </div>

    <?php
        $estadoActual = request('estado', '');
    ?>

    <div class="toolbar-wrap" style="margin-bottom:18px;">
        <a href="<?php echo e(route('admin.vacantes', ['modo' => $modo])); ?>"
           style="padding:6px 14px; border-radius:6px; font-size:13px; font-weight:500; text-decoration:none;
                  background:<?php echo e($estadoActual === '' ? 'var(--surface-2)' : 'transparent'); ?>;
                  color:<?php echo e($estadoActual === '' ? 'var(--text)' : 'var(--text-muted)'); ?>;
                  border:1px solid <?php echo e($estadoActual === '' ? 'var(--border)' : 'transparent'); ?>;">
            Todas
        </a>
        <a href="<?php echo e(route('admin.vacantes', ['modo' => $modo, 'estado' => 'pendiente'])); ?>"
           style="padding:6px 14px; border-radius:6px; font-size:13px; font-weight:500; text-decoration:none;
                  background:<?php echo e($estadoActual === 'pendiente' ? '#fffbeb' : 'transparent'); ?>;
                  color:<?php echo e($estadoActual === 'pendiente' ? '#d97706' : 'var(--text-muted)'); ?>;
                  border:1px solid <?php echo e($estadoActual === 'pendiente' ? '#fcd34d' : 'transparent'); ?>;">
            Por revisar
        </a>
        <a href="<?php echo e(route('admin.vacantes', ['modo' => $modo, 'estado' => 'activa'])); ?>"
           style="padding:6px 14px; border-radius:6px; font-size:13px; font-weight:500; text-decoration:none;
                  background:<?php echo e($estadoActual === 'activa' ? '#f0fdf4' : 'transparent'); ?>;
                  color:<?php echo e($estadoActual === 'activa' ? '#16a34a' : 'var(--text-muted)'); ?>;
                  border:1px solid <?php echo e($estadoActual === 'activa' ? '#86efac' : 'transparent'); ?>;">
            Activas
        </a>
        <a href="<?php echo e(route('admin.vacantes', ['modo' => $modo, 'estado' => 'cerrada'])); ?>"
           style="padding:6px 14px; border-radius:6px; font-size:13px; font-weight:500; text-decoration:none;
                  background:<?php echo e($estadoActual === 'cerrada' ? '#f8fafc' : 'transparent'); ?>;
                  color:<?php echo e($estadoActual === 'cerrada' ? '#64748b' : 'var(--text-muted)'); ?>;
                  border:1px solid <?php echo e($estadoActual === 'cerrada' ? '#cbd5e1' : 'transparent'); ?>;">
            Cerradas
        </a>

        <form method="GET" class="form-inline toolbar-end">
            <input type="hidden" name="modo" value="<?php echo e($modo); ?>">
            <?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if BLOCK]><![endif]--><?php endif; ?><?php if($estadoActual): ?>
                <input type="hidden" name="estado" value="<?php echo e($estadoActual); ?>">
            <?php endif; ?><?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if ENDBLOCK]><![endif]--><?php endif; ?>
            <input type="text" name="buscar" value="<?php echo e(request('buscar')); ?>" placeholder="Título o empresa..."
                   style="padding:8px 12px; border:1px solid var(--border); border-radius:8px; font-size:13px; background:var(--surface); width:220px;" spellcheck="true" autocorrect="on" autocapitalize="sentences" lang="es-MX">
            <button type="submit" class="btn btn-secondary" style="padding:8px 14px; font-size:13px;">Buscar</button>
            <?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if BLOCK]><![endif]--><?php endif; ?><?php if(request()->hasAny(['buscar', 'estado'])): ?>
                <a href="<?php echo e(route('admin.vacantes', ['modo' => $modo])); ?>" class="btn btn-secondary" style="padding:8px 12px; font-size:13px;" title="Limpiar filtros">&times;</a>
            <?php endif; ?><?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if ENDBLOCK]><![endif]--><?php endif; ?>
        </form>
    </div>

    <div class="table-wrapper table-scroll">
        <?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if BLOCK]><![endif]--><?php endif; ?><?php if($vacantes->isEmpty()): ?>
            <div style="text-align:center; padding:48px; color:#475569;">
                <?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if BLOCK]><![endif]--><?php endif; ?><?php if($estadoActual === 'pendiente'): ?>
                    No hay <?php echo e($modo === 'reclutamiento' ? 'vacantes' : 'servicios'); ?> pendientes de revisión. Todo al día.
                <?php else: ?>
                    No hay <?php echo e($modo === 'reclutamiento' ? 'vacantes' : 'servicios'); ?> que coincidan.
                <?php endif; ?><?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if ENDBLOCK]><![endif]--><?php endif; ?>
            </div>
        <?php else: ?>
            <table class="table">
                <thead>
                    <tr>
                        <th>Solicitud</th>
                        <th>Empresa</th>
                        <?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if BLOCK]><![endif]--><?php endif; ?><?php if($modo === 'reclutamiento'): ?>
                            <th>Requisitos</th>
                            <th>Candidatos</th>
                        <?php else: ?>
                            <th>Tipo de servicio</th>
                            <th>Tarea asignada</th>
                        <?php endif; ?><?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if ENDBLOCK]><![endif]--><?php endif; ?>
                        <th>Estado</th>
                        <th></th>
                    </tr>
                </thead>
                <tbody>
                    <?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if BLOCK]><![endif]--><?php \Livewire\Features\SupportCompiledWireKeys\SupportCompiledWireKeys::openLoop(); ?><?php endif; ?><?php $__currentLoopData = $vacantes; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $vacante): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?><?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><?php \Livewire\Features\SupportCompiledWireKeys\SupportCompiledWireKeys::startLoopIteration(); ?><?php endif; ?>
                        <?php
                            $tareaVinculada = $modo === 'servicios' && $vacante->servicios_asignados_count > 0
                                ? $vacante->serviciosAsignados()->latest()->first()
                                : null;
                        ?>
                        <tr>
                            <td>
                                <div style="font-weight:600; color:var(--text);"><?php echo e($vacante->titulo); ?></div>
                                <div style="font-size:0.75rem; color:#64748b; margin-top:2px;"><?php echo e($vacante->fecha_publicacion?->format('d/m/Y') ?? '—'); ?></div>
                            </td>
                            <td style="font-size:0.85rem;">
                                <div style="display:flex; align-items:center; gap:8px;">
                                    <?php if (isset($component)) { $__componentOriginal8ca5b43b8fff8bb34ab2ba4eb4bdd67b = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginal8ca5b43b8fff8bb34ab2ba4eb4bdd67b = $attributes; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.avatar','data' => ['src' => $vacante->empresa?->usuario?->avatar_url,'nombre' => $vacante->empresa?->nombre_empresa ?? '?','tamano' => 28]] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('avatar'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\Illuminate\View\AnonymousComponent::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes(['src' => \Illuminate\View\Compilers\BladeCompiler::sanitizeComponentAttribute($vacante->empresa?->usuario?->avatar_url),'nombre' => \Illuminate\View\Compilers\BladeCompiler::sanitizeComponentAttribute($vacante->empresa?->nombre_empresa ?? '?'),'tamano' => 28]); ?>
<?php \Livewire\Features\SupportCompiledWireKeys\SupportCompiledWireKeys::processComponentKey($component); ?>

<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginal8ca5b43b8fff8bb34ab2ba4eb4bdd67b)): ?>
<?php $attributes = $__attributesOriginal8ca5b43b8fff8bb34ab2ba4eb4bdd67b; ?>
<?php unset($__attributesOriginal8ca5b43b8fff8bb34ab2ba4eb4bdd67b); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal8ca5b43b8fff8bb34ab2ba4eb4bdd67b)): ?>
<?php $component = $__componentOriginal8ca5b43b8fff8bb34ab2ba4eb4bdd67b; ?>
<?php unset($__componentOriginal8ca5b43b8fff8bb34ab2ba4eb4bdd67b); ?>
<?php endif; ?>
                                    <span><?php echo e($vacante->empresa?->nombre_empresa ?? '—'); ?></span>
                                </div>
                            </td>

                            <?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if BLOCK]><![endif]--><?php endif; ?><?php if($modo === 'reclutamiento'): ?>
                                <td style="font-size:0.8rem; color:#64748b; line-height:1.5;">
                                    <?php echo e($vacante->requisitoResumen()); ?>

                                </td>
                                <td>
                                    <?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if BLOCK]><![endif]--><?php endif; ?><?php if(($vacante->postulaciones_count ?? 0) === 0): ?>
                                        <span style="color:#475569; font-size:0.8rem;">—</span>
                                    <?php else: ?>
                                        <div style="display:flex; flex-direction:column; gap:3px; font-size:0.75rem;">
                                            <?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if BLOCK]><![endif]--><?php endif; ?><?php if($vacante->seleccionados_count > 0): ?>
                                                <span style="color:#22c55e; font-weight:700;"><?php echo e($vacante->seleccionados_count); ?> seleccionado<?php echo e($vacante->seleccionados_count > 1 ? 's' : ''); ?></span>
                                            <?php endif; ?><?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if ENDBLOCK]><![endif]--><?php endif; ?>
                                            <?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if BLOCK]><![endif]--><?php endif; ?><?php if($vacante->entrevista_count > 0): ?>
                                                <span style="color:#f59e0b;"><?php echo e($vacante->entrevista_count); ?> entrevista<?php echo e($vacante->entrevista_count > 1 ? 's' : ''); ?></span>
                                            <?php endif; ?><?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if ENDBLOCK]><![endif]--><?php endif; ?>
                                            <?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if BLOCK]><![endif]--><?php endif; ?><?php if($vacante->postulados_count > 0): ?>
                                                <span style="color:#60a5fa;"><?php echo e($vacante->postulados_count); ?> en revisión</span>
                                            <?php endif; ?><?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if ENDBLOCK]><![endif]--><?php endif; ?>
                                        </div>
                                    <?php endif; ?><?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if ENDBLOCK]><![endif]--><?php endif; ?>
                                </td>
                            <?php else: ?>
                                <td>
                                    <span class="badge badge-secondary" style="font-size:11px;">
                                        <?php echo e(\App\Models\Vacante::tiposServicio()[$vacante->tipo_servicio] ?? $vacante->tipo_servicio); ?>

                                    </span>
                                </td>
                                <td>
                                    <?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if BLOCK]><![endif]--><?php endif; ?><?php if($tareaVinculada): ?>
                                        <a href="<?php echo e(route('admin.tareas.show', $tareaVinculada)); ?>" class="badge badge-blue" style="font-size:11px; text-decoration:none;">
                                            <?php echo e(\App\Models\ServicioAsignado::estadoLabel($tareaVinculada->estado)); ?>

                                        </a>
                                    <?php else: ?>
                                        <span class="badge badge-orange" style="font-size:11px;">Sin asignar</span>
                                    <?php endif; ?><?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if ENDBLOCK]><![endif]--><?php endif; ?>
                                </td>
                            <?php endif; ?><?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if ENDBLOCK]><![endif]--><?php endif; ?>

                            <td>
                                <span class="badge <?php echo e(\App\Models\Vacante::estadoBadgeClass($vacante->estado)); ?>">
                                    <?php echo e(\App\Models\Vacante::estadoLabel($vacante->estado)); ?>

                                </span>
                            </td>
                            <td style="white-space:nowrap;">
                                <div style="display:flex; flex-wrap:wrap; gap:6px; align-items:center; justify-content:flex-end;">
                                    <button type="button" onclick="rhModal('<?php echo e(route('admin.vacantes.modal', $vacante)); ?>')" class="btn btn-secondary" style="padding:4px 10px; font-size:0.8rem;">Ver</button>
                                    <a href="<?php echo e(route('admin.vacantes.editar', $vacante)); ?>" class="btn btn-secondary" style="padding:4px 10px; font-size:0.8rem;">Editar</a>

                                    <?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if BLOCK]><![endif]--><?php endif; ?><?php if($modo === 'reclutamiento'): ?>
                                        <a href="<?php echo e(route('admin.vacantes.matching', $vacante)); ?>" class="btn btn-primary" style="padding:4px 12px; font-size:0.8rem; white-space:nowrap;">Candidatos</a>
                                    <?php else: ?>
                                        <?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if BLOCK]><![endif]--><?php endif; ?><?php if($tareaVinculada): ?>
                                            <a href="<?php echo e(route('admin.tareas.show', $tareaVinculada)); ?>" class="btn btn-primary" style="padding:4px 12px; font-size:0.8rem;">Ver tarea</a>
                                        <?php else: ?>
                                            <form method="POST" action="<?php echo e(route('admin.vacantes.tarea', $vacante)); ?>">
                                                <?php echo csrf_field(); ?>
                                                <button type="submit" class="btn btn-primary" style="padding:4px 12px; font-size:0.8rem; white-space:nowrap;">Crear tarea</button>
                                            </form>
                                        <?php endif; ?><?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if ENDBLOCK]><![endif]--><?php endif; ?>
                                    <?php endif; ?><?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if ENDBLOCK]><![endif]--><?php endif; ?>

                                    <?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if BLOCK]><![endif]--><?php endif; ?><?php if($vacante->estado === 'pendiente'): ?>
                                        <form method="POST" action="<?php echo e(route('admin.vacantes.activar', $vacante)); ?>">
                                            <?php echo csrf_field(); ?>
                                            <?php echo method_field('PATCH'); ?>
                                            <button type="submit" class="btn btn-success" style="padding:4px 10px; font-size:0.8rem;">Activar</button>
                                        </form>
                                        <button type="button" onclick="rhModal('<?php echo e(route('admin.vacantes.accion.modal', [$vacante, 'rechazar'])); ?>')" class="btn btn-danger" style="padding:4px 10px; font-size:0.8rem;">Rechazar</button>
                                    <?php elseif($vacante->estado === 'activa'): ?>
                                        <button type="button" onclick="rhModal('<?php echo e(route('admin.vacantes.accion.modal', [$vacante, 'cerrar'])); ?>')" class="btn btn-secondary" style="padding:4px 10px; font-size:0.8rem;">Desactivar</button>
                                    <?php elseif($vacante->estado === 'cerrada'): ?>
                                        <form method="POST" action="<?php echo e(route('admin.vacantes.reabrir', $vacante)); ?>">
                                            <?php echo csrf_field(); ?>
                                            <?php echo method_field('PATCH'); ?>
                                            <button type="submit" class="btn btn-success" style="padding:4px 10px; font-size:0.8rem;">Reabrir</button>
                                        </form>
                                    <?php elseif($vacante->estado === 'rechazada'): ?>
                                        <form method="POST" action="<?php echo e(route('admin.vacantes.activar', $vacante)); ?>">
                                            <?php echo csrf_field(); ?>
                                            <?php echo method_field('PATCH'); ?>
                                            <button type="submit" class="btn btn-success" style="padding:4px 10px; font-size:0.8rem;">Reactivar</button>
                                        </form>
                                    <?php endif; ?><?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if ENDBLOCK]><![endif]--><?php endif; ?>

                                    <button type="button" onclick="rhModal('<?php echo e(route('admin.vacantes.accion.modal', [$vacante, 'eliminar'])); ?>')" class="btn btn-danger" style="padding:4px 10px; font-size:0.8rem;" title="Eliminar">
                                        <svg fill="none" viewBox="0 0 24 24" stroke-width="1.5" stroke="currentColor" style="width:15px;height:15px;"><path stroke-linecap="round" stroke-linejoin="round" d="M14.74 9l-.346 9m-4.788 0L9.26 9m9.968-3.21c.342.052.682.107 1.022.166m-1.022-.165L18.16 19.673a2.25 2.25 0 0 1-2.244 2.077H8.084a2.25 2.25 0 0 1-2.244-2.077L4.772 5.79m14.456 0a48.108 48.108 0 0 0-3.478-.397M4.772 5.79c.342-.052.682-.107 1.022-.166m1.022.165l.346 9"/></svg>
                                    </button>
                                </div>
                            </td>
                        </tr>
                    <?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><?php \Livewire\Features\SupportCompiledWireKeys\SupportCompiledWireKeys::endLoop(); ?><?php endif; ?><?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?><?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if ENDBLOCK]><![endif]--><?php \Livewire\Features\SupportCompiledWireKeys\SupportCompiledWireKeys::closeLoop(); ?><?php endif; ?>
                </tbody>
            </table>
            <div style="margin-top:16px;">
                <?php echo e($vacantes->links()); ?>

            </div>
        <?php endif; ?><?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if ENDBLOCK]><![endif]--><?php endif; ?>
    </div>
 <?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginal9ac128a9029c0e4701924bd2d73d7f54)): ?>
<?php $attributes = $__attributesOriginal9ac128a9029c0e4701924bd2d73d7f54; ?>
<?php unset($__attributesOriginal9ac128a9029c0e4701924bd2d73d7f54); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal9ac128a9029c0e4701924bd2d73d7f54)): ?>
<?php $component = $__componentOriginal9ac128a9029c0e4701924bd2d73d7f54; ?>
<?php unset($__componentOriginal9ac128a9029c0e4701924bd2d73d7f54); ?>
<?php endif; ?>
<?php /**PATH C:\Dev\Web\SistemaRH_Laravel\resources\views/admin/vacantes/index.blade.php ENDPATH**/ ?>