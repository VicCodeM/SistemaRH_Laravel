<?php
    // Helper para mostrar valor o "—" si está vacío
    $val = fn ($v) => $v !== null && $v !== '' && $v !== [] ? $v : '—';
    $arrVal = fn ($arr, $key, $def = '—') => isset($arr[$key]) && $arr[$key] !== '' ? $arr[$key] : $def;
?>

<?php $__env->startComponent('partials.layout-imprimible', [
    'titulo'    => 'Solicitud de candidato',
    'subtitulo' => $candidato->nombreCompleto() . ' · ' . ($candidato->usuario?->email ?? '—'),
    'tipo'      => 'Ficha',
]); ?>

    <?php
        $estado = \App\Models\Candidato::solicitudEstadoLabel($candidato->solicitud_estado);
        $estadoColor = match($candidato->solicitud_estado) {
            'aprobada' => 'b-green',
            'enviada'  => 'b-yellow',
            'rechazada' => 'b-red',
            default    => 'b-gray',
        };
    ?>

    <div style="margin-bottom:16px; padding:12px 14px; background:#f8fafc; border-radius:8px; display:flex; justify-content:space-between; align-items:center; font-size:11px;">
        <div>
            <strong>Estado:</strong> <span class="badge <?php echo e($estadoColor); ?>"><?php echo e($estado); ?></span>
            <?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if BLOCK]><![endif]--><?php endif; ?><?php if($candidato->solicitud_enviada_at): ?>
                · Enviada <?php echo e($candidato->solicitud_enviada_at->format('d/m/Y')); ?>

            <?php endif; ?><?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if ENDBLOCK]><![endif]--><?php endif; ?>
            <?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if BLOCK]><![endif]--><?php endif; ?><?php if($candidato->solicitud_revisada_at): ?>
                · Revisada <?php echo e($candidato->solicitud_revisada_at->format('d/m/Y')); ?>

            <?php endif; ?><?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if ENDBLOCK]><![endif]--><?php endif; ?>
        </div>
    </div>

    
    <h2 style="font-size:14px; color:#1e40af; margin:18px 0 8px; padding-bottom:4px; border-bottom:1px solid #cbd5e1;">1. Datos personales</h2>
    <table>
        <tbody>
            <tr>
                <td style="width:33%;"><strong>Nombre completo:</strong> <?php echo e($candidato->nombreCompleto()); ?></td>
                <td style="width:33%;"><strong>Fecha de nacimiento:</strong> <?php echo e($candidato->fecha_nacimiento?->format('d/m/Y') ?? '—'); ?></td>
                <td style="width:34%;"><strong>Edad:</strong> <?php echo e($val($candidato->edad)); ?> años</td>
            </tr>
            <tr>
                <td><strong>Sexo:</strong> <?php echo e($val($candidato->sexo)); ?></td>
                <td><strong>Estado civil:</strong> <?php echo e($val($candidato->estado_civil)); ?></td>
                <td><strong>Nacionalidad:</strong> <?php echo e($val($candidato->nacionalidad)); ?></td>
            </tr>
            <tr>
                <td><strong>Lugar de nacimiento:</strong> <?php echo e($val($candidato->lugar_nacimiento)); ?></td>
                <td><strong>Peso:</strong> <?php echo e($val($candidato->peso)); ?> kg</td>
                <td><strong>Estatura:</strong> <?php echo e($val($candidato->estatura)); ?> m</td>
            </tr>
            <tr>
                <td><strong>Vive con:</strong> <?php echo e($val($candidato->vive_con)); ?></td>
                <td><strong>Dependientes:</strong> <?php echo e($val($candidato->dependientes)); ?></td>
                <td></td>
            </tr>
        </tbody>
    </table>

    
    <h2 style="font-size:14px; color:#1e40af; margin:18px 0 8px; padding-bottom:4px; border-bottom:1px solid #cbd5e1;">2. Contacto y dirección</h2>
    <table>
        <tbody>
            <tr>
                <td style="width:33%;"><strong>Correo:</strong> <?php echo e($candidato->usuario?->email ?? '—'); ?></td>
                <td style="width:33%;"><strong>Teléfono:</strong> <?php echo e($val($candidato->telefono)); ?></td>
                <td style="width:34%;"><strong>Celular:</strong> <?php echo e($val($candidato->celular)); ?></td>
            </tr>
            <tr>
                <td colspan="3"><strong>Domicilio:</strong> <?php echo e($val($candidato->domicilio)); ?></td>
            </tr>
            <tr>
                <td><strong>Colonia:</strong> <?php echo e($val($candidato->colonia)); ?></td>
                <td><strong>CP:</strong> <?php echo e($val($candidato->codigo_postal)); ?></td>
                <td><strong>Municipio:</strong> <?php echo e($val($candidato->municipio)); ?></td>
            </tr>
            <tr>
                <td colspan="3"><strong>Ciudad / Estado:</strong> <?php echo e($val($candidato->ciudad)); ?></td>
            </tr>
        </tbody>
    </table>

    
    <h2 style="font-size:14px; color:#1e40af; margin:18px 0 8px; padding-bottom:4px; border-bottom:1px solid #cbd5e1;">3. Documentos de identificación</h2>
    <table>
        <tbody>
            <tr>
                <td style="width:50%;"><strong>CURP:</strong> <?php echo e($val($candidato->curp)); ?></td>
                <td style="width:50%;"><strong>RFC:</strong> <?php echo e($val($candidato->rfc)); ?></td>
            </tr>
            <tr>
                <td><strong>NSS:</strong> <?php echo e($val($candidato->nore_seguro_social)); ?></td>
                <td><strong>AFORE:</strong> <?php echo e($val($candidato->afore)); ?></td>
            </tr>
            <tr>
                <td><strong>Cartilla militar:</strong> <?php echo e($val($candidato->cartilla_militar)); ?></td>
                <td><strong>Pasaporte:</strong> <?php echo e($val($candidato->pasaporte)); ?></td>
            </tr>
        </tbody>
    </table>

    
    <?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if BLOCK]><![endif]--><?php endif; ?><?php if(! empty($candidato->licencia_conducir) && ($candidato->licencia_conducir['tiene'] ?? '') === 'si'): ?>
        <h2 style="font-size:14px; color:#1e40af; margin:18px 0 8px; padding-bottom:4px; border-bottom:1px solid #cbd5e1;">Licencia de conducir</h2>
        <table>
            <tbody>
                <tr>
                    <td><strong>Clase:</strong> <?php echo e($arrVal($candidato->licencia_conducir, 'clase')); ?></td>
                    <td><strong>Número:</strong> <?php echo e($arrVal($candidato->licencia_conducir, 'numero')); ?></td>
                    <td><strong>Vigencia:</strong> <?php echo e($arrVal($candidato->licencia_conducir, 'vigencia')); ?></td>
                </tr>
            </tbody>
        </table>
    <?php endif; ?><?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if ENDBLOCK]><![endif]--><?php endif; ?>

    
    <h2 style="font-size:14px; color:#1e40af; margin:18px 0 8px; padding-bottom:4px; border-bottom:1px solid #cbd5e1;">4. Aspiración laboral</h2>
    <table>
        <tbody>
            <tr>
                <td style="width:50%;"><strong>Puesto deseado:</strong> <?php echo e($val($candidato->puesto_deseado)); ?></td>
                <td style="width:50%;"><strong>Sueldo deseado:</strong> <?php echo e($candidato->sueldo_deseado ? '$ ' . number_format((float) $candidato->sueldo_deseado, 2) : '—'); ?></td>
            </tr>
            <tr>
                <td><strong>Años de experiencia:</strong> <?php echo e($val($candidato->experiencia_anios)); ?></td>
                <td><strong>Escolaridad máxima:</strong> <?php echo e($val($candidato->escolaridad)); ?></td>
            </tr>
        </tbody>
    </table>

    <?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if BLOCK]><![endif]--><?php endif; ?><?php if($candidato->habilidades): ?>
        <table style="margin-top:6px;">
            <tbody>
                <tr><td><strong>Habilidades:</strong><br><?php echo e($candidato->habilidades); ?></td></tr>
            </tbody>
        </table>
    <?php endif; ?><?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if ENDBLOCK]><![endif]--><?php endif; ?>

    
    <?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if BLOCK]><![endif]--><?php endif; ?><?php if(! empty($candidato->escolaridad_detallada)): ?>
        <h2 style="font-size:14px; color:#1e40af; margin:18px 0 8px; padding-bottom:4px; border-bottom:1px solid #cbd5e1;">5. Historial académico</h2>
        <table>
            <thead>
                <tr>
                    <th>Nivel</th>
                    <th>Institución</th>
                    <th>Carrera / Área</th>
                    <th>Periodo</th>
                </tr>
            </thead>
            <tbody>
                <?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if BLOCK]><![endif]--><?php \Livewire\Features\SupportCompiledWireKeys\SupportCompiledWireKeys::openLoop(); ?><?php endif; ?><?php $__currentLoopData = $candidato->escolaridad_detallada; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $est): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?><?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><?php \Livewire\Features\SupportCompiledWireKeys\SupportCompiledWireKeys::startLoopIteration(); ?><?php endif; ?>
                    <tr>
                        <td><?php echo e($arrVal($est, 'nivel')); ?></td>
                        <td><?php echo e($arrVal($est, 'institucion')); ?></td>
                        <td><?php echo e($arrVal($est, 'carrera')); ?></td>
                        <td><?php echo e($arrVal($est, 'periodo')); ?></td>
                    </tr>
                <?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><?php \Livewire\Features\SupportCompiledWireKeys\SupportCompiledWireKeys::endLoop(); ?><?php endif; ?><?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?><?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if ENDBLOCK]><![endif]--><?php \Livewire\Features\SupportCompiledWireKeys\SupportCompiledWireKeys::closeLoop(); ?><?php endif; ?>
            </tbody>
        </table>
    <?php endif; ?><?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if ENDBLOCK]><![endif]--><?php endif; ?>

    
    <?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if BLOCK]><![endif]--><?php endif; ?><?php if(! empty($candidato->historial_laboral)): ?>
        <h2 style="font-size:14px; color:#1e40af; margin:18px 0 8px; padding-bottom:4px; border-bottom:1px solid #cbd5e1;">6. Experiencia laboral</h2>
        <table>
            <thead>
                <tr>
                    <th>Empresa</th>
                    <th>Puesto</th>
                    <th>Periodo</th>
                    <th>Motivo de salida</th>
                </tr>
            </thead>
            <tbody>
                <?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if BLOCK]><![endif]--><?php \Livewire\Features\SupportCompiledWireKeys\SupportCompiledWireKeys::openLoop(); ?><?php endif; ?><?php $__currentLoopData = $candidato->historial_laboral; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $emp): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?><?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><?php \Livewire\Features\SupportCompiledWireKeys\SupportCompiledWireKeys::startLoopIteration(); ?><?php endif; ?>
                    <tr>
                        <td><?php echo e($arrVal($emp, 'empresa')); ?></td>
                        <td><?php echo e($arrVal($emp, 'puesto')); ?></td>
                        <td><?php echo e($arrVal($emp, 'periodo')); ?></td>
                        <td><?php echo e($arrVal($emp, 'motivo_salida')); ?></td>
                    </tr>
                <?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><?php \Livewire\Features\SupportCompiledWireKeys\SupportCompiledWireKeys::endLoop(); ?><?php endif; ?><?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?><?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if ENDBLOCK]><![endif]--><?php \Livewire\Features\SupportCompiledWireKeys\SupportCompiledWireKeys::closeLoop(); ?><?php endif; ?>
            </tbody>
        </table>
    <?php endif; ?><?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if ENDBLOCK]><![endif]--><?php endif; ?>

    
    <?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if BLOCK]><![endif]--><?php endif; ?><?php if(! empty($candidato->referencias_personales)): ?>
        <h2 style="font-size:14px; color:#1e40af; margin:18px 0 8px; padding-bottom:4px; border-bottom:1px solid #cbd5e1;">7. Referencias personales</h2>
        <table>
            <thead>
                <tr>
                    <th>Nombre</th>
                    <th>Relación</th>
                    <th>Teléfono</th>
                    <th>Tiempo de conocerle</th>
                </tr>
            </thead>
            <tbody>
                <?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if BLOCK]><![endif]--><?php \Livewire\Features\SupportCompiledWireKeys\SupportCompiledWireKeys::openLoop(); ?><?php endif; ?><?php $__currentLoopData = $candidato->referencias_personales; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $ref): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?><?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><?php \Livewire\Features\SupportCompiledWireKeys\SupportCompiledWireKeys::startLoopIteration(); ?><?php endif; ?>
                    <tr>
                        <td><?php echo e($arrVal($ref, 'nombre')); ?></td>
                        <td><?php echo e($arrVal($ref, 'relacion')); ?></td>
                        <td><?php echo e($arrVal($ref, 'telefono')); ?></td>
                        <td><?php echo e($arrVal($ref, 'tiempo')); ?></td>
                    </tr>
                <?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><?php \Livewire\Features\SupportCompiledWireKeys\SupportCompiledWireKeys::endLoop(); ?><?php endif; ?><?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?><?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if ENDBLOCK]><![endif]--><?php \Livewire\Features\SupportCompiledWireKeys\SupportCompiledWireKeys::closeLoop(); ?><?php endif; ?>
            </tbody>
        </table>
    <?php endif; ?><?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if ENDBLOCK]><![endif]--><?php endif; ?>

    
    <?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if BLOCK]><![endif]--><?php endif; ?><?php if(! empty($candidato->redes_sociales)): ?>
        <?php
            $hayRedes = collect($candidato->redes_sociales)->filter()->isNotEmpty();
        ?>
        <?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if BLOCK]><![endif]--><?php endif; ?><?php if($hayRedes): ?>
            <h2 style="font-size:14px; color:#1e40af; margin:18px 0 8px; padding-bottom:4px; border-bottom:1px solid #cbd5e1;">8. Redes sociales</h2>
            <table>
                <tbody>
                    <?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if BLOCK]><![endif]--><?php \Livewire\Features\SupportCompiledWireKeys\SupportCompiledWireKeys::openLoop(); ?><?php endif; ?><?php $__currentLoopData = ['facebook' => 'Facebook', 'twitter' => 'Twitter / X', 'instagram' => 'Instagram', 'linkedin' => 'LinkedIn']; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key => $label): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?><?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><?php \Livewire\Features\SupportCompiledWireKeys\SupportCompiledWireKeys::startLoopIteration(); ?><?php endif; ?>
                        <?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if BLOCK]><![endif]--><?php endif; ?><?php if(! empty($candidato->redes_sociales[$key])): ?>
                            <tr>
                                <td style="width:25%;"><strong><?php echo e($label); ?>:</strong></td>
                                <td><?php echo e($candidato->redes_sociales[$key]); ?></td>
                            </tr>
                        <?php endif; ?><?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if ENDBLOCK]><![endif]--><?php endif; ?>
                    <?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><?php \Livewire\Features\SupportCompiledWireKeys\SupportCompiledWireKeys::endLoop(); ?><?php endif; ?><?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?><?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if ENDBLOCK]><![endif]--><?php \Livewire\Features\SupportCompiledWireKeys\SupportCompiledWireKeys::closeLoop(); ?><?php endif; ?>
                </tbody>
            </table>
        <?php endif; ?><?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if ENDBLOCK]><![endif]--><?php endif; ?>
    <?php endif; ?><?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if ENDBLOCK]><![endif]--><?php endif; ?>

    
    <?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if BLOCK]><![endif]--><?php endif; ?><?php if($candidato->postulaciones->isNotEmpty()): ?>
        <h2 style="font-size:14px; color:#1e40af; margin:18px 0 8px; padding-bottom:4px; border-bottom:1px solid #cbd5e1;">9. Postulaciones a vacantes</h2>
        <table>
            <thead>
                <tr>
                    <th>Vacante</th>
                    <th>Empresa</th>
                    <th>Estado</th>
                    <th>Postulado</th>
                </tr>
            </thead>
            <tbody>
                <?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if BLOCK]><![endif]--><?php \Livewire\Features\SupportCompiledWireKeys\SupportCompiledWireKeys::openLoop(); ?><?php endif; ?><?php $__currentLoopData = $candidato->postulaciones; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $p): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?><?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><?php \Livewire\Features\SupportCompiledWireKeys\SupportCompiledWireKeys::startLoopIteration(); ?><?php endif; ?>
                    <tr>
                        <td><?php echo e($p->vacante?->titulo ?? '—'); ?></td>
                        <td><?php echo e($p->vacante?->empresa?->nombre_empresa ?? '—'); ?></td>
                        <td>
                            <span class="badge b-blue"><?php echo e(\App\Models\Postulacion::estadoLabel($p->estado)); ?></span>
                        </td>
                        <td><?php echo e($p->fecha_postulacion?->format('d/m/Y') ?? '—'); ?></td>
                    </tr>
                <?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><?php \Livewire\Features\SupportCompiledWireKeys\SupportCompiledWireKeys::endLoop(); ?><?php endif; ?><?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?><?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if ENDBLOCK]><![endif]--><?php \Livewire\Features\SupportCompiledWireKeys\SupportCompiledWireKeys::closeLoop(); ?><?php endif; ?>
            </tbody>
        </table>
    <?php endif; ?><?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if ENDBLOCK]><![endif]--><?php endif; ?>

    
    <div style="margin-top:40px; padding-top:20px; border-top:1px solid #cbd5e1; display:flex; justify-content:space-between; gap:40px;">
        <div style="flex:1; text-align:center;">
            <div style="border-bottom:1px solid #475569; margin-top:30px;"></div>
            <p style="margin-top:6px; font-size:10px; color:#64748b;">Firma del candidato</p>
        </div>
        <div style="flex:1; text-align:center;">
            <div style="border-bottom:1px solid #475569; margin-top:30px;"></div>
            <p style="margin-top:6px; font-size:10px; color:#64748b;">Firma del revisor</p>
        </div>
        <div style="flex:1; text-align:center;">
            <div style="border-bottom:1px solid #475569; margin-top:30px;"></div>
            <p style="margin-top:6px; font-size:10px; color:#64748b;">Fecha</p>
        </div>
    </div>

<?php echo $__env->renderComponent(); ?>
<?php /**PATH C:\Dev\Web\SistemaRH_Laravel\resources\views/admin/candidatos/solicitud-imprimible.blade.php ENDPATH**/ ?>