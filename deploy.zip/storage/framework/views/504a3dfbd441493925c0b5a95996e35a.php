<?php if (isset($component)) { $__componentOriginal9ac128a9029c0e4701924bd2d73d7f54 = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginal9ac128a9029c0e4701924bd2d73d7f54 = $attributes; } ?>
<?php $component = App\View\Components\AppLayout::resolve([] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('app-layout'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\App\View\Components\AppLayout::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes([]); ?>
<?php \Livewire\Features\SupportCompiledWireKeys\SupportCompiledWireKeys::processComponentKey($component); ?>

     <?php $__env->slot('header', null, []); ?> 
        <nav class="breadcrumbs">
            <a href="<?php echo e(route('admin.candidatos')); ?>">Candidatos</a>
            <span class="breadcrumb-sep">&rsaquo;</span>
            <span>Solicitud</span>
        </nav>
        <div style="display:flex; justify-content:space-between; gap:16px; align-items:flex-start; flex-wrap:wrap;">
            <div>
                <h1 class="page-title">Solicitud de <?php echo e($candidato->nombreCompleto()); ?></h1>
                <p class="page-subtitle">Revisa la ficha completa y corrige lo necesario sin perder el avance.</p>
            </div>
            <div style="display:flex; gap:10px; flex-wrap:wrap;">
                <a href="<?php echo e(route('admin.candidatos.solicitud.pdf', $candidato)); ?>" target="_blank" class="btn btn-secondary" title="Descargar solicitud completa en PDF">📄 Descargar PDF</a>
                <a href="<?php echo e(route('admin.candidatos')); ?>" class="btn btn-secondary">Volver</a>
                <button onclick="rhModal('<?php echo e(route('admin.candidatos.modal', $candidato)); ?>')" class="btn btn-primary">Ver resumen</button>
            </div>
        </div>
     <?php $__env->endSlot(); ?>

    <div style="max-width:1180px; margin:0 auto;">
        <?php
$__split = function ($name, $params = []) {
    return [$name, $params];
};
[$__name, $__params] = $__split('candidato-solicitud', ['candidato-id' => $candidato->id,'modo-admin' => true]);

$__keyOuter = $__key ?? null;

$__key = null;
$__componentSlots = [];

$__key ??= \Livewire\Features\SupportCompiledWireKeys\SupportCompiledWireKeys::generateKey('lw-838894724-0', $__key);

$__html = app('livewire')->mount($__name, $__params, $__key, $__componentSlots);

echo $__html;

unset($__html);
unset($__key);
$__key = $__keyOuter;
unset($__keyOuter);
unset($__name);
unset($__params);
unset($__componentSlots);
unset($__split);
?>
    </div>
 <?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginal9ac128a9029c0e4701924bd2d73d7f54)): ?>
<?php $attributes = $__attributesOriginal9ac128a9029c0e4701924bd2d73d7f54; ?>
<?php unset($__attributesOriginal9ac128a9029c0e4701924bd2d73d7f54); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal9ac128a9029c0e4701924bd2d73d7f54)): ?>
<?php $component = $__componentOriginal9ac128a9029c0e4701924bd2d73d7f54; ?>
<?php unset($__componentOriginal9ac128a9029c0e4701924bd2d73d7f54); ?>
<?php endif; ?>
<?php /**PATH C:\Dev\Web\SistemaRH_Laravel\resources\views/admin/candidatos/solicitud.blade.php ENDPATH**/ ?>