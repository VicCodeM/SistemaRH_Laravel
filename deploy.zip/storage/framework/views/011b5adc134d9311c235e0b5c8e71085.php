<?php $attributes ??= new \Illuminate\View\ComponentAttributeBag;

$__newAttributes = [];
$__propNames = \Illuminate\View\ComponentAttributeBag::extractPropNames(([
    'titulo'   => '¿Qué sigue?',
    'acciones' => collect(),  // Collection de arrays: icono, titulo, mensaje, href, color, etiquetaBoton
]));

foreach ($attributes->all() as $__key => $__value) {
    if (in_array($__key, $__propNames)) {
        $$__key = $$__key ?? $__value;
    } else {
        $__newAttributes[$__key] = $__value;
    }
}

$attributes = new \Illuminate\View\ComponentAttributeBag($__newAttributes);

unset($__propNames);
unset($__newAttributes);

foreach (array_filter(([
    'titulo'   => '¿Qué sigue?',
    'acciones' => collect(),  // Collection de arrays: icono, titulo, mensaje, href, color, etiquetaBoton
]), 'is_string', ARRAY_FILTER_USE_KEY) as $__key => $__value) {
    $$__key = $$__key ?? $__value;
}

$__defined_vars = get_defined_vars();

foreach ($attributes->all() as $__key => $__value) {
    if (array_key_exists($__key, $__defined_vars)) unset($$__key);
}

unset($__defined_vars, $__key, $__value); ?>

<div class="card fade-in" style="padding:20px; margin-bottom:20px;">
    <h2 style="margin:0 0 14px; font-size:0.95rem; font-weight:700; color:var(--text);"><?php echo e($titulo); ?></h2>

    <div class="pending-actions-grid">
        <?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if BLOCK]><![endif]--><?php \Livewire\Features\SupportCompiledWireKeys\SupportCompiledWireKeys::openLoop(); ?><?php endif; ?><?php $__currentLoopData = $acciones; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $a): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?><?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><?php \Livewire\Features\SupportCompiledWireKeys\SupportCompiledWireKeys::startLoopIteration(); ?><?php endif; ?>
            <a href="<?php echo e($a['href']); ?>"
               class="pending-action-item"
               style="border-left-color: <?php echo e($a['color']); ?>;"
               onmouseover="this.style.transform='translateX(2px)'"
               onmouseout="this.style.transform='translateX(0)'">
                <div style="font-size:28px; line-height:1; flex-shrink:0;"><?php echo e($a['icono']); ?></div>
                <div style="flex:1; min-width:0;">
                    <div style="font-weight:600; font-size:0.9rem; color:var(--text); margin-bottom:2px;">
                        <?php echo e($a['titulo']); ?>

                    </div>
                    <div style="font-size:0.78rem; color:#64748b; line-height:1.4;">
                        <?php echo e($a['mensaje']); ?>

                    </div>
                    <div style="margin-top:8px; font-size:0.75rem; color:<?php echo e($a['color']); ?>; font-weight:600;">
                        <?php echo e($a['etiquetaBoton'] ?? 'Ir'); ?> →
                    </div>
                </div>
            </a>
        <?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><?php \Livewire\Features\SupportCompiledWireKeys\SupportCompiledWireKeys::endLoop(); ?><?php endif; ?><?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?><?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if ENDBLOCK]><![endif]--><?php \Livewire\Features\SupportCompiledWireKeys\SupportCompiledWireKeys::closeLoop(); ?><?php endif; ?>
    </div>
</div>
<?php /**PATH C:\Dev\Web\SistemaRH_Laravel\resources\views/components/acciones-pendientes.blade.php ENDPATH**/ ?>