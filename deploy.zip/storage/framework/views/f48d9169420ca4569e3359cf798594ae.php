<?php
    $tabSolicitado = $tabActivo ?? request('tab', 'servicios');
    $aliasTabs = ['opciones' => 'vacantes'];
    $baseQuery = request()->except(['tab', 'page', 'grupo', 'buscar', 'buscar_servicio']);

    $tabs = [
        'servicios' => ['icono' => 'Servicios', 'label' => 'Servicios'],
        'vacantes' => ['icono' => 'Vacantes', 'label' => 'Vacantes'],
        'empresas' => ['icono' => 'Empresas', 'label' => 'Empresas'],
    ];

    $tabActivo = $aliasTabs[$tabSolicitado] ?? $tabSolicitado;
    if (! array_key_exists($tabActivo, $tabs)) {
        $tabActivo = 'servicios';
    }

    $hints = [
        'servicios' => 'Servicios que tu empresa ofrece y los tipos que se pueden solicitar.',
        'vacantes' => 'Listas que usa el formulario de vacantes: areas, niveles de estudio, contratos y jerarquias.',
        'empresas' => 'Datos de las empresas clientes: sectores economicos.',
    ];
?>

<?php if (isset($component)) { $__componentOriginal9ac128a9029c0e4701924bd2d73d7f54 = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginal9ac128a9029c0e4701924bd2d73d7f54 = $attributes; } ?>
<?php $component = App\View\Components\AppLayout::resolve([] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('app-layout'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\App\View\Components\AppLayout::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes([]); ?>
<?php \Livewire\Features\SupportCompiledWireKeys\SupportCompiledWireKeys::processComponentKey($component); ?>

     <?php $__env->slot('header', null, []); ?> 
        <nav class="breadcrumbs">
            <a href="<?php echo e(route('admin.dashboard')); ?>">Administracion</a>
            <span class="breadcrumb-sep">&rsaquo;</span>
            <span>Personalizar el sistema</span>
        </nav>
        <div class="candidate-inline-meta">
            <div>
                <h1 class="page-title">Personalizar el sistema</h1>
                <p class="page-subtitle">Decide que servicios ofreces y que opciones aparecen en los formularios.</p>
            </div>
            <?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if BLOCK]><![endif]--><?php endif; ?><?php if($tabActivo === 'servicios'): ?>
                <a href="<?php echo e(route('admin.catalogo.create')); ?>" class="btn btn-primary" style="font-size:14px; padding:10px 18px;">+ Nuevo servicio</a>
            <?php else: ?>
                <?php $gruposModulo = \App\Models\CatalogoOpcion::gruposDelModulo($tabActivo); ?>
                <a href="<?php echo e(route('admin.catalogos.create', ['grupo' => request('grupo', $gruposModulo[0] ?? null), 'tab' => $tabActivo])); ?>" class="btn btn-primary" style="font-size:14px; padding:10px 18px;">+ Nueva opcion</a>
            <?php endif; ?><?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if ENDBLOCK]><![endif]--><?php endif; ?>
        </div>
     <?php $__env->endSlot(); ?>

    <?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if BLOCK]><![endif]--><?php endif; ?><?php if(session('success')): ?>
        <div class="alert alert-success mb-4"><?php echo e(session('success')); ?></div>
    <?php endif; ?><?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if ENDBLOCK]><![endif]--><?php endif; ?>
    <?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if BLOCK]><![endif]--><?php endif; ?><?php if(session('error')): ?>
        <div class="alert alert-danger mb-4"><?php echo e(session('error')); ?></div>
    <?php endif; ?><?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if ENDBLOCK]><![endif]--><?php endif; ?>

    <div style="display:flex; gap:0; margin-bottom:18px; border-bottom:2px solid var(--border); flex-wrap:wrap;">
        <?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if BLOCK]><![endif]--><?php \Livewire\Features\SupportCompiledWireKeys\SupportCompiledWireKeys::openLoop(); ?><?php endif; ?><?php $__currentLoopData = $tabs; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key => $cfg): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?><?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><?php \Livewire\Features\SupportCompiledWireKeys\SupportCompiledWireKeys::startLoopIteration(); ?><?php endif; ?>
            <a href="<?php echo e(route('admin.catalogos.index', array_merge($baseQuery, ['tab' => $key]))); ?>"
               style="padding:14px 24px; text-decoration:none; font-weight:600; font-size:1rem; border-bottom:3px solid <?php echo e($tabActivo === $key ? 'var(--accent)' : 'transparent'); ?>; color:<?php echo e($tabActivo === $key ? 'var(--accent)' : 'var(--text-muted)'); ?>; margin-bottom:-2px;">
                <?php echo e($cfg['label']); ?>

            </a>
        <?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><?php \Livewire\Features\SupportCompiledWireKeys\SupportCompiledWireKeys::endLoop(); ?><?php endif; ?><?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?><?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if ENDBLOCK]><![endif]--><?php \Livewire\Features\SupportCompiledWireKeys\SupportCompiledWireKeys::closeLoop(); ?><?php endif; ?>
    </div>

    <?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if BLOCK]><![endif]--><?php endif; ?><?php if($tabActivo === 'servicios'): ?>
        <div class="metrics-grid" style="margin-bottom:18px;">
            <div class="metric-card">
                <div class="metric-top">
                    <span class="metric-label">Servicios</span>
                </div>
                <div class="metric-value"><?php echo e($serviciosStats['total']); ?></div>
                <span class="metric-change text-muted"><?php echo e($serviciosStats['activos']); ?> activos</span>
            </div>
            <div class="metric-card">
                <div class="metric-top">
                    <span class="metric-label">Empresa</span>
                </div>
                <div class="metric-value"><?php echo e($serviciosStats['empresa']); ?></div>
                <span class="metric-change text-muted">Solo empresas</span>
            </div>
            <div class="metric-card">
                <div class="metric-top">
                    <span class="metric-label">Candidato</span>
                </div>
                <div class="metric-value"><?php echo e($serviciosStats['candidato']); ?></div>
                <span class="metric-change text-muted">Solo candidatos</span>
            </div>
            <div class="metric-card">
                <div class="metric-top">
                    <span class="metric-label">Ambos</span>
                </div>
                <div class="metric-value"><?php echo e($serviciosStats['ambos']); ?></div>
                <span class="metric-change text-muted">Disponibles para ambos</span>
            </div>
        </div>

        <div class="card" style="padding:20px;">
            <p style="margin:0 0 16px; font-size:13px; color:#64748b;">
                Aqui defines los servicios que tu empresa puede dar: capacitaciones, coaching, mantenimiento y otros.
            </p>

            <form method="GET" style="display:flex; gap:8px; margin-bottom:16px; flex-wrap:wrap; align-items:center;">
                <input type="hidden" name="tab" value="servicios">
                <input type="text" name="buscar_servicio" class="form-input" value="<?php echo e(request('buscar_servicio')); ?>" placeholder="Buscar servicio..." style="flex:1; min-width:220px; padding:10px 14px;" spellcheck="true" autocorrect="on" autocapitalize="sentences" lang="es-MX">
                <button type="submit" class="btn btn-secondary">Buscar</button>
                <?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if BLOCK]><![endif]--><?php endif; ?><?php if(request('buscar_servicio')): ?>
                    <a href="<?php echo e(route('admin.catalogos.index', ['tab' => 'servicios'])); ?>" class="btn btn-ghost">Limpiar</a>
                <?php endif; ?><?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if ENDBLOCK]><![endif]--><?php endif; ?>
                <a href="<?php echo e(route('admin.catalogo.create')); ?>" class="btn btn-primary">+ Nuevo servicio</a>
            </form>

            <?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if BLOCK]><![endif]--><?php endif; ?><?php if($servicios->isEmpty()): ?>
                <div style="text-align:center; padding:60px 20px;">
                    <p style="font-size:1rem; margin:0 0 6px;">Aun no hay servicios.</p>
                    <p style="font-size:13px; color:#94a3b8; margin:0 0 16px;">Agrega el primero para que empresas y candidatos puedan solicitarlo.</p>
                    <a href="<?php echo e(route('admin.catalogo.create')); ?>" class="btn btn-primary">+ Agregar el primero</a>
                </div>
            <?php else: ?>
                <div class="desktop-only table-scroll">
                    <table class="table" style="width:100%;">
                        <thead>
                            <tr>
                                <th>Nombre del servicio</th>
                                <th style="width:120px;">Para quien</th>
                                <th style="width:100px; text-align:center;">Estado</th>
                                <th style="width:160px; text-align:right;">Acciones</th>
                            </tr>
                        </thead>
                        <tbody>
                            <?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if BLOCK]><![endif]--><?php \Livewire\Features\SupportCompiledWireKeys\SupportCompiledWireKeys::openLoop(); ?><?php endif; ?><?php $__currentLoopData = $servicios; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $servicio): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?><?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><?php \Livewire\Features\SupportCompiledWireKeys\SupportCompiledWireKeys::startLoopIteration(); ?><?php endif; ?>
                                <?php
                                    $pq = ['empresa' => 'Empresas', 'candidato' => 'Candidatos', 'ambos' => 'Ambos'];
                                    $bloqueado = $servicio->activo && ! $servicio->puedeDesactivarse();
                                ?>
                                <tr>
                                    <td>
                                        <div style="font-weight:600; font-size:14px;"><?php echo e($servicio->nombre); ?></div>
                                        <?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if BLOCK]><![endif]--><?php endif; ?><?php if($servicio->descripcion): ?>
                                            <div style="font-size:12px; color:#94a3b8; margin-top:2px;"><?php echo e(\Illuminate\Support\Str::limit($servicio->descripcion, 90)); ?></div>
                                        <?php endif; ?><?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if ENDBLOCK]><![endif]--><?php endif; ?>
                                    </td>
                                    <td><span style="font-size:12px;"><?php echo e($pq[$servicio->para_quien] ?? 'Ambos'); ?></span></td>
                                    <td style="text-align:center;">
                                        <form method="POST" action="<?php echo e(route('admin.catalogo.toggle', $servicio)); ?>" style="display:inline;">
                                            <?php echo csrf_field(); ?>
                                            <?php echo method_field('PATCH'); ?>
                                            <button type="submit"
                                                    <?php if($bloqueado): echo 'disabled'; endif; ?>
                                                    style="padding:5px 12px; border-radius:20px; font-size:12px; font-weight:500; cursor:pointer; border:none;
                                                           background:<?php echo e($servicio->activo ? 'var(--success-light)' : 'var(--surface-2)'); ?>;
                                                           color:<?php echo e($servicio->activo ? 'var(--success)' : 'var(--text-muted)'); ?>;
                                                           opacity:<?php echo e($bloqueado ? '.6' : '1'); ?>;
                                                           cursor:<?php echo e($bloqueado ? 'not-allowed' : 'pointer'); ?>;"
                                                    title="<?php echo e($bloqueado ? 'No se puede desactivar: tiene pedidos activos o en proceso' : ($servicio->activo ? 'Clic para desactivar' : 'Clic para activar')); ?>">
                                                <?php echo e($servicio->activo ? 'Activo' : 'Inactivo'); ?>

                                            </button>
                                        </form>
                                    </td>
                                    <td style="text-align:right; white-space:nowrap;">
                                        <a href="<?php echo e(route('admin.catalogo.edit', $servicio)); ?>" class="btn btn-secondary" style="padding:5px 12px; font-size:12px;">Editar</a>
                                        <button type="button" onclick="rhModal('<?php echo e(route('admin.catalogo.accion.modal', [$servicio, 'eliminar'])); ?>')" class="btn btn-danger" style="padding:5px 12px; font-size:12px;">Borrar</button>
                                    </td>
                                </tr>
                            <?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><?php \Livewire\Features\SupportCompiledWireKeys\SupportCompiledWireKeys::endLoop(); ?><?php endif; ?><?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?><?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if ENDBLOCK]><![endif]--><?php \Livewire\Features\SupportCompiledWireKeys\SupportCompiledWireKeys::closeLoop(); ?><?php endif; ?>
                        </tbody>
                    </table>
                </div>

                <div class="mobile-only">
                    <div class="candidate-mobile-list">
                        <?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if BLOCK]><![endif]--><?php \Livewire\Features\SupportCompiledWireKeys\SupportCompiledWireKeys::openLoop(); ?><?php endif; ?><?php $__currentLoopData = $servicios; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $servicio): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?><?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><?php \Livewire\Features\SupportCompiledWireKeys\SupportCompiledWireKeys::startLoopIteration(); ?><?php endif; ?>
                            <?php
                                $pq = ['empresa' => 'Empresas', 'candidato' => 'Candidatos', 'ambos' => 'Ambos'];
                                $bloqueado = $servicio->activo && ! $servicio->puedeDesactivarse();
                            ?>
                            <article class="candidate-mobile-card">
                                <div class="candidate-inline-meta">
                                    <div>
                                        <h3 class="candidate-mobile-card-title"><?php echo e($servicio->nombre); ?></h3>
                                        <p class="candidate-mobile-card-subtitle"><?php echo e($pq[$servicio->para_quien] ?? 'Ambos'); ?></p>
                                    </div>
                                    <span class="badge <?php echo e($servicio->activo ? 'badge-green' : 'badge-gray'); ?>"><?php echo e($servicio->activo ? 'Activo' : 'Inactivo'); ?></span>
                                </div>

                                <div class="candidate-mobile-meta">
                                    <div>
                                        <p class="candidate-mobile-meta-label">Tipo</p>
                                        <p class="candidate-mobile-meta-value"><?php echo e(\App\Models\CatalogoServicio::tipos()[$servicio->tipo] ?? $servicio->tipo); ?></p>
                                    </div>
                                    <div>
                                        <p class="candidate-mobile-meta-label">Jerarquia</p>
                                        <p class="candidate-mobile-meta-value"><?php echo e(\App\Models\CatalogoServicio::nivelJerarquicoLabel($servicio->nivel_jerarquico)); ?></p>
                                    </div>
                                    <div>
                                        <p class="candidate-mobile-meta-label">Descripcion</p>
                                        <p class="candidate-mobile-meta-value"><?php echo e($servicio->descripcion ?: 'Sin descripcion'); ?></p>
                                    </div>
                                </div>

                                <div class="candidate-actions" style="margin-top:14px;">
                                    <form method="POST" action="<?php echo e(route('admin.catalogo.toggle', $servicio)); ?>">
                                        <?php echo csrf_field(); ?>
                                        <?php echo method_field('PATCH'); ?>
                                        <button type="submit" class="btn btn-secondary btn-sm" <?php if($bloqueado): echo 'disabled'; endif; ?> title="<?php echo e($bloqueado ? 'No se puede desactivar: tiene pedidos activos o en proceso' : ($servicio->activo ? 'Desactivar' : 'Activar')); ?>"><?php echo e($servicio->activo ? 'Desactivar' : 'Activar'); ?></button>
                                    </form>
                                    <a href="<?php echo e(route('admin.catalogo.edit', $servicio)); ?>" class="btn btn-secondary btn-sm">Editar</a>
                                    <button type="button" onclick="rhModal('<?php echo e(route('admin.catalogo.accion.modal', [$servicio, 'eliminar'])); ?>')" class="btn btn-danger btn-sm">Borrar</button>
                                </div>
                            </article>
                        <?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><?php \Livewire\Features\SupportCompiledWireKeys\SupportCompiledWireKeys::endLoop(); ?><?php endif; ?><?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?><?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if ENDBLOCK]><![endif]--><?php \Livewire\Features\SupportCompiledWireKeys\SupportCompiledWireKeys::closeLoop(); ?><?php endif; ?>
                    </div>
                </div>

                <div style="margin-top:16px;"><?php echo e($servicios->links()); ?></div>
            <?php endif; ?><?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if ENDBLOCK]><![endif]--><?php endif; ?>
        </div>
    <?php else: ?>
        <div class="metrics-grid" style="margin-bottom:18px;">
            <div class="metric-card">
                <div class="metric-top">
                    <span class="metric-label">Opciones</span>
                </div>
                <div class="metric-value"><?php echo e($stats['opciones_total']); ?></div>
                <span class="metric-change text-muted">Total del sistema</span>
            </div>
            <div class="metric-card">
                <div class="metric-top">
                    <span class="metric-label">Grupos</span>
                </div>
                <div class="metric-value"><?php echo e($stats['grupos_activos']); ?></div>
                <span class="metric-change text-muted">Listas configurables</span>
            </div>
            <div class="metric-card">
                <div class="metric-top">
                    <span class="metric-label">Sistema</span>
                </div>
                <div class="metric-value"><?php echo e($stats['opciones_sistema']); ?></div>
                <span class="metric-change text-muted">Bloqueadas</span>
            </div>
            <div class="metric-card">
                <div class="metric-top">
                    <span class="metric-label">Personalizadas</span>
                </div>
                <div class="metric-value"><?php echo e($stats['opciones_personalizadas']); ?></div>
                <span class="metric-change text-muted">Editables</span>
            </div>
        </div>

        <div class="card" style="padding:20px;">
            <p style="margin:0 0 16px; font-size:13px; color:#64748b;"><?php echo e($hints[$tabActivo] ?? ''); ?></p>

            <?php
                $todosLosGrupos = \App\Models\CatalogoOpcion::gruposGestionables();
                $gruposModulo = \App\Models\CatalogoOpcion::gruposDelModulo($tabActivo);
            ?>

            <form method="GET" style="display:flex; gap:8px; margin-bottom:16px; flex-wrap:wrap;">
                <input type="hidden" name="tab" value="<?php echo e($tabActivo); ?>">
                <select name="grupo" class="form-input" onchange="this.form.submit()" style="min-width:280px; padding:10px 14px; font-size:14px;">
                    <option value="">Ver todas las listas de <?php echo e($tabs[$tabActivo]['label']); ?></option>
                    <?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if BLOCK]><![endif]--><?php \Livewire\Features\SupportCompiledWireKeys\SupportCompiledWireKeys::openLoop(); ?><?php endif; ?><?php $__currentLoopData = $gruposModulo; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $clave): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?><?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><?php \Livewire\Features\SupportCompiledWireKeys\SupportCompiledWireKeys::startLoopIteration(); ?><?php endif; ?>
                        <?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if BLOCK]><![endif]--><?php endif; ?><?php if(isset($todosLosGrupos[$clave])): ?>
                            <option value="<?php echo e($clave); ?>" <?php echo e(request('grupo') === $clave ? 'selected' : ''); ?>><?php echo e($todosLosGrupos[$clave]); ?></option>
                        <?php endif; ?><?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if ENDBLOCK]><![endif]--><?php endif; ?>
                    <?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><?php \Livewire\Features\SupportCompiledWireKeys\SupportCompiledWireKeys::endLoop(); ?><?php endif; ?><?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?><?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if ENDBLOCK]><![endif]--><?php \Livewire\Features\SupportCompiledWireKeys\SupportCompiledWireKeys::closeLoop(); ?><?php endif; ?>
                </select>
            <input type="text" name="buscar" class="form-input" value="<?php echo e(request('buscar')); ?>" placeholder="Buscar..." style="flex:1; min-width:200px; padding:10px 14px;" spellcheck="true" autocorrect="on" autocapitalize="sentences" lang="es-MX">
                <button type="submit" class="btn btn-secondary">Buscar</button>
                <?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if BLOCK]><![endif]--><?php endif; ?><?php if(request()->hasAny(['grupo', 'buscar'])): ?>
                    <a href="<?php echo e(route('admin.catalogos.index', ['tab' => $tabActivo])); ?>" class="btn btn-ghost">Limpiar</a>
                <?php endif; ?><?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if ENDBLOCK]><![endif]--><?php endif; ?>
            </form>

            <?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if BLOCK]><![endif]--><?php \Livewire\Features\SupportCompiledWireKeys\SupportCompiledWireKeys::openLoop(); ?><?php endif; ?><?php $__empty_1 = true; $__currentLoopData = $catalogosPorGrupo; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $grupo => $items): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?><?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><?php \Livewire\Features\SupportCompiledWireKeys\SupportCompiledWireKeys::startLoopIteration(); ?><?php endif; ?>
                <?php $grupoLabel = \App\Models\CatalogoOpcion::grupoLabel($grupo); ?>
                <div style="margin-bottom:24px; padding:18px; border:1px solid var(--border); border-radius:10px; background:var(--surface);">
                    <div class="candidate-inline-meta" style="margin-bottom:12px;">
                        <div>
                            <h3 style="margin:0; font-size:1rem; font-weight:700;"><?php echo e($grupoLabel); ?></h3>
                            <p style="margin:2px 0 0; font-size:12px; color:#94a3b8;"><?php echo e($items->count()); ?> opcion(es) en esta lista</p>
                        </div>
                        <a href="<?php echo e(route('admin.catalogos.create', ['grupo' => $grupo, 'tab' => $tabActivo])); ?>" class="btn btn-secondary" style="font-size:12px;">+ Agregar opcion</a>
                    </div>

                    <div class="desktop-only table-scroll">
                        <table class="table" style="width:100%; margin:0;">
                            <thead>
                                <tr>
                                    <th>Lo que ve el usuario</th>
                                    <th style="width:100px; text-align:center;">Visible</th>
                                    <th style="width:160px; text-align:right;">Acciones</th>
                                </tr>
                            </thead>
                            <tbody>
                                <?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if BLOCK]><![endif]--><?php \Livewire\Features\SupportCompiledWireKeys\SupportCompiledWireKeys::openLoop(); ?><?php endif; ?><?php $__currentLoopData = $items; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $opcion): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?><?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><?php \Livewire\Features\SupportCompiledWireKeys\SupportCompiledWireKeys::startLoopIteration(); ?><?php endif; ?>
                                    <tr>
                                        <td>
                                            <div style="font-weight:500;"><?php echo e($opcion->valor); ?></div>
                                            <?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if BLOCK]><![endif]--><?php endif; ?><?php if($opcion->descripcion): ?>
                                                <div style="font-size:11px; color:#94a3b8;"><?php echo e(\Illuminate\Support\Str::limit($opcion->descripcion, 80)); ?></div>
                                            <?php endif; ?><?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if ENDBLOCK]><![endif]--><?php endif; ?>
                                        </td>
                                        <td style="text-align:center;">
                                            <?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if BLOCK]><![endif]--><?php endif; ?><?php if($opcion->es_sistema): ?>
                                                <span style="padding:5px 12px; border-radius:20px; font-size:11px; background:var(--surface-2); color:var(--text-muted);" title="Esta opcion la usa el sistema, no se puede ocultar">Fija</span>
                                            <?php else: ?>
                                                <form method="POST" action="<?php echo e(route('admin.catalogos.toggle', $opcion)); ?>" style="display:inline;">
                                                    <?php echo csrf_field(); ?>
                                                    <?php echo method_field('PATCH'); ?>
                                                    <button type="submit"
                                                            style="padding:5px 12px; border-radius:20px; font-size:12px; font-weight:500; cursor:pointer; border:none;
                                                                   background:<?php echo e($opcion->activo ? 'var(--success-light)' : 'var(--surface-2)'); ?>;
                                                                   color:<?php echo e($opcion->activo ? 'var(--success)' : 'var(--text-muted)'); ?>;">
                                                        <?php echo e($opcion->activo ? 'Si' : 'No'); ?>

                                                    </button>
                                                </form>
                                            <?php endif; ?><?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if ENDBLOCK]><![endif]--><?php endif; ?>
                                        </td>
                                        <td style="text-align:right; white-space:nowrap;">
                                            <a href="<?php echo e(route('admin.catalogos.edit', $opcion)); ?>" class="btn btn-secondary" style="padding:5px 12px; font-size:12px;">Editar</a>
                                            <?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if BLOCK]><![endif]--><?php endif; ?><?php if(! $opcion->es_sistema): ?>
                                                <button type="button" onclick="rhModal('<?php echo e(route('admin.catalogos.accion.modal', [$opcion, 'eliminar'])); ?>')" class="btn btn-danger" style="padding:5px 12px; font-size:12px;">Borrar</button>
                                            <?php endif; ?><?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if ENDBLOCK]><![endif]--><?php endif; ?>
                                        </td>
                                    </tr>
                                <?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><?php \Livewire\Features\SupportCompiledWireKeys\SupportCompiledWireKeys::endLoop(); ?><?php endif; ?><?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?><?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if ENDBLOCK]><![endif]--><?php \Livewire\Features\SupportCompiledWireKeys\SupportCompiledWireKeys::closeLoop(); ?><?php endif; ?>
                            </tbody>
                        </table>
                    </div>

                    <div class="mobile-only">
                        <div class="candidate-mobile-list">
                            <?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if BLOCK]><![endif]--><?php \Livewire\Features\SupportCompiledWireKeys\SupportCompiledWireKeys::openLoop(); ?><?php endif; ?><?php $__currentLoopData = $items; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $opcion): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?><?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><?php \Livewire\Features\SupportCompiledWireKeys\SupportCompiledWireKeys::startLoopIteration(); ?><?php endif; ?>
                                <article class="candidate-mobile-card">
                                    <div class="candidate-inline-meta">
                                        <div>
                                            <h3 class="candidate-mobile-card-title"><?php echo e($opcion->valor); ?></h3>
                                            <p class="candidate-mobile-card-subtitle"><?php echo e($opcion->clave); ?></p>
                                        </div>
                                        <?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if BLOCK]><![endif]--><?php endif; ?><?php if($opcion->es_sistema): ?>
                                            <span class="badge badge-gray">Fija</span>
                                        <?php else: ?>
                                            <span class="badge <?php echo e($opcion->activo ? 'badge-green' : 'badge-gray'); ?>"><?php echo e($opcion->activo ? 'Visible' : 'Oculta'); ?></span>
                                        <?php endif; ?><?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if ENDBLOCK]><![endif]--><?php endif; ?>
                                    </div>

                                    <div class="candidate-mobile-meta">
                                        <div>
                                            <p class="candidate-mobile-meta-label">Grupo</p>
                                            <p class="candidate-mobile-meta-value"><?php echo e($grupoLabel); ?></p>
                                        </div>
                                        <div>
                                            <p class="candidate-mobile-meta-label">Descripcion</p>
                                            <p class="candidate-mobile-meta-value"><?php echo e($opcion->descripcion ?: 'Sin descripcion'); ?></p>
                                        </div>
                                    </div>

                                    <div class="candidate-actions" style="margin-top:14px;">
                                        <?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if BLOCK]><![endif]--><?php endif; ?><?php if(! $opcion->es_sistema): ?>
                                            <form method="POST" action="<?php echo e(route('admin.catalogos.toggle', $opcion)); ?>">
                                                <?php echo csrf_field(); ?>
                                                <?php echo method_field('PATCH'); ?>
                                                <button type="submit" class="btn btn-secondary btn-sm"><?php echo e($opcion->activo ? 'Ocultar' : 'Mostrar'); ?></button>
                                            </form>
                                        <?php endif; ?><?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if ENDBLOCK]><![endif]--><?php endif; ?>
                                        <a href="<?php echo e(route('admin.catalogos.edit', $opcion)); ?>" class="btn btn-secondary btn-sm">Editar</a>
                                        <?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if BLOCK]><![endif]--><?php endif; ?><?php if(! $opcion->es_sistema): ?>
                                            <button type="button" onclick="rhModal('<?php echo e(route('admin.catalogos.accion.modal', [$opcion, 'eliminar'])); ?>')" class="btn btn-danger btn-sm">Borrar</button>
                                        <?php endif; ?><?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if ENDBLOCK]><![endif]--><?php endif; ?>
                                    </div>
                                </article>
                            <?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><?php \Livewire\Features\SupportCompiledWireKeys\SupportCompiledWireKeys::endLoop(); ?><?php endif; ?><?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?><?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if ENDBLOCK]><![endif]--><?php \Livewire\Features\SupportCompiledWireKeys\SupportCompiledWireKeys::closeLoop(); ?><?php endif; ?>
                        </div>
                    </div>
                </div>
            <?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><?php \Livewire\Features\SupportCompiledWireKeys\SupportCompiledWireKeys::endLoop(); ?><?php endif; ?><?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?><?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><?php \Livewire\Features\SupportCompiledWireKeys\SupportCompiledWireKeys::closeLoop(); ?><?php endif; ?>
                <div style="text-align:center; padding:60px 20px;">
                    <p style="font-size:1rem; margin:0 0 6px;">No hay opciones que mostrar.</p>
                    <p style="font-size:13px; color:#94a3b8; margin:0 0 16px;">Elige una lista del menu o agrega una nueva opcion.</p>
                </div>
            <?php endif; ?><?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if ENDBLOCK]><![endif]--><?php endif; ?>
        </div>
    <?php endif; ?><?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if ENDBLOCK]><![endif]--><?php endif; ?>
 <?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginal9ac128a9029c0e4701924bd2d73d7f54)): ?>
<?php $attributes = $__attributesOriginal9ac128a9029c0e4701924bd2d73d7f54; ?>
<?php unset($__attributesOriginal9ac128a9029c0e4701924bd2d73d7f54); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal9ac128a9029c0e4701924bd2d73d7f54)): ?>
<?php $component = $__componentOriginal9ac128a9029c0e4701924bd2d73d7f54; ?>
<?php unset($__componentOriginal9ac128a9029c0e4701924bd2d73d7f54); ?>
<?php endif; ?>
<?php /**PATH C:\Dev\Web\SistemaRH_Laravel\resources\views/admin/catalogos/index.blade.php ENDPATH**/ ?>