<?php
    $nivelesEstudios = \App\Models\Vacante::nivelesEstudios();
?>

<?php if (isset($component)) { $__componentOriginal9ac128a9029c0e4701924bd2d73d7f54 = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginal9ac128a9029c0e4701924bd2d73d7f54 = $attributes; } ?>
<?php $component = App\View\Components\AppLayout::resolve([] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('app-layout'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\App\View\Components\AppLayout::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes([]); ?>
<?php \Livewire\Features\SupportCompiledWireKeys\SupportCompiledWireKeys::processComponentKey($component); ?>

     <?php $__env->slot('header', null, []); ?> 
        <nav class="breadcrumbs">
            <a href="<?php echo e(route('admin.dashboard')); ?>">Administracion</a>
            <span class="breadcrumb-sep">&rsaquo;</span>
            <span>Candidatos</span>
        </nav>
        <h1 class="page-title">Aprobaciones de perfil - Candidatos</h1>
        <p class="page-subtitle"><?php echo e($candidatos->total()); ?> candidato(s) registrado(s). Aqui apruebas o rechazas el perfil/CV que envio cada candidato. Esto NO es asignacion de servicios.</p>
     <?php $__env->endSlot(); ?>

    <?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if BLOCK]><![endif]--><?php endif; ?><?php if(session('success')): ?>
        <div style="margin-bottom:16px; padding:12px 16px; background:var(--success-light); color:var(--success); border-radius:8px; border-left:4px solid var(--success);"><?php echo e(session('success')); ?></div>
    <?php endif; ?><?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if ENDBLOCK]><![endif]--><?php endif; ?>
    <?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if BLOCK]><![endif]--><?php endif; ?><?php if(session('error')): ?>
        <div style="margin-bottom:16px; padding:12px 16px; background:var(--danger-light); color:var(--danger); border-radius:8px; border-left:4px solid var(--danger);"><?php echo e(session('error')); ?></div>
    <?php endif; ?><?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if ENDBLOCK]><![endif]--><?php endif; ?>

    <div class="card fade-in" style="margin-bottom:20px;">
        <form method="GET" style="display:grid; grid-template-columns:repeat(auto-fit, minmax(180px, 1fr)); gap:12px; align-items:end;">
            <div style="min-width:0;">
                <label style="font-size:12px; color:var(--text-muted); display:block; margin-bottom:4px;">Buscar</label>
                <input type="text" name="buscar" value="<?php echo e(request('buscar')); ?>" placeholder="Nombre o CURP..." style="width:100%; padding:8px 12px; border:1px solid var(--border); border-radius:8px; font-size:14px; background:var(--surface);" spellcheck="true" autocorrect="on" autocapitalize="sentences" lang="es-MX">
            </div>
            <div style="min-width:0;">
                <label style="font-size:12px; color:var(--text-muted); display:block; margin-bottom:4px;">Estado</label>
                <select name="estado" style="width:100%; padding:8px 12px; border:1px solid var(--border); border-radius:8px; font-size:14px; background:var(--surface);">
                    <option value="">Todos</option>
                    <?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if BLOCK]><![endif]--><?php \Livewire\Features\SupportCompiledWireKeys\SupportCompiledWireKeys::openLoop(); ?><?php endif; ?><?php $__currentLoopData = \App\Models\Candidato::solicitudEstados(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key => $label): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?><?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><?php \Livewire\Features\SupportCompiledWireKeys\SupportCompiledWireKeys::startLoopIteration(); ?><?php endif; ?>
                        <option value="<?php echo e($key); ?>" <?php echo e(request('estado') === $key ? 'selected' : ''); ?>><?php echo e($label); ?></option>
                    <?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><?php \Livewire\Features\SupportCompiledWireKeys\SupportCompiledWireKeys::endLoop(); ?><?php endif; ?><?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?><?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if ENDBLOCK]><![endif]--><?php \Livewire\Features\SupportCompiledWireKeys\SupportCompiledWireKeys::closeLoop(); ?><?php endif; ?>
                </select>
            </div>
            <div style="min-width:0;">
                <label style="font-size:12px; color:var(--text-muted); display:block; margin-bottom:4px;">Estudios</label>
                <select name="estudios" style="width:100%; padding:8px 12px; border:1px solid var(--border); border-radius:8px; font-size:14px; background:var(--surface);">
                    <option value="">Todos</option>
                    <?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if BLOCK]><![endif]--><?php \Livewire\Features\SupportCompiledWireKeys\SupportCompiledWireKeys::openLoop(); ?><?php endif; ?><?php $__currentLoopData = $nivelesEstudios; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key => $label): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?><?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><?php \Livewire\Features\SupportCompiledWireKeys\SupportCompiledWireKeys::startLoopIteration(); ?><?php endif; ?>
                        <option value="<?php echo e($key); ?>" <?php echo e(request('estudios') === $key ? 'selected' : ''); ?>><?php echo e($label); ?></option>
                    <?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><?php \Livewire\Features\SupportCompiledWireKeys\SupportCompiledWireKeys::endLoop(); ?><?php endif; ?><?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?><?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if ENDBLOCK]><![endif]--><?php \Livewire\Features\SupportCompiledWireKeys\SupportCompiledWireKeys::closeLoop(); ?><?php endif; ?>
                </select>
            </div>
            <div style="min-width:0;">
                <label style="font-size:12px; color:var(--text-muted); display:block; margin-bottom:4px;">Experiencia minima</label>
                <input type="number" name="experiencia_min" min="0" value="<?php echo e(request('experiencia_min')); ?>" placeholder="Anios" style="width:100%; padding:8px 12px; border:1px solid var(--border); border-radius:8px; font-size:14px; background:var(--surface);">
            </div>
            <div style="min-width:0;">
                <label style="font-size:12px; color:var(--text-muted); display:block; margin-bottom:4px;">Aspiracion</label>
                <input type="text" name="aspiracion" value="<?php echo e(request('aspiracion')); ?>" placeholder="Puesto deseado..." style="width:100%; padding:8px 12px; border:1px solid var(--border); border-radius:8px; font-size:14px; background:var(--surface);" spellcheck="true" autocorrect="on" autocapitalize="sentences" lang="es-MX">
            </div>
            <div class="toolbar-wrap">
                <button type="submit" class="btn btn-primary">Filtrar</button>
                <?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if BLOCK]><![endif]--><?php endif; ?><?php if(request()->hasAny(['buscar', 'estado', 'estudios', 'experiencia_min', 'aspiracion'])): ?>
                    <a href="<?php echo e(route('admin.candidatos')); ?>" class="btn btn-secondary">Limpiar</a>
                <?php endif; ?><?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if ENDBLOCK]><![endif]--><?php endif; ?>
            </div>
        </form>
    </div>

    <div class="card fade-in">
        <?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if BLOCK]><![endif]--><?php endif; ?><?php if($candidatos->isEmpty()): ?>
            <p class="text-muted text-sm" style="text-align:center; padding:40px 0;">No hay candidatos que coincidan.</p>
        <?php else: ?>
            <div class="desktop-only table-scroll">
                <table style="width:100%; border-collapse:collapse; font-size:14px;">
                    <thead>
                        <tr style="border-bottom:2px solid var(--border);">
                            <th style="text-align:left; padding:10px 12px; color:var(--text-muted); font-weight:500;">Candidato</th>
                            <th style="text-align:left; padding:10px 12px; color:var(--text-muted); font-weight:500;">Contacto</th>
                            <th style="text-align:left; padding:10px 12px; color:var(--text-muted); font-weight:500;">CURP</th>
                            <th style="text-align:left; padding:10px 12px; color:var(--text-muted); font-weight:500;">Solicitud</th>
                            <th style="text-align:left; padding:10px 12px; color:var(--text-muted); font-weight:500;">Enviada</th>
                            <th style="text-align:right; padding:10px 12px; color:var(--text-muted); font-weight:500;">Acciones</th>
                        </tr>
                    </thead>
                    <tbody>
                        <?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if BLOCK]><![endif]--><?php \Livewire\Features\SupportCompiledWireKeys\SupportCompiledWireKeys::openLoop(); ?><?php endif; ?><?php $__currentLoopData = $candidatos; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $candidato): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?><?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><?php \Livewire\Features\SupportCompiledWireKeys\SupportCompiledWireKeys::startLoopIteration(); ?><?php endif; ?>
                            <?php
                                $colors = ['borrador' => 'var(--text-muted)', 'enviada' => 'var(--warning)', 'aprobada' => 'var(--success)', 'rechazada' => 'var(--danger)', 'en_revision' => 'var(--accent)'];
                                $bgs = ['borrador' => 'var(--surface-2)', 'enviada' => 'var(--warning-light)', 'aprobada' => 'var(--success-light)', 'rechazada' => 'var(--danger-light)', 'en_revision' => 'var(--accent-light)'];
                                $estado = $candidato->solicitud_estado ?? 'borrador';
                                $progreso = $candidato->solicitudProgreso();
                            ?>
                            <tr style="border-bottom:1px solid var(--border);">
                                <td style="padding:12px;">
                                    <div style="display:flex; align-items:center; gap:10px;">
                                        <?php if (isset($component)) { $__componentOriginal8ca5b43b8fff8bb34ab2ba4eb4bdd67b = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginal8ca5b43b8fff8bb34ab2ba4eb4bdd67b = $attributes; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.avatar','data' => ['src' => $candidato->usuario?->avatar_url,'nombre' => $candidato->nombre . ' ' . ($candidato->apellido_paterno ?? ''),'tamano' => 36]] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('avatar'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\Illuminate\View\AnonymousComponent::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes(['src' => \Illuminate\View\Compilers\BladeCompiler::sanitizeComponentAttribute($candidato->usuario?->avatar_url),'nombre' => \Illuminate\View\Compilers\BladeCompiler::sanitizeComponentAttribute($candidato->nombre . ' ' . ($candidato->apellido_paterno ?? '')),'tamano' => 36]); ?>
<?php \Livewire\Features\SupportCompiledWireKeys\SupportCompiledWireKeys::processComponentKey($component); ?>

<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginal8ca5b43b8fff8bb34ab2ba4eb4bdd67b)): ?>
<?php $attributes = $__attributesOriginal8ca5b43b8fff8bb34ab2ba4eb4bdd67b; ?>
<?php unset($__attributesOriginal8ca5b43b8fff8bb34ab2ba4eb4bdd67b); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal8ca5b43b8fff8bb34ab2ba4eb4bdd67b)): ?>
<?php $component = $__componentOriginal8ca5b43b8fff8bb34ab2ba4eb4bdd67b; ?>
<?php unset($__componentOriginal8ca5b43b8fff8bb34ab2ba4eb4bdd67b); ?>
<?php endif; ?>
                                        <div>
                                            <p style="font-weight:500; margin:0;"><?php echo e($candidato->nombre); ?> <?php echo e($candidato->apellido_paterno); ?> <?php echo e($candidato->apellido_materno); ?></p>
                                            <p style="font-size:12px; color:var(--text-muted); margin:0;">Aspiracion: <?php echo e($candidato->puesto_deseado ?? 'Sin puesto indicado'); ?></p>
                                            <p style="font-size:12px; color:var(--text-muted); margin:0;">Estudios: <?php echo e(\App\Models\Vacante::nivelEstudiosLabel($candidato->escolaridad)); ?> · Experiencia: <?php echo e((int) ($candidato->experiencia_anios ?? 0)); ?> anio(s)</p>
                                        </div>
                                    </div>
                                </td>
                                <td style="padding:12px;">
                                    <p style="margin:0; font-size:13px;"><?php echo e($candidato->usuario?->email); ?></p>
                                    <p style="margin:0; font-size:12px; color:var(--text-muted);"><?php echo e($candidato->celular ?? $candidato->telefono ?? '—'); ?></p>
                                </td>
                                <td style="padding:12px; color:var(--text-muted); font-size:13px;"><?php echo e($candidato->curp ?? '—'); ?></td>
                                <td style="padding:12px;">
                                    <span style="padding:3px 10px; border-radius:20px; font-size:12px; font-weight:500; background:<?php echo e($bgs[$estado] ?? 'var(--surface-2)'); ?>; color:<?php echo e($colors[$estado] ?? 'var(--text-muted)'); ?>;">
                                        <?php echo e(\App\Models\Candidato::solicitudEstadoLabel($estado)); ?>

                                    </span>
                                    <div style="margin-top:6px; font-size:12px; color:var(--text-muted);">Avance: <?php echo e($progreso); ?>%</div>
                                </td>
                                <td style="padding:12px; color:var(--text-muted); font-size:13px;"><?php echo e($candidato->solicitud_enviada_at?->format('d/m/Y H:i') ?? '—'); ?></td>
                                <td style="padding:12px; text-align:right;">
                                    <div class="toolbar-wrap" style="justify-content:flex-end;">
                                        <button type="button" onclick="rhModal('<?php echo e(route('admin.candidatos.modal', $candidato)); ?>')" title="Ver solicitud" class="btn btn-ghost" style="width:30px; height:30px; padding:0;">
                                            <svg fill="none" viewBox="0 0 24 24" stroke-width="1.5" stroke="currentColor" style="width:15px;height:15px;"><path stroke-linecap="round" stroke-linejoin="round" d="M2.036 12.322a1.012 1.012 0 010-.639C3.423 7.51 7.36 4.5 12 4.5c4.638 0 8.573 3.007 9.963 7.178.07.207.07.431 0 .639C20.577 16.49 16.64 19.5 12 19.5c-4.638 0-8.573-3.007-9.963-7.178z"/><path stroke-linecap="round" stroke-linejoin="round" d="M15 12a3 3 0 11-6 0 3 3 0 016 0z"/></svg>
                                        </button>
                                        <a href="<?php echo e(route('admin.candidatos.solicitud.pdf', $candidato)); ?>" target="_blank" title="Descargar solicitud en PDF" class="btn btn-ghost" style="width:30px; height:30px; padding:0; display:inline-flex; align-items:center; justify-content:center;">PDF</a>
                                        <?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if BLOCK]><![endif]--><?php endif; ?><?php if($candidato->solicitud_estado === 'enviada'): ?>
                                            <form method="POST" action="<?php echo e(route('admin.candidatos.aprobar', $candidato)); ?>">
                                                <?php echo csrf_field(); ?>
                                                <?php echo method_field('PATCH'); ?>
                                                <button type="submit" class="btn btn-success btn-sm">Aprobar</button>
                                            </form>
                                            <button type="button" onclick="rhModal('<?php echo e(route('admin.candidatos.accion.modal', [$candidato, 'rechazar'])); ?>')" class="btn btn-danger btn-sm">Rechazar</button>
                                        <?php elseif($candidato->solicitud_estado === 'rechazada'): ?>
                                            <form method="POST" action="<?php echo e(route('admin.candidatos.aprobar', $candidato)); ?>">
                                                <?php echo csrf_field(); ?>
                                                <?php echo method_field('PATCH'); ?>
                                                <button type="submit" class="btn btn-success btn-sm">Reactivar</button>
                                            </form>
                                        <?php endif; ?><?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if ENDBLOCK]><![endif]--><?php endif; ?>
                                        <button type="button" onclick="rhModal('<?php echo e(route('admin.candidatos.accion.modal', [$candidato, 'eliminar'])); ?>')" class="btn btn-danger" style="width:30px; height:30px; padding:0;" title="Eliminar">
                                            <svg fill="none" viewBox="0 0 24 24" stroke-width="1.5" stroke="currentColor" style="width:15px;height:15px;"><path stroke-linecap="round" stroke-linejoin="round" d="M14.74 9l-.346 9m-4.788 0L9.26 9m9.968-3.21c.342.052.682.107 1.022.166m-1.022-.165L18.16 19.673a2.25 2.25 0 01-2.244 2.077H8.084a2.25 2.25 0 01-2.244-2.077L4.772 5.79m14.456 0a48.108 48.108 0 00-3.478-.397M4.772 5.79c.342-.052.682-.107 1.022-.166m1.022.165l.346 9"/></svg>
                                        </button>
                                    </div>
                                </td>
                            </tr>
                        <?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><?php \Livewire\Features\SupportCompiledWireKeys\SupportCompiledWireKeys::endLoop(); ?><?php endif; ?><?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?><?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if ENDBLOCK]><![endif]--><?php \Livewire\Features\SupportCompiledWireKeys\SupportCompiledWireKeys::closeLoop(); ?><?php endif; ?>
                    </tbody>
                </table>
            </div>

            <div class="mobile-only">
                <div class="candidate-mobile-list">
                    <?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if BLOCK]><![endif]--><?php \Livewire\Features\SupportCompiledWireKeys\SupportCompiledWireKeys::openLoop(); ?><?php endif; ?><?php $__currentLoopData = $candidatos; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $candidato): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?><?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><?php \Livewire\Features\SupportCompiledWireKeys\SupportCompiledWireKeys::startLoopIteration(); ?><?php endif; ?>
                        <?php
                            $colors = ['borrador' => 'var(--text-muted)', 'enviada' => 'var(--warning)', 'aprobada' => 'var(--success)', 'rechazada' => 'var(--danger)', 'en_revision' => 'var(--accent)'];
                            $bgs = ['borrador' => 'var(--surface-2)', 'enviada' => 'var(--warning-light)', 'aprobada' => 'var(--success-light)', 'rechazada' => 'var(--danger-light)', 'en_revision' => 'var(--accent-light)'];
                            $estado = $candidato->solicitud_estado ?? 'borrador';
                            $progreso = $candidato->solicitudProgreso();
                        ?>
                        <article class="candidate-mobile-card">
                            <div class="candidate-inline-meta">
                                <div style="display:flex; align-items:center; gap:10px; min-width:0;">
                                    <?php if (isset($component)) { $__componentOriginal8ca5b43b8fff8bb34ab2ba4eb4bdd67b = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginal8ca5b43b8fff8bb34ab2ba4eb4bdd67b = $attributes; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.avatar','data' => ['src' => $candidato->usuario?->avatar_url,'nombre' => $candidato->nombre . ' ' . ($candidato->apellido_paterno ?? ''),'tamano' => 40]] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('avatar'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\Illuminate\View\AnonymousComponent::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes(['src' => \Illuminate\View\Compilers\BladeCompiler::sanitizeComponentAttribute($candidato->usuario?->avatar_url),'nombre' => \Illuminate\View\Compilers\BladeCompiler::sanitizeComponentAttribute($candidato->nombre . ' ' . ($candidato->apellido_paterno ?? '')),'tamano' => 40]); ?>
<?php \Livewire\Features\SupportCompiledWireKeys\SupportCompiledWireKeys::processComponentKey($component); ?>

<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginal8ca5b43b8fff8bb34ab2ba4eb4bdd67b)): ?>
<?php $attributes = $__attributesOriginal8ca5b43b8fff8bb34ab2ba4eb4bdd67b; ?>
<?php unset($__attributesOriginal8ca5b43b8fff8bb34ab2ba4eb4bdd67b); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal8ca5b43b8fff8bb34ab2ba4eb4bdd67b)): ?>
<?php $component = $__componentOriginal8ca5b43b8fff8bb34ab2ba4eb4bdd67b; ?>
<?php unset($__componentOriginal8ca5b43b8fff8bb34ab2ba4eb4bdd67b); ?>
<?php endif; ?>
                                    <div style="min-width:0;">
                                        <h3 class="candidate-mobile-card-title"><?php echo e($candidato->nombre); ?> <?php echo e($candidato->apellido_paterno); ?> <?php echo e($candidato->apellido_materno); ?></h3>
                                        <p class="candidate-mobile-card-subtitle"><?php echo e($candidato->puesto_deseado ?: 'Sin puesto indicado'); ?></p>
                                    </div>
                                </div>
                                <span style="padding:3px 10px; border-radius:20px; font-size:12px; font-weight:500; background:<?php echo e($bgs[$estado] ?? 'var(--surface-2)'); ?>; color:<?php echo e($colors[$estado] ?? 'var(--text-muted)'); ?>;">
                                    <?php echo e(\App\Models\Candidato::solicitudEstadoLabel($estado)); ?>

                                </span>
                            </div>

                            <div class="candidate-mobile-meta">
                                <div>
                                    <p class="candidate-mobile-meta-label">Contacto</p>
                                    <p class="candidate-mobile-meta-value"><?php echo e($candidato->usuario?->email ?? '—'); ?></p>
                                </div>
                                <div>
                                    <p class="candidate-mobile-meta-label">Telefono</p>
                                    <p class="candidate-mobile-meta-value"><?php echo e($candidato->celular ?? $candidato->telefono ?? '—'); ?></p>
                                </div>
                                <div>
                                    <p class="candidate-mobile-meta-label">CURP</p>
                                    <p class="candidate-mobile-meta-value"><?php echo e($candidato->curp ?? '—'); ?></p>
                                </div>
                                <div>
                                    <p class="candidate-mobile-meta-label">Avance</p>
                                    <p class="candidate-mobile-meta-value"><?php echo e($progreso); ?>%</p>
                                </div>
                                <div>
                                    <p class="candidate-mobile-meta-label">Enviada</p>
                                    <p class="candidate-mobile-meta-value"><?php echo e($candidato->solicitud_enviada_at?->format('d/m/Y H:i') ?? '—'); ?></p>
                                </div>
                            </div>

                            <div class="candidate-actions" style="margin-top:14px;">
                                <button type="button" onclick="rhModal('<?php echo e(route('admin.candidatos.modal', $candidato)); ?>')" class="btn btn-secondary btn-sm">Ver</button>
                                <a href="<?php echo e(route('admin.candidatos.solicitud.pdf', $candidato)); ?>" target="_blank" class="btn btn-secondary btn-sm">PDF</a>
                                <?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if BLOCK]><![endif]--><?php endif; ?><?php if($candidato->solicitud_estado === 'enviada'): ?>
                                    <form method="POST" action="<?php echo e(route('admin.candidatos.aprobar', $candidato)); ?>">
                                        <?php echo csrf_field(); ?>
                                        <?php echo method_field('PATCH'); ?>
                                        <button type="submit" class="btn btn-success btn-sm">Aprobar</button>
                                    </form>
                                    <button type="button" onclick="rhModal('<?php echo e(route('admin.candidatos.accion.modal', [$candidato, 'rechazar'])); ?>')" class="btn btn-danger btn-sm">Rechazar</button>
                                <?php elseif($candidato->solicitud_estado === 'rechazada'): ?>
                                    <form method="POST" action="<?php echo e(route('admin.candidatos.aprobar', $candidato)); ?>">
                                        <?php echo csrf_field(); ?>
                                        <?php echo method_field('PATCH'); ?>
                                        <button type="submit" class="btn btn-success btn-sm">Reactivar</button>
                                    </form>
                                <?php endif; ?><?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if ENDBLOCK]><![endif]--><?php endif; ?>
                                <button type="button" onclick="rhModal('<?php echo e(route('admin.candidatos.accion.modal', [$candidato, 'eliminar'])); ?>')" class="btn btn-danger btn-sm">Eliminar</button>
                            </div>
                        </article>
                    <?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><?php \Livewire\Features\SupportCompiledWireKeys\SupportCompiledWireKeys::endLoop(); ?><?php endif; ?><?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?><?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if ENDBLOCK]><![endif]--><?php \Livewire\Features\SupportCompiledWireKeys\SupportCompiledWireKeys::closeLoop(); ?><?php endif; ?>
                </div>
            </div>

            <div style="margin-top:16px;">
                <?php echo e($candidatos->links()); ?>

            </div>
        <?php endif; ?><?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if ENDBLOCK]><![endif]--><?php endif; ?>
    </div>
 <?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginal9ac128a9029c0e4701924bd2d73d7f54)): ?>
<?php $attributes = $__attributesOriginal9ac128a9029c0e4701924bd2d73d7f54; ?>
<?php unset($__attributesOriginal9ac128a9029c0e4701924bd2d73d7f54); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal9ac128a9029c0e4701924bd2d73d7f54)): ?>
<?php $component = $__componentOriginal9ac128a9029c0e4701924bd2d73d7f54; ?>
<?php unset($__componentOriginal9ac128a9029c0e4701924bd2d73d7f54); ?>
<?php endif; ?>
<?php /**PATH C:\Dev\Web\SistemaRH_Laravel\resources\views/admin/candidatos/index.blade.php ENDPATH**/ ?>