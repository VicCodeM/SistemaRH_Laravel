
<div style="font-family:inherit;">

    
    <div class="modal-header">
        <div style="display:flex;align-items:center;gap:12px;">
            <?php if (isset($component)) { $__componentOriginal8ca5b43b8fff8bb34ab2ba4eb4bdd67b = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginal8ca5b43b8fff8bb34ab2ba4eb4bdd67b = $attributes; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.avatar','data' => ['src' => $candidato->usuario?->avatar_url,'nombre' => $candidato->nombre . ' ' . ($candidato->apellido_paterno ?? ''),'tamano' => 48]] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('avatar'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\Illuminate\View\AnonymousComponent::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes(['src' => \Illuminate\View\Compilers\BladeCompiler::sanitizeComponentAttribute($candidato->usuario?->avatar_url),'nombre' => \Illuminate\View\Compilers\BladeCompiler::sanitizeComponentAttribute($candidato->nombre . ' ' . ($candidato->apellido_paterno ?? '')),'tamano' => 48]); ?>
<?php \Livewire\Features\SupportCompiledWireKeys\SupportCompiledWireKeys::processComponentKey($component); ?>

<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginal8ca5b43b8fff8bb34ab2ba4eb4bdd67b)): ?>
<?php $attributes = $__attributesOriginal8ca5b43b8fff8bb34ab2ba4eb4bdd67b; ?>
<?php unset($__attributesOriginal8ca5b43b8fff8bb34ab2ba4eb4bdd67b); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal8ca5b43b8fff8bb34ab2ba4eb4bdd67b)): ?>
<?php $component = $__componentOriginal8ca5b43b8fff8bb34ab2ba4eb4bdd67b; ?>
<?php unset($__componentOriginal8ca5b43b8fff8bb34ab2ba4eb4bdd67b); ?>
<?php endif; ?>
            <div>
                <h2 class="modal-title"><?php echo e($candidato->nombre); ?> <?php echo e($candidato->apellido_paterno); ?> <?php echo e($candidato->apellido_materno); ?></h2>
                <span class="modal-subtitle"><?php echo e($candidato->puesto_deseado ?: 'Sin puesto indicado'); ?></span>
            </div>
        </div>
        <div style="display:flex;align-items:center;gap:8px;">
            <span class="badge <?php echo e(\App\Models\Candidato::solicitudEstadoBadgeClass($candidato->solicitud_estado)); ?>" style="font-size:12px;">
                <?php echo e(\App\Models\Candidato::solicitudEstadoLabel($candidato->solicitud_estado)); ?>

            </span>
            <span class="badge badge-blue" style="font-size:12px;"><?php echo e($candidato->solicitudProgreso()); ?>%</span>
            <button onclick="rhModalClose()" class="modal-close">&times;</button>
        </div>
    </div>

    
    <div style="padding:16px 28px 0;border-bottom:1px solid var(--border);display:flex;gap:4px;flex-wrap:wrap;" id="cand-tabs">
        <button onclick="showTab('tab-personal')" id="btn-personal" class="modal-tab active">Datos personales</button>
        <button onclick="showTab('tab-laboral')" id="btn-laboral" class="modal-tab">Perfil laboral</button>
        <button onclick="showTab('tab-proceso')" id="btn-proceso" class="modal-tab">En proceso</button>
    </div>

    <div class="modal-body">
        
        <div class="modal-progress-bar" style="margin-bottom:18px;">
            <div>
                <div style="font-size:11px;color:var(--text-muted);text-transform:uppercase;letter-spacing:.5px;">Avance de la solicitud</div>
                <div style="font-size:13px;color:var(--text-primary);font-weight:600;"><?php echo e($candidato->solicitudProgreso()); ?>% completado</div>
            </div>
            <div style="display:flex; gap:6px; flex-wrap:wrap;">
                <a href="<?php echo e(route('admin.candidatos.solicitud.pdf', $candidato)); ?>" target="_blank" class="btn btn-secondary btn-sm" title="Descargar la solicitud completa en PDF">📄 PDF</a>
                <a href="<?php echo e(route('admin.candidatos.solicitud', $candidato)); ?>" class="btn btn-primary btn-sm">Editar solicitud</a>
            </div>
        </div>

        
        <div id="tab-personal">
            <div class="modal-grid-2">
                <?php
                    $campos = [
                        'Correo' => $candidato->usuario?->email, 'Teléfono' => $candidato->celular ?: $candidato->telefono,
                        'CURP' => $candidato->curp, 'RFC' => $candidato->rfc,
                        'Edad' => $candidato->edad ? $candidato->edad.' años' : null, 'Sexo' => $candidato->sexo ? ucfirst($candidato->sexo) : null,
                        'Estado civil' => $candidato->estado_civil ? ucfirst($candidato->estado_civil) : null, 'Ciudad' => $candidato->ciudad,
                        'Municipio' => $candidato->municipio, 'Escolaridad' => $candidato->escolaridad ? ucfirst($candidato->escolaridad) : null,
                    ];
                ?>
                <?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if BLOCK]><![endif]--><?php \Livewire\Features\SupportCompiledWireKeys\SupportCompiledWireKeys::openLoop(); ?><?php endif; ?><?php $__currentLoopData = $campos; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $label => $valor): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?><?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><?php \Livewire\Features\SupportCompiledWireKeys\SupportCompiledWireKeys::startLoopIteration(); ?><?php endif; ?>
                    <div>
                        <p class="modal-field-label"><?php echo e($label); ?></p>
                        <p class="modal-field-value"><?php echo e($valor ?: '—'); ?></p>
                    </div>
                <?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><?php \Livewire\Features\SupportCompiledWireKeys\SupportCompiledWireKeys::endLoop(); ?><?php endif; ?><?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?><?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if ENDBLOCK]><![endif]--><?php \Livewire\Features\SupportCompiledWireKeys\SupportCompiledWireKeys::closeLoop(); ?><?php endif; ?>
            </div>
        </div>

        
        <div id="tab-laboral" style="display:none;">
            <div class="modal-grid-2" style="margin-bottom:16px;">
                <div><p class="modal-field-label">Puesto deseado</p><p class="modal-field-value"><?php echo e($candidato->puesto_deseado ?: '—'); ?></p></div>
                <div><p class="modal-field-label">Experiencia</p><p class="modal-field-value"><?php echo e($candidato->experiencia_anios ? $candidato->experiencia_anios.' año(s)' : '—'); ?></p></div>
                <div><p class="modal-field-label">Sueldo deseado</p><p class="modal-field-value"><?php echo e($candidato->sueldo_deseado ? '$'.number_format($candidato->sueldo_deseado, 0).' MXN' : '—'); ?></p></div>
                <div>
                    <p class="modal-field-label">CV</p>
                    <?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if BLOCK]><![endif]--><?php endif; ?><?php if($candidato->cv_path): ?>
                        <a href="<?php echo e(Storage::url($candidato->cv_path)); ?>" target="_blank" style="font-size:13px;color:var(--accent);">Descargar CV</a>
                    <?php else: ?>
                        <p style="font-size:13px;color:var(--text-muted);margin:0;">Sin CV adjunto</p>
                    <?php endif; ?><?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if ENDBLOCK]><![endif]--><?php endif; ?>
                </div>
            </div>
            <?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if BLOCK]><![endif]--><?php endif; ?><?php if($candidato->habilidades): ?>
                <div><p class="modal-field-label">Habilidades</p><p class="modal-field-value" style="line-height:1.6;"><?php echo e($candidato->habilidades); ?></p></div>
            <?php endif; ?><?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if ENDBLOCK]><![endif]--><?php endif; ?>
        </div>

        
        <div id="tab-proceso" style="display:none;">
            <?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if BLOCK]><![endif]--><?php \Livewire\Features\SupportCompiledWireKeys\SupportCompiledWireKeys::openLoop(); ?><?php endif; ?><?php $__empty_1 = true; $__currentLoopData = $candidato->postulaciones; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $postulacion): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?><?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><?php \Livewire\Features\SupportCompiledWireKeys\SupportCompiledWireKeys::startLoopIteration(); ?><?php endif; ?>
                <div class="modal-list-item">
                    <div>
                        <p class="modal-list-item-title" style="margin:0;"><?php echo e($postulacion->vacante?->titulo ?? '—'); ?></p>
                        <p class="modal-list-item-sub" style="margin:0;"><?php echo e($postulacion->vacante?->empresa?->nombre_empresa ?? '—'); ?></p>
                    </div>
                    <span class="badge badge-gray" style="font-size:11px;"><?php echo e(\App\Models\Postulacion::estadoLabel($postulacion->estado)); ?></span>
                </div>
            <?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><?php \Livewire\Features\SupportCompiledWireKeys\SupportCompiledWireKeys::endLoop(); ?><?php endif; ?><?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?><?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><?php \Livewire\Features\SupportCompiledWireKeys\SupportCompiledWireKeys::closeLoop(); ?><?php endif; ?>
                <p style="text-align:center;color:var(--text-muted);padding:32px 0;font-size:13px;">Sin procesos activos</p>
            <?php endif; ?><?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if ENDBLOCK]><![endif]--><?php endif; ?>
        </div>
    </div>

    
    <div class="modal-footer modal-actions-wrap" style="border-top:1px solid var(--border);padding-top:20px;">
        <?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if BLOCK]><![endif]--><?php endif; ?><?php if($candidato->solicitud_estado === 'enviada'): ?>
            <form method="POST" action="<?php echo e(route('admin.candidatos.aprobar', $candidato)); ?>" style="margin:0;"><?php echo csrf_field(); ?> <?php echo method_field('PATCH'); ?>
                <button type="submit" onclick="rhModalClose()" class="btn btn-success">✓ Aprobar solicitud</button>
            </form>
            <form method="POST" action="<?php echo e(route('admin.candidatos.rechazar', $candidato)); ?>" style="margin:0;"><?php echo csrf_field(); ?> <?php echo method_field('PATCH'); ?>
                <button type="submit" onclick="rhModalClose()" class="btn btn-danger">✗ Rechazar</button>
            </form>
            <a href="<?php echo e(route('admin.candidatos.solicitud', $candidato)); ?>" class="btn btn-ghost">Editar solicitud</a>
        <?php elseif($candidato->solicitud_estado === 'rechazada'): ?>
            <form method="POST" action="<?php echo e(route('admin.candidatos.aprobar', $candidato)); ?>" style="margin:0;"><?php echo csrf_field(); ?> <?php echo method_field('PATCH'); ?>
                <button type="submit" onclick="rhModalClose()" class="btn btn-success">Reactivar candidato</button>
            </form>
        <?php endif; ?><?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if ENDBLOCK]><![endif]--><?php endif; ?>
        <button onclick="rhModalClose()" class="btn btn-ghost">Cerrar</button>
    </div>
</div>

<script>
function showTab(id) {
    ['tab-personal','tab-laboral','tab-proceso'].forEach(t => {
        document.getElementById(t).style.display = t === id ? 'block' : 'none';
    });
    document.querySelectorAll('#cand-tabs .modal-tab').forEach(btn => {
        const active = btn.id === 'btn-' + id.replace('tab-','');
        btn.classList.toggle('active', active);
    });
}
</script>
<?php /**PATH C:\Dev\Web\SistemaRH_Laravel\resources\views/admin/candidatos/modal.blade.php ENDPATH**/ ?>