<div class="chat-fab-wrap" data-noleidos="<?php echo e($noLeidosTotal); ?>"
    data-estado="<?php echo e($abierto && $conv ? 'conv' : ($abierto ? 'lista' : 'cerrado')); ?>">
    
    <button type="button" class="chat-fab <?php echo e($abierto ? 'abierto' : ''); ?> <?php echo e((!$abierto && $noLeidosTotal > 0) ? 'tiene-nuevos' : ''); ?>" wire:click="toggle" title="Mensajes">
        <?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if BLOCK]><![endif]--><?php endif; ?><?php if($abierto): ?>
            <svg width="24" height="24" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><path d="M18 6L6 18M6 6l12 12"/></svg>
        <?php else: ?>
            <svg width="24" height="24" fill="none" viewBox="0 0 24 24" stroke-width="1.8" stroke="currentColor"><path stroke-linecap="round" stroke-linejoin="round" d="M20.25 8.511c.884.284 1.5 1.128 1.5 2.097v4.286c0 1.136-.847 2.1-1.98 2.193-.34.027-.68.052-1.02.072v3.091l-3-3c-1.354 0-2.694-.055-4.02-.163a2.115 2.115 0 0 1-.825-.242m9.345-8.334a2.126 2.126 0 0 0-.476-.095 48.64 48.64 0 0 0-8.048 0c-1.131.094-1.976 1.057-1.976 2.192v4.286c0 .837.46 1.58 1.155 1.951m9.345-8.334V6.637c0-1.621-1.152-3.026-2.76-3.235A48.455 48.455 0 0 0 11.25 3c-2.115 0-4.198.137-6.24.402-1.608.209-2.76 1.614-2.76 3.235v6.226c0 1.621 1.152 3.026 2.76 3.235.577.075 1.157.14 1.74.194V21l4.155-4.155"/></svg>
            <?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if BLOCK]><![endif]--><?php endif; ?><?php if($noLeidosTotal > 0): ?>
                <span class="chat-fab-badge"><?php echo e($noLeidosTotal > 99 ? '99+' : $noLeidosTotal); ?></span>
            <?php endif; ?><?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if ENDBLOCK]><![endif]--><?php endif; ?>
        <?php endif; ?><?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if ENDBLOCK]><![endif]--><?php endif; ?>
    </button>

    <?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if BLOCK]><![endif]--><?php endif; ?><?php if($abierto): ?>
        <div class="chat-fab-panel">
            <?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if BLOCK]><![endif]--><?php endif; ?><?php if($conv): ?>
                <?php $room = $conv['room']; $mensajes = $conv['mensajes']; $otro = $conv['otro']; ?>

                
                <div class="chat-fab-header">
                    <button type="button" wire:click="volver" class="chat-fab-back" title="Volver">
                        <svg width="20" height="20" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><path d="M15 18l-6-6 6-6"/></svg>
                    </button>
                    <?php if (isset($component)) { $__componentOriginal8ca5b43b8fff8bb34ab2ba4eb4bdd67b = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginal8ca5b43b8fff8bb34ab2ba4eb4bdd67b = $attributes; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.avatar','data' => ['src' => $otro['usuario']?->avatar_url,'nombre' => $otro['usuario']?->name ?? ($room->nombre ?? 'Chat'),'tamano' => 34]] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('avatar'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\Illuminate\View\AnonymousComponent::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes(['src' => \Illuminate\View\Compilers\BladeCompiler::sanitizeComponentAttribute($otro['usuario']?->avatar_url),'nombre' => \Illuminate\View\Compilers\BladeCompiler::sanitizeComponentAttribute($otro['usuario']?->name ?? ($room->nombre ?? 'Chat')),'tamano' => 34]); ?>
<?php \Livewire\Features\SupportCompiledWireKeys\SupportCompiledWireKeys::processComponentKey($component); ?>

<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginal8ca5b43b8fff8bb34ab2ba4eb4bdd67b)): ?>
<?php $attributes = $__attributesOriginal8ca5b43b8fff8bb34ab2ba4eb4bdd67b; ?>
<?php unset($__attributesOriginal8ca5b43b8fff8bb34ab2ba4eb4bdd67b); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal8ca5b43b8fff8bb34ab2ba4eb4bdd67b)): ?>
<?php $component = $__componentOriginal8ca5b43b8fff8bb34ab2ba4eb4bdd67b; ?>
<?php unset($__componentOriginal8ca5b43b8fff8bb34ab2ba4eb4bdd67b); ?>
<?php endif; ?>
                    <div class="chat-fab-htext">
                        <p class="chat-fab-name"><?php echo e($otro['usuario']?->name ?? ($room->nombre ?? 'Chat')); ?></p>
                        <p class="chat-fab-status">
                            <?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if BLOCK]><![endif]--><?php endif; ?><?php if($otro['escribiendo']): ?>
                                <span class="chat-typing-label">escribiendo…</span>
                            <?php elseif($otro['enLinea']): ?>
                                <span class="status-dot"></span> en línea
                            <?php elseif($otro['ultimaVez']): ?>
                                <span class="status-dot offline"></span> <?php echo e($otro['ultimaVez']); ?>

                            <?php elseif($otro['usuario']): ?>
                                <?php echo e(ucfirst($otro['usuario']->rol)); ?>

                            <?php endif; ?><?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if ENDBLOCK]><![endif]--><?php endif; ?>
                        </p>
                    </div>
                    <button type="button" wire:click="toggle" class="chat-fab-close" title="Cerrar">&times;</button>
                </div>

                
                <div id="fab-mensajes" class="chat-fab-mensajes">
                    <?php $fechaAnterior = null; $emisorAnterior = null; ?>
                    <?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if BLOCK]><![endif]--><?php \Livewire\Features\SupportCompiledWireKeys\SupportCompiledWireKeys::openLoop(); ?><?php endif; ?><?php $__empty_1 = true; $__currentLoopData = $mensajes; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $msg): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?><?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><?php \Livewire\Features\SupportCompiledWireKeys\SupportCompiledWireKeys::startLoopIteration(); ?><?php endif; ?>
                        <?php
                            $esMio = $msg->sender_user_id === auth()->id();
                            $fechaMsg = $msg->created_at->startOfDay();
                            $mismoEmisor = ($emisorAnterior === $msg->sender_user_id);
                            $leido = $otro['leyoHasta'] >= $msg->id;
                            $puedeBorrar = $esMio || auth()->user()->esAdmin();
                        ?>

                        <?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if BLOCK]><![endif]--><?php endif; ?><?php if($fechaAnterior === null || !$fechaAnterior->equalTo($fechaMsg)): ?>
                            <?php $fechaAnterior = $fechaMsg; $emisorAnterior = null; $mismoEmisor = false; ?>
                            <div class="chat-date-separator"><span>
                                <?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if BLOCK]><![endif]--><?php endif; ?><?php if($fechaMsg->isToday()): ?> Hoy
                                <?php elseif($fechaMsg->isYesterday()): ?> Ayer
                                <?php else: ?> <?php echo e($fechaMsg->translatedFormat('d \d\e F')); ?>

                                <?php endif; ?><?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if ENDBLOCK]><![endif]--><?php endif; ?>
                            </span></div>
                        <?php endif; ?><?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if ENDBLOCK]><![endif]--><?php endif; ?>

                        <div class="chat-bubble-wrap <?php echo e($esMio ? 'mine' : 'theirs'); ?>">
                            <?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if BLOCK]><![endif]--><?php endif; ?><?php if(!$esMio): ?>
                                <?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if BLOCK]><![endif]--><?php endif; ?><?php if($mismoEmisor): ?>
                                    <span class="chat-bubble-av-spacer" style="width:26px;"></span>
                                <?php else: ?>
                                    <?php if (isset($component)) { $__componentOriginal8ca5b43b8fff8bb34ab2ba4eb4bdd67b = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginal8ca5b43b8fff8bb34ab2ba4eb4bdd67b = $attributes; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.avatar','data' => ['src' => $msg->sender?->avatar_url,'nombre' => $msg->sender?->name ?? 'Usuario','tamano' => 26,'class' => 'chat-bubble-av']] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('avatar'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\Illuminate\View\AnonymousComponent::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes(['src' => \Illuminate\View\Compilers\BladeCompiler::sanitizeComponentAttribute($msg->sender?->avatar_url),'nombre' => \Illuminate\View\Compilers\BladeCompiler::sanitizeComponentAttribute($msg->sender?->name ?? 'Usuario'),'tamano' => 26,'class' => 'chat-bubble-av']); ?>
<?php \Livewire\Features\SupportCompiledWireKeys\SupportCompiledWireKeys::processComponentKey($component); ?>

<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginal8ca5b43b8fff8bb34ab2ba4eb4bdd67b)): ?>
<?php $attributes = $__attributesOriginal8ca5b43b8fff8bb34ab2ba4eb4bdd67b; ?>
<?php unset($__attributesOriginal8ca5b43b8fff8bb34ab2ba4eb4bdd67b); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal8ca5b43b8fff8bb34ab2ba4eb4bdd67b)): ?>
<?php $component = $__componentOriginal8ca5b43b8fff8bb34ab2ba4eb4bdd67b; ?>
<?php unset($__componentOriginal8ca5b43b8fff8bb34ab2ba4eb4bdd67b); ?>
<?php endif; ?>
                                <?php endif; ?><?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if ENDBLOCK]><![endif]--><?php endif; ?>
                            <?php endif; ?><?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if ENDBLOCK]><![endif]--><?php endif; ?>
                            <div class="chat-bubble">
                                <div class="chat-bubble-text"><?php echo e($msg->contenido); ?></div>
                                <div class="chat-bubble-time">
                                    <?php echo e($msg->created_at->format('H:i')); ?>

                                    <?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if BLOCK]><![endif]--><?php endif; ?><?php if($esMio): ?>
                                        <span class="chat-ticks <?php echo e($leido ? 'leido' : ''); ?>">
                                            <svg viewBox="0 0 16 11" width="15" height="10" fill="none" stroke="currentColor" stroke-width="1.5" stroke-linecap="round" stroke-linejoin="round"><path d="M1 6.2 3.6 8.8 8.1 3.2"/><path d="M6.4 8.8 10.9 3.2"/></svg>
                                        </span>
                                    <?php endif; ?><?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if ENDBLOCK]><![endif]--><?php endif; ?>
                                </div>
                                <?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if BLOCK]><![endif]--><?php endif; ?><?php if($puedeBorrar): ?>
                                    <div class="chat-msg-actions">
                                        <button type="button" wire:click="eliminarMensaje(<?php echo e($msg->id); ?>)" wire:confirm="¿Eliminar este mensaje?" title="Eliminar">×</button>
                                    </div>
                                <?php endif; ?><?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if ENDBLOCK]><![endif]--><?php endif; ?>
                            </div>
                        </div>

                        <?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if BLOCK]><![endif]--><?php endif; ?><?php if($loop->last && $esMio && $leido): ?>
                            <div class="chat-visto">Visto</div>
                        <?php endif; ?><?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if ENDBLOCK]><![endif]--><?php endif; ?>

                        <?php $emisorAnterior = $msg->sender_user_id; ?>
                    <?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><?php \Livewire\Features\SupportCompiledWireKeys\SupportCompiledWireKeys::endLoop(); ?><?php endif; ?><?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?><?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><?php \Livewire\Features\SupportCompiledWireKeys\SupportCompiledWireKeys::closeLoop(); ?><?php endif; ?>
                        <div style="flex:1; display:flex; align-items:center; justify-content:center; text-align:center;">
                            <p style="color:var(--text-muted); font-size:13px;">Sé el primero en escribir</p>
                        </div>
                    <?php endif; ?><?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if ENDBLOCK]><![endif]--><?php endif; ?>

                    <?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if BLOCK]><![endif]--><?php endif; ?><?php if($otro['escribiendo']): ?>
                        <div class="chat-typing-wrap">
                            <?php if (isset($component)) { $__componentOriginal8ca5b43b8fff8bb34ab2ba4eb4bdd67b = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginal8ca5b43b8fff8bb34ab2ba4eb4bdd67b = $attributes; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.avatar','data' => ['src' => $otro['usuario']?->avatar_url,'nombre' => $otro['usuario']?->name ?? 'Usuario','tamano' => 26,'class' => 'chat-bubble-av']] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('avatar'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\Illuminate\View\AnonymousComponent::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes(['src' => \Illuminate\View\Compilers\BladeCompiler::sanitizeComponentAttribute($otro['usuario']?->avatar_url),'nombre' => \Illuminate\View\Compilers\BladeCompiler::sanitizeComponentAttribute($otro['usuario']?->name ?? 'Usuario'),'tamano' => 26,'class' => 'chat-bubble-av']); ?>
<?php \Livewire\Features\SupportCompiledWireKeys\SupportCompiledWireKeys::processComponentKey($component); ?>

<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginal8ca5b43b8fff8bb34ab2ba4eb4bdd67b)): ?>
<?php $attributes = $__attributesOriginal8ca5b43b8fff8bb34ab2ba4eb4bdd67b; ?>
<?php unset($__attributesOriginal8ca5b43b8fff8bb34ab2ba4eb4bdd67b); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal8ca5b43b8fff8bb34ab2ba4eb4bdd67b)): ?>
<?php $component = $__componentOriginal8ca5b43b8fff8bb34ab2ba4eb4bdd67b; ?>
<?php unset($__componentOriginal8ca5b43b8fff8bb34ab2ba4eb4bdd67b); ?>
<?php endif; ?>
                            <div class="chat-typing-bubble"><span></span><span></span><span></span></div>
                        </div>
                    <?php endif; ?><?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if ENDBLOCK]><![endif]--><?php endif; ?>
                </div>

                
                <div class="chat-input-area">
                    <form id="fab-form" wire:submit="enviar" class="chat-input-form">
                        <textarea id="fab-textarea" wire:model="mensaje" rows="1" autocomplete="off"
                            placeholder="Escribe un mensaje..." class="chat-input-textarea" spellcheck="true" autocorrect="on" autocapitalize="sentences" lang="es-MX"></textarea>
                        <button type="submit" class="chat-input-btn" title="Enviar">
                            <svg width="18" height="18" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><path d="M22 2 11 13M22 2l-7 20-4-9-9-4 20-7z"/></svg>
                        </button>
                    </form>
                </div>
            <?php else: ?>
                
                <div class="chat-fab-header">
                    <span class="chat-fab-title">Mensajes</span>
                    <button type="button" wire:click="toggle" class="chat-fab-close" title="Cerrar">&times;</button>
                </div>

                <div class="chat-fab-mensajes chat-fab-lista">
                    
                    <?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if BLOCK]><![endif]--><?php endif; ?><?php if(auth()->user()->esAdmin()): ?>
                        <div class="chat-new-top">
                            <button type="button" wire:click="$toggle('mostrarNuevos')" class="chat-new-toggle <?php echo e($mostrarNuevos ? 'abierto' : ''); ?>">
                                <span><span class="chat-new-plus">＋</span> Nueva conversación</span>
                                <svg width="16" height="16" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" style="transition:transform .2s; <?php echo e($mostrarNuevos ? 'transform:rotate(180deg);' : ''); ?>"><path stroke-linecap="round" stroke-linejoin="round" d="M19 9l-7 7-7-7"/></svg>
                            </button>
                            <?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if BLOCK]><![endif]--><?php endif; ?><?php if($mostrarNuevos): ?>
                                <input type="text" wire:model.live.debounce.300ms="buscarUsuario" placeholder="Buscar persona..." class="chat-new-search" spellcheck="true" autocorrect="on" autocapitalize="sentences" lang="es-MX">
                                <div class="chat-new-list">
                                    <?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if BLOCK]><![endif]--><?php \Livewire\Features\SupportCompiledWireKeys\SupportCompiledWireKeys::openLoop(); ?><?php endif; ?><?php $__empty_1 = true; $__currentLoopData = $usuariosSinChat; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $u): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?><?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><?php \Livewire\Features\SupportCompiledWireKeys\SupportCompiledWireKeys::startLoopIteration(); ?><?php endif; ?>
                                        <button type="button" wire:click="iniciarChatConUsuario(<?php echo e($u->id); ?>)" class="chat-new-user">
                                            <?php if (isset($component)) { $__componentOriginal8ca5b43b8fff8bb34ab2ba4eb4bdd67b = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginal8ca5b43b8fff8bb34ab2ba4eb4bdd67b = $attributes; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.avatar','data' => ['src' => $u->avatar_url,'nombre' => $u->name,'tamano' => 34]] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('avatar'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\Illuminate\View\AnonymousComponent::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes(['src' => \Illuminate\View\Compilers\BladeCompiler::sanitizeComponentAttribute($u->avatar_url),'nombre' => \Illuminate\View\Compilers\BladeCompiler::sanitizeComponentAttribute($u->name),'tamano' => 34]); ?>
<?php \Livewire\Features\SupportCompiledWireKeys\SupportCompiledWireKeys::processComponentKey($component); ?>

<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginal8ca5b43b8fff8bb34ab2ba4eb4bdd67b)): ?>
<?php $attributes = $__attributesOriginal8ca5b43b8fff8bb34ab2ba4eb4bdd67b; ?>
<?php unset($__attributesOriginal8ca5b43b8fff8bb34ab2ba4eb4bdd67b); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal8ca5b43b8fff8bb34ab2ba4eb4bdd67b)): ?>
<?php $component = $__componentOriginal8ca5b43b8fff8bb34ab2ba4eb4bdd67b; ?>
<?php unset($__componentOriginal8ca5b43b8fff8bb34ab2ba4eb4bdd67b); ?>
<?php endif; ?>
                                            <div><p class="user-name"><?php echo e($u->name); ?></p><p class="user-role"><?php echo e(ucfirst($u->rol)); ?></p></div>
                                        </button>
                                    <?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><?php \Livewire\Features\SupportCompiledWireKeys\SupportCompiledWireKeys::endLoop(); ?><?php endif; ?><?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?><?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><?php \Livewire\Features\SupportCompiledWireKeys\SupportCompiledWireKeys::closeLoop(); ?><?php endif; ?>
                                        <p class="chat-new-empty">No hay personas para mostrar.</p>
                                    <?php endif; ?><?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if ENDBLOCK]><![endif]--><?php endif; ?>
                                </div>
                            <?php endif; ?><?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if ENDBLOCK]><![endif]--><?php endif; ?>
                        </div>
                    <?php else: ?>
                        <div class="chat-new-top">
                            <button type="button" wire:click="iniciarChatConAdmin" class="chat-new-user">
                                <span class="chat-new-icon">🛟</span>
                                <div><p class="user-name">Escribir al administrador</p><p class="user-role">Soporte y dudas</p></div>
                            </button>
                        </div>
                    <?php endif; ?><?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if ENDBLOCK]><![endif]--><?php endif; ?>

                    
                    <?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if BLOCK]><![endif]--><?php \Livewire\Features\SupportCompiledWireKeys\SupportCompiledWireKeys::openLoop(); ?><?php endif; ?><?php $__empty_1 = true; $__currentLoopData = $rooms; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $room): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?><?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><?php \Livewire\Features\SupportCompiledWireKeys\SupportCompiledWireKeys::startLoopIteration(); ?><?php endif; ?>
                        <?php
                            $otroU = $room->tipo === 'directo' ? $room->miembros->firstWhere('id', '!=', auth()->id()) : null;
                            $nombre = $otroU?->name ?? ($room->nombre ?? 'Chat');
                            $ultimo = $room->mensajes->first();
                            $noLeidos = $room->noLeidosPara(auth()->user());
                        ?>
                        <div class="chat-room-link" wire:click="abrirRoom(<?php echo e($room->id); ?>)" style="cursor:pointer;">
                            <div class="chat-room-main">
                                <div class="chat-room-av">
                                    <?php if (isset($component)) { $__componentOriginal8ca5b43b8fff8bb34ab2ba4eb4bdd67b = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginal8ca5b43b8fff8bb34ab2ba4eb4bdd67b = $attributes; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.avatar','data' => ['src' => $otroU?->avatar_url,'nombre' => $nombre,'tamano' => 42]] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('avatar'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\Illuminate\View\AnonymousComponent::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes(['src' => \Illuminate\View\Compilers\BladeCompiler::sanitizeComponentAttribute($otroU?->avatar_url),'nombre' => \Illuminate\View\Compilers\BladeCompiler::sanitizeComponentAttribute($nombre),'tamano' => 42]); ?>
<?php \Livewire\Features\SupportCompiledWireKeys\SupportCompiledWireKeys::processComponentKey($component); ?>

<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginal8ca5b43b8fff8bb34ab2ba4eb4bdd67b)): ?>
<?php $attributes = $__attributesOriginal8ca5b43b8fff8bb34ab2ba4eb4bdd67b; ?>
<?php unset($__attributesOriginal8ca5b43b8fff8bb34ab2ba4eb4bdd67b); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal8ca5b43b8fff8bb34ab2ba4eb4bdd67b)): ?>
<?php $component = $__componentOriginal8ca5b43b8fff8bb34ab2ba4eb4bdd67b; ?>
<?php unset($__componentOriginal8ca5b43b8fff8bb34ab2ba4eb4bdd67b); ?>
<?php endif; ?>
                                    <?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if BLOCK]><![endif]--><?php endif; ?><?php if($otroU && $otroU->estaEnLinea()): ?><span class="chat-online-dot"></span><?php endif; ?><?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if ENDBLOCK]><![endif]--><?php endif; ?>
                                    <?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if BLOCK]><![endif]--><?php endif; ?><?php if($noLeidos > 0): ?><span class="badge-unread"><?php echo e($noLeidos > 99 ? '99+' : $noLeidos); ?></span><?php endif; ?><?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if ENDBLOCK]><![endif]--><?php endif; ?>
                                </div>
                                <div class="chat-room-info">
                                    <p class="chat-room-name"><?php echo e($nombre); ?></p>
                                    <p class="chat-room-meta <?php echo e($noLeidos > 0 ? 'sin-leer' : ''); ?>">
                                        <?php echo e($ultimo ? \Illuminate\Support\Str::limit($ultimo->contenido, 32) : 'Sin mensajes todavía'); ?>

                                    </p>
                                </div>
                            </div>
                            <div class="chat-room-side">
                                <?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if BLOCK]><![endif]--><?php endif; ?><?php if($ultimo): ?><span class="chat-room-time"><?php echo e($ultimo->created_at->locale('es')->diffForHumans(short: true)); ?></span><?php endif; ?><?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if ENDBLOCK]><![endif]--><?php endif; ?>
                                <?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if BLOCK]><![endif]--><?php endif; ?><?php if(auth()->user()->esAdmin()): ?>
                                    <button type="button" class="chat-room-del" title="Eliminar"
                                            wire:click.stop="eliminarConversacion(<?php echo e($room->id); ?>)"
                                            wire:confirm="¿Eliminar esta conversación para siempre?">
                                        <svg width="14" height="14" fill="none" viewBox="0 0 24 24" stroke-width="2" stroke="currentColor"><path stroke-linecap="round" stroke-linejoin="round" d="M6 18L18 6M6 6l12 12"/></svg>
                                    </button>
                                <?php endif; ?><?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if ENDBLOCK]><![endif]--><?php endif; ?>
                            </div>
                        </div>
                    <?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><?php \Livewire\Features\SupportCompiledWireKeys\SupportCompiledWireKeys::endLoop(); ?><?php endif; ?><?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?><?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><?php \Livewire\Features\SupportCompiledWireKeys\SupportCompiledWireKeys::closeLoop(); ?><?php endif; ?>
                        <p class="chat-list-empty">Sin conversaciones todavía</p>
                    <?php endif; ?><?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if ENDBLOCK]><![endif]--><?php endif; ?>
                </div>
            <?php endif; ?><?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if ENDBLOCK]><![endif]--><?php endif; ?>
        </div>
    <?php endif; ?><?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if ENDBLOCK]><![endif]--><?php endif; ?>

        <?php
        $__scriptKey = '2564702429-0';
        ob_start();
    ?>
    <script>
        const snd = window.rhSonido || {};
        let fabPrevNoLeidos = -1;
        let fabPrevMsgCount = -1;
        let fabListo = false;

        function fabScroll() {
            const c = document.getElementById('fab-mensajes');
            if (c) c.scrollTop = c.scrollHeight;
        }

        function fabBindTextarea() {
            const ta = document.getElementById('fab-textarea');
            if (!ta || ta.dataset.bound) return;
            ta.dataset.bound = '1';
            ta.focus();

            ta.addEventListener('keydown', (e) => {
                if (e.key === 'Enter' && !e.shiftKey) {
                    e.preventDefault();
                    fabEnviarRapido();
                }
            });

            const form = document.getElementById('fab-form');
            if (form) form.addEventListener('submit', (e) => {
                e.preventDefault();
                fabEnviarRapido();
            });

            let ping = 0;
            ta.addEventListener('input', () => {
                const n = Date.now();
                if (n - ping > 2000) { ping = n; $wire.escribiendo(); }
            });
        }

        function fabEnviarRapido() {
            const ta = document.getElementById('fab-textarea');
            if (!ta) return;
            const txt = ta.value.trim();
            if (txt === '') return;
            fabOptimisticSend(txt);
            ta.value = '';
            if (snd.enviado) snd.enviado();
            $wire.set('mensaje', txt);
            $wire.enviar();
        }

        function fabOptimisticSend(txt) {
            const cont = document.getElementById('fab-mensajes');
            if (!cont) return;
            const hora = new Date().toLocaleTimeString('es-MX', { hour: '2-digit', minute: '2-digit', hour12: false });
            const wrap = document.createElement('div');
            wrap.className = 'chat-bubble-wrap mine fab-optimistic';
            wrap.innerHTML = '<div class="chat-bubble"><div class="chat-bubble-text">' + txt.replace(/&/g,'&amp;').replace(/</g,'&lt;') + '</div><div class="chat-bubble-time">' + hora + '</div></div>';
            cont.appendChild(wrap);
            cont.scrollTop = cont.scrollHeight;
        }

        // ── Notificaciones de escritorio ──
        if ('Notification' in window && Notification.permission === 'default') {
            // Pedir permiso tras primera interacción del usuario
            document.addEventListener('click', function _perm() {
                Notification.requestPermission();
                document.removeEventListener('click', _perm);
            }, { once: true });
        }

        function fabNotificarEscritorio(cantidad) {
            if (!('Notification' in window) || Notification.permission !== 'granted') return;
            if (!document.hidden) return; // solo si la pestaña está oculta
            const n = new Notification('Nuevo mensaje', {
                body: cantidad > 1 ? 'Tienes ' + cantidad + ' mensajes sin leer' : 'Tienes un mensaje nuevo',
                icon: document.querySelector('link[rel="icon"]')?.href || '/favicon.ico',
                tag: 'chat-rh', // reemplaza notificaciones anteriores
                silent: true,   // el sonido ya lo maneja el chat
            });
            n.onclick = () => { window.focus(); n.close(); };
            setTimeout(() => n.close(), 6000);
        }

        function fabCheckSonidos() {
            const wrap = document.querySelector('.chat-fab-wrap');
            if (!wrap) return;

            // ── Detectar nuevos no leídos (badge) ──
            const nuevoNoLeidos = parseInt(wrap.dataset.noleidos || '0', 10);
            if (fabListo && nuevoNoLeidos > fabPrevNoLeidos && fabPrevNoLeidos >= 0) {
                // Hay nuevos mensajes: ¿estoy viendo la conversación o no?
                const enConv = !!document.getElementById('fab-mensajes') && !document.querySelector('.chat-fab-lista');
                if (enConv) {
                    // Estoy en la conversación: sonido de "recibido"
                    if (snd.recibido) snd.recibido();
                } else {
                    // Estoy en la lista o cerrado: sonido de "notificación"
                    if (snd.notificacion) snd.notificacion();
                    fabNotificarEscritorio(nuevoNoLeidos);
                }
            }
            fabPrevNoLeidos = nuevoNoLeidos;

            // ── Detectar nuevo mensaje en conversación abierta ──
            const cont = document.getElementById('fab-mensajes');
            if (cont) {
                const msgs = cont.querySelectorAll('.chat-bubble-wrap.theirs:not(.fab-optimistic)');
                const count = msgs.length;
                if (fabListo && count > fabPrevMsgCount && fabPrevMsgCount >= 0) {
                    if (snd.recibido) snd.recibido();
                }
                fabPrevMsgCount = count;
            } else {
                fabPrevMsgCount = -1;
            }

            // ── Detectar "escribiendo" ──
            const typing = document.querySelector('.chat-fab-wrap .chat-typing-wrap');
            if (typing && !typing.dataset.sonado) {
                typing.dataset.sonado = '1';
                if (fabListo && snd.escribiendo) snd.escribiendo();
            }
        }

        Livewire.hook('morphed', ({ component }) => {
            if (component.id !== $wire.id) return;
            document.querySelectorAll('.fab-optimistic').forEach(el => el.remove());
            fabScroll();
            fabBindTextarea();
            fabCheckSonidos();
            if (!fabListo) setTimeout(() => { fabListo = true; }, 800);
        });

        // Primer render
        requestAnimationFrame(() => {
            fabScroll();
            fabBindTextarea();
            fabCheckSonidos();
            setTimeout(() => { fabListo = true; }, 800);
        });

        // ── Sondeo adaptativo (reemplaza wire:poll) ──────────────────
        // Conv abierta: 500ms-5s · Lista: 3s · Cerrado: 8s · Tab oculta: pausa
        let fabSondeoTimer = null;
        let fabSondeoActividad = Date.now();
        let fabSondeoThrottle = 0;

        function fabGetDelay() {
            const wrap = document.querySelector('.chat-fab-wrap');
            const estado = wrap ? wrap.dataset.estado : 'cerrado';

            if (estado === 'conv') {
                const idle = Date.now() - fabSondeoActividad;
                return idle < 15000 ? 500 : idle < 60000 ? 2000 : 5000;
            }
            if (estado === 'lista') return 3000;
            return 4000; // cerrado: solo badge
        }

        function fabSondeoPoll() {
            $wire.$refresh()
                .then(() => fabSondeoSchedule())
                .catch(() => setTimeout(fabSondeoSchedule, 5000));
        }

        function fabSondeoSchedule() {
            if (fabSondeoTimer) clearTimeout(fabSondeoTimer);
            // Tab oculta: sondeo lento (15s) para seguir detectando mensajes y notificar
            const delay = document.hidden ? 15000 : fabGetDelay();
            fabSondeoTimer = setTimeout(fabSondeoPoll, delay);
        }

        function fabSondeoTouch() {
            const now = Date.now();
            if (now - fabSondeoThrottle < 2000) return;
            fabSondeoThrottle = now;
            const estabaInactivo = (now - fabSondeoActividad) > 15000;
            fabSondeoActividad = now;
            if (estabaInactivo) { clearTimeout(fabSondeoTimer); fabSondeoPoll(); }
        }

        document.addEventListener('mousemove', fabSondeoTouch, { passive: true });
        document.addEventListener('keydown', fabSondeoTouch);
        document.addEventListener('visibilitychange', () => {
            clearTimeout(fabSondeoTimer);
            if (document.hidden) {
                fabSondeoSchedule(); // sondeo lento (15s) para notificaciones de escritorio
            } else {
                fabSondeoActividad = Date.now();
                fabSondeoPoll(); // volver a velocidad normal
            }
        });

        fabSondeoSchedule();
    </script>
        <?php
        $__output = ob_get_clean();

        \Livewire\store($this)->push('scripts', $__output, $__scriptKey)
    ?>
</div>
<?php /**PATH C:\Dev\Web\SistemaRH_Laravel\resources\views/livewire/chat/chat-widget.blade.php ENDPATH**/ ?>