<!DOCTYPE html>
<html lang="<?php echo e(app()->getLocale() === 'es' ? 'es' : str_replace('_', '-', app()->getLocale())); ?>">
    <head>
        <meta charset="utf-8">
        <meta name="viewport" content="width=device-width, initial-scale=1">
        <meta name="csrf-token" content="<?php echo e(csrf_token()); ?>">
        <title><?php echo $__env->yieldContent('title', ($sitio['sitio_nombre'] ?? config('app.name', 'SistemaRH')) . (!empty($sitio['sitio_subtitulo']) ? ' — ' . $sitio['sitio_subtitulo'] : '')); ?></title>
        <?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if BLOCK]><![endif]--><?php endif; ?><?php if(!empty($sitio['sitio_favicon'])): ?>
            <?php $favExt = pathinfo($sitio['sitio_favicon'], PATHINFO_EXTENSION); ?>
            <link rel="icon" type="<?php echo e($favExt === 'svg' ? 'image/svg+xml' : ($favExt === 'ico' ? 'image/x-icon' : 'image/' . $favExt)); ?>" href="<?php echo e(asset('storage/' . $sitio['sitio_favicon'])); ?>">
        <?php else: ?>
            <link rel="icon" type="image/x-icon" href="<?php echo e(asset('favicon.ico')); ?>">
        <?php endif; ?><?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if ENDBLOCK]><![endif]--><?php endif; ?>
        <?php echo app('Illuminate\Foundation\Vite')(['resources/css/app.css', 'resources/js/app.js']); ?>
    </head>
    <body class="guest-page">
        <div class="guest-wrapper">
            <?php $marca = \App\Services\SitioService::partirMarca($sitio['sitio_nombre'] ?? 'SistemaRH'); ?>
            <div class="guest-brand fade-in">
                <a href="/" class="guest-logo">
                    <h1><?php echo e($marca['base']); ?><span><?php echo e($marca['acento']); ?></span></h1>
                    <?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if BLOCK]><![endif]--><?php endif; ?><?php if(!empty($sitio['sitio_subtitulo'])): ?>
                        <p class="guest-tagline"><?php echo e($sitio['sitio_subtitulo']); ?></p>
                    <?php endif; ?><?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if ENDBLOCK]><![endif]--><?php endif; ?>
                </a>
            </div>

            <div class="card fade-in guest-card">
                <?php echo e($slot); ?>

            </div>

            <p class="guest-footer fade-in">&copy; <?php echo e(date('Y')); ?> <?php echo e($sitio['landing_footer'] ?? ($sitio['sitio_nombre'] ?? 'SistemaRH') . '. Todos los derechos reservados.'); ?> · v<?php echo e(config('app.version')); ?></p>
        </div>
    </body>
</html>
<?php /**PATH C:\Dev\Web\SistemaRH_Laravel\resources\views/layouts/guest.blade.php ENDPATH**/ ?>