<?php
    $val = fn ($v) => $v !== null && $v !== '' ? $v : '—';
    $estadoColor = match($empresa->estado) {
        'activa' => 'b-green',
        'pendiente' => 'b-yellow',
        'suspendida' => 'b-gray',
        'rechazada' => 'b-red',
        default => 'b-gray',
    };
?>

<?php $__env->startComponent('partials.layout-imprimible', [
    'titulo'    => $empresa->nombre_empresa,
    'subtitulo' => 'Ficha de empresa cliente',
    'tipo'      => 'Ficha',
]); ?>

    <div style="margin-bottom:16px; padding:12px 14px; background:#f8fafc; border-radius:8px; font-size:11px;">
        <strong>Estado:</strong>
        <span class="badge <?php echo e($estadoColor); ?>"><?php echo e(\App\Models\Empresa::estadoLabel($empresa->estado)); ?></span>
        · Registrada el <?php echo e($empresa->created_at?->format('d/m/Y') ?? '—'); ?>

    </div>

    
    <h2 style="font-size:14px; color:#1e40af; margin:18px 0 8px; padding-bottom:4px; border-bottom:1px solid #cbd5e1;">1. Datos generales</h2>
    <table>
        <tbody>
            <tr>
                <td style="width:50%;"><strong>Nombre comercial:</strong> <?php echo e($val($empresa->nombre_empresa)); ?></td>
                <td style="width:50%;"><strong>Razón social:</strong> <?php echo e($val($empresa->razon_social)); ?></td>
            </tr>
            <tr>
                <td><strong>RFC:</strong> <?php echo e($val($empresa->rfc)); ?></td>
                <td><strong>Correo de la cuenta:</strong> <?php echo e($empresa->usuario?->email ?? '—'); ?></td>
            </tr>
        </tbody>
    </table>

    
    <h2 style="font-size:14px; color:#1e40af; margin:18px 0 8px; padding-bottom:4px; border-bottom:1px solid #cbd5e1;">2. Contacto</h2>
    <table>
        <tbody>
            <tr>
                <td style="width:50%;"><strong>Responsable RH:</strong> <?php echo e($val($empresa->nombre_rh)); ?></td>
                <td style="width:50%;"><strong>Página web:</strong> <?php echo e($val($empresa->pagina_web)); ?></td>
            </tr>
            <tr>
                <td><strong>Teléfono general:</strong> <?php echo e($val($empresa->telefono)); ?></td>
                <td><strong>Teléfono directo:</strong> <?php echo e($val($empresa->telefono_directo)); ?></td>
            </tr>
        </tbody>
    </table>

    
    <h2 style="font-size:14px; color:#1e40af; margin:18px 0 8px; padding-bottom:4px; border-bottom:1px solid #cbd5e1;">3. Ubicación</h2>
    <table>
        <tbody>
            <tr>
                <td colspan="3"><strong>Dirección:</strong> <?php echo e($val($empresa->direccion)); ?></td>
            </tr>
            <tr>
                <td style="width:34%;"><strong>Ciudad:</strong> <?php echo e($val($empresa->ciudad)); ?></td>
                <td style="width:33%;"><strong>Municipio:</strong> <?php echo e($val($empresa->municipio)); ?></td>
                <td style="width:33%;"><strong>CP:</strong> <?php echo e($val($empresa->codigo_postal)); ?></td>
            </tr>
        </tbody>
    </table>

    <?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if BLOCK]><![endif]--><?php endif; ?><?php if($empresa->descripcion): ?>
        <h2 style="font-size:14px; color:#1e40af; margin:18px 0 8px; padding-bottom:4px; border-bottom:1px solid #cbd5e1;">4. Descripción</h2>
        <table>
            <tbody>
                <tr><td><?php echo e($empresa->descripcion); ?></td></tr>
            </tbody>
        </table>
    <?php endif; ?><?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if ENDBLOCK]><![endif]--><?php endif; ?>

<?php echo $__env->renderComponent(); ?>
<?php /**PATH C:\Dev\Web\SistemaRH_Laravel\resources\views/admin/empresas/imprimible.blade.php ENDPATH**/ ?>