<?php if (isset($component)) { $__componentOriginal9ac128a9029c0e4701924bd2d73d7f54 = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginal9ac128a9029c0e4701924bd2d73d7f54 = $attributes; } ?>
<?php $component = App\View\Components\AppLayout::resolve([] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('app-layout'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\App\View\Components\AppLayout::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes([]); ?>
<?php \Livewire\Features\SupportCompiledWireKeys\SupportCompiledWireKeys::processComponentKey($component); ?>

     <?php $__env->slot('header', null, []); ?> 
        <nav class="breadcrumbs">
            <a href="<?php echo e(route('dashboard')); ?>">Inicio</a>
            <span class="breadcrumb-sep">&rsaquo;</span>
            <span>Seguridad</span>
        </nav>
        <h1 class="page-title">Sesión detectada en otro dispositivo</h1>
        <p class="page-subtitle">
            Antes de continuar, revisa las sesiones activas y decide si quieres cerrarlas o mantenerlas abiertas.
        </p>
     <?php $__env->endSlot(); ?>

    <div class="card fade-in" style="max-width: 980px; margin: 0 auto; padding: 28px;">
        <div style="display:flex; gap:16px; align-items:flex-start; flex-wrap:wrap;">
            <div style="width:54px; height:54px; border-radius:16px; background:rgba(59,130,246,.12); color:#3b82f6; display:flex; align-items:center; justify-content:center; font-size:1.4rem; font-weight:800;">
                !
            </div>

            <div style="flex:1; min-width:240px;">
                <h2 style="margin:0 0 6px; font-size:1.2rem; font-weight:800;">
                    Detectamos <?php echo e($sesionesDetectadas); ?> <?php echo e($sesionesDetectadas === 1 ? 'sesión activa' : 'sesiones activas'); ?> en otros dispositivos.
                </h2>
                <p style="margin:0; color:#64748b; line-height:1.65;">
                    Si reconoces estos accesos, puedes continuar sin tocar nada.
                    Si no los reconoces, te recomendamos cerrar las demás sesiones para proteger tu cuenta.
                </p>
            </div>
        </div>

        <div style="margin-top:22px; padding:16px; border:1px solid var(--border); border-radius:12px; background:var(--surface-2);">
            <div style="font-weight:700; margin-bottom:6px;">¿Qué quieres hacer?</div>
            <div style="font-size:0.92rem; color:#64748b; line-height:1.6;">
                Cerrar las otras sesiones invalidará los accesos anteriores en otros dispositivos.
                La sesión actual permanecerá abierta y podrás continuar a tu destino habitual.
            </div>
        </div>

        <div style="margin-top:24px; display:grid; gap:14px;">
            <?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if BLOCK]><![endif]--><?php \Livewire\Features\SupportCompiledWireKeys\SupportCompiledWireKeys::openLoop(); ?><?php endif; ?><?php $__empty_1 = true; $__currentLoopData = $sesiones; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $sesion): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?><?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><?php \Livewire\Features\SupportCompiledWireKeys\SupportCompiledWireKeys::startLoopIteration(); ?><?php endif; ?>
                <article style="border:1px solid var(--border); border-radius:16px; padding:18px; background:var(--surface); box-shadow:0 10px 30px rgba(15,23,42,.04);">
                    <div style="display:flex; justify-content:space-between; gap:14px; flex-wrap:wrap; align-items:flex-start;">
                        <div>
                            <div style="font-size:1.02rem; font-weight:800; color:#0f172a;"><?php echo e($sesion['dispositivo']); ?></div>
                            <div style="margin-top:4px; font-size:0.9rem; color:#64748b;">
                                <?php echo e($sesion['navegador']); ?> · <?php echo e($sesion['sistema_operativo']); ?>

                            </div>
                        </div>

                        <div style="padding:7px 12px; border-radius:999px; background:rgba(37,99,235,.1); color:#2563eb; font-weight:700; font-size:0.82rem;">
                            Última actividad: <?php echo e($sesion['ultima_actividad_humana']); ?>

                        </div>
                    </div>

                    <div style="margin-top:16px; display:grid; grid-template-columns:repeat(auto-fit, minmax(180px, 1fr)); gap:14px;">
                        <div>
                            <div style="font-size:0.78rem; text-transform:uppercase; letter-spacing:.06em; color:#94a3b8; font-weight:700;">IP</div>
                            <div style="margin-top:4px; font-weight:700; color:#0f172a; font-family:ui-monospace, SFMono-Regular, Menlo, Monaco, Consolas, monospace;">
                                <?php echo e($sesion['ip_address']); ?>

                            </div>
                        </div>

                        <div>
                            <div style="font-size:0.78rem; text-transform:uppercase; letter-spacing:.06em; color:#94a3b8; font-weight:700;">Navegador</div>
                            <div style="margin-top:4px; font-weight:700; color:#0f172a;">
                                <?php echo e($sesion['navegador']); ?>

                            </div>
                        </div>

                        <div>
                            <div style="font-size:0.78rem; text-transform:uppercase; letter-spacing:.06em; color:#94a3b8; font-weight:700;">Sistema</div>
                            <div style="margin-top:4px; font-weight:700; color:#0f172a;">
                                <?php echo e($sesion['sistema_operativo']); ?>

                            </div>
                        </div>

                        <div>
                            <div style="font-size:0.78rem; text-transform:uppercase; letter-spacing:.06em; color:#94a3b8; font-weight:700;">Fecha y hora</div>
                            <div style="margin-top:4px; font-weight:700; color:#0f172a;">
                                <?php echo e($sesion['ultima_actividad_formateada']); ?>

                            </div>
                        </div>
                    </div>

                    <?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if BLOCK]><![endif]--><?php endif; ?><?php if(! empty($sesion['user_agent'])): ?>
                        <div style="margin-top:14px; padding:12px 14px; border-radius:12px; background:#f8fafc; border:1px solid #e2e8f0; color:#475569; font-size:0.84rem; word-break:break-word;">
                            <?php echo e($sesion['user_agent']); ?>

                        </div>
                    <?php endif; ?><?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if ENDBLOCK]><![endif]--><?php endif; ?>
                </article>
            <?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><?php \Livewire\Features\SupportCompiledWireKeys\SupportCompiledWireKeys::endLoop(); ?><?php endif; ?><?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?><?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><?php \Livewire\Features\SupportCompiledWireKeys\SupportCompiledWireKeys::closeLoop(); ?><?php endif; ?>
                <div style="padding:16px; border:1px dashed var(--border); border-radius:12px; color:#64748b; background:var(--surface-2);">
                    No se pudo leer el detalle de las otras sesiones, pero sí detectamos accesos activos en tu cuenta.
                </div>
            <?php endif; ?><?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if ENDBLOCK]><![endif]--><?php endif; ?>
        </div>

        <div style="display:flex; gap:10px; flex-wrap:wrap; margin-top:24px;">
            <form method="POST" action="<?php echo e(route('sesiones.cerrar-otras')); ?>">
                <?php echo csrf_field(); ?>
                <button type="submit" class="btn btn-primary">
                    Cerrar otras sesiones
                </button>
            </form>

            <form method="POST" action="<?php echo e(route('sesiones.continuar')); ?>">
                <?php echo csrf_field(); ?>
                <button type="submit" class="btn btn-secondary">
                    Continuar sin cerrar
                </button>
            </form>
        </div>

        <div style="margin-top:18px; font-size:0.85rem; color:#64748b;">
            Si no reconoces un acceso, también conviene cambiar tu contraseña desde
            <a href="<?php echo e(route('profile.edit')); ?>" style="color:var(--accent); font-weight:600;">Mi cuenta</a>.
        </div>
    </div>
 <?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginal9ac128a9029c0e4701924bd2d73d7f54)): ?>
<?php $attributes = $__attributesOriginal9ac128a9029c0e4701924bd2d73d7f54; ?>
<?php unset($__attributesOriginal9ac128a9029c0e4701924bd2d73d7f54); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal9ac128a9029c0e4701924bd2d73d7f54)): ?>
<?php $component = $__componentOriginal9ac128a9029c0e4701924bd2d73d7f54; ?>
<?php unset($__componentOriginal9ac128a9029c0e4701924bd2d73d7f54); ?>
<?php endif; ?>
<?php /**PATH C:\Dev\Web\SistemaRH_Laravel\resources\views/auth/confirmar-cierre-sesiones.blade.php ENDPATH**/ ?>