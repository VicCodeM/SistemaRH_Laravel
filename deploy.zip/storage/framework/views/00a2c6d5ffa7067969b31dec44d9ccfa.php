<?php $attributes ??= new \Illuminate\View\ComponentAttributeBag;

$__newAttributes = [];
$__propNames = \Illuminate\View\ComponentAttributeBag::extractPropNames(([
    'src'   => null,   // URL o ruta relativa de storage
    'nombre' => '',    // nombre completo (para iniciales)
    'tamano' => 40,    // tamaño en px
]));

foreach ($attributes->all() as $__key => $__value) {
    if (in_array($__key, $__propNames)) {
        $$__key = $$__key ?? $__value;
    } else {
        $__newAttributes[$__key] = $__value;
    }
}

$attributes = new \Illuminate\View\ComponentAttributeBag($__newAttributes);

unset($__propNames);
unset($__newAttributes);

foreach (array_filter(([
    'src'   => null,   // URL o ruta relativa de storage
    'nombre' => '',    // nombre completo (para iniciales)
    'tamano' => 40,    // tamaño en px
]), 'is_string', ARRAY_FILTER_USE_KEY) as $__key => $__value) {
    $$__key = $$__key ?? $__value;
}

$__defined_vars = get_defined_vars();

foreach ($attributes->all() as $__key => $__value) {
    if (array_key_exists($__key, $__defined_vars)) unset($$__key);
}

unset($__defined_vars, $__key, $__value); ?>

<?php
    $iniciales = collect(explode(' ', trim($nombre)))
        ->filter()
        ->take(2)
        ->map(fn ($p) => mb_strtoupper(mb_substr($p, 0, 1)))
        ->implode('');

    if (! $iniciales) {
        $iniciales = '?';
    }

    // Si src es ruta relativa, convertirla a URL completa
    $url = null;
    if ($src) {
        $url = str_starts_with($src, 'http') || str_starts_with($src, '/')
            ? $src
            : asset('storage/' . $src);
    }

    $fontSize = max(10, (int) ($tamano * 0.4));
?>

<?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if BLOCK]><![endif]--><?php endif; ?><?php if($url): ?>
    <img src="<?php echo e($url); ?>" alt="<?php echo e($nombre); ?>"
         style="width:<?php echo e($tamano); ?>px; height:<?php echo e($tamano); ?>px; border-radius:50%; object-fit:cover; flex-shrink:0; border:1px solid var(--border);"
         <?php echo e($attributes); ?>>
<?php else: ?>
    <div style="width:<?php echo e($tamano); ?>px; height:<?php echo e($tamano); ?>px; border-radius:50%; background:var(--accent-light); color:var(--accent); display:flex; align-items:center; justify-content:center; font-weight:700; font-size:<?php echo e($fontSize); ?>px; flex-shrink:0;"
         title="<?php echo e($nombre); ?>"
         <?php echo e($attributes); ?>>
        <?php echo e($iniciales); ?>

    </div>
<?php endif; ?><?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if ENDBLOCK]><![endif]--><?php endif; ?>
<?php /**PATH C:\Dev\Web\SistemaRH_Laravel\resources\views/components/avatar.blade.php ENDPATH**/ ?>