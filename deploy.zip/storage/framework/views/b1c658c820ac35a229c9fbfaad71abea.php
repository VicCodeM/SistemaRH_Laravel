<?php
    $estadoActual = request('estado', '');

    $linkTab = fn ($estado) => route('admin.tareas.index', array_merge(
        request()->except(['page', 'estado']),
        $estado ? ['estado' => $estado] : []
    ));

    $linkOrden = function (string $campo) {
        $sortActual = request('sort');
        $dirActual = request('dir', 'desc');
        $nuevaDir = ($sortActual === $campo && $dirActual === 'asc') ? 'desc' : 'asc';

        return route('admin.tareas.index', array_merge(
            request()->except(['page', 'sort', 'dir']),
            ['sort' => $campo, 'dir' => $nuevaDir]
        ));
    };

    $flecha = function (string $campo) use ($sort, $dir) {
        if ($sort !== $campo) {
            return '';
        }

        return $dir === 'asc' ? ' ^' : ' v';
    };

    $tabs = [
        '' => ['label' => 'Todas', 'count' => null, 'bg' => 'var(--surface-2)', 'fg' => 'var(--text)', 'br' => 'var(--border)'],
        'pendiente' => ['label' => 'Pendientes', 'count' => $stats['pendientes'], 'bg' => '#fffbeb', 'fg' => '#d97706', 'br' => '#fcd34d'],
        'activo' => ['label' => 'Activas', 'count' => $stats['activas'], 'bg' => '#eff6ff', 'fg' => '#2563eb', 'br' => '#93c5fd'],
        'en_proceso' => ['label' => 'En proceso', 'count' => $stats['en_proceso'], 'bg' => '#fef3c7', 'fg' => '#92400e', 'br' => '#fbbf24'],
        'completado' => ['label' => 'Completadas', 'count' => $stats['completadas'], 'bg' => '#f0fdf4', 'fg' => '#16a34a', 'br' => '#86efac'],
        'cancelado' => ['label' => 'Canceladas', 'count' => $stats['canceladas'], 'bg' => '#f8fafc', 'fg' => '#64748b', 'br' => '#cbd5e1'],
    ];
?>

<?php if (isset($component)) { $__componentOriginal9ac128a9029c0e4701924bd2d73d7f54 = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginal9ac128a9029c0e4701924bd2d73d7f54 = $attributes; } ?>
<?php $component = App\View\Components\AppLayout::resolve([] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('app-layout'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\App\View\Components\AppLayout::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes([]); ?>
<?php \Livewire\Features\SupportCompiledWireKeys\SupportCompiledWireKeys::processComponentKey($component); ?>

     <?php $__env->slot('header', null, []); ?> 
        <nav class="breadcrumbs">
            <a href="<?php echo e(route('admin.dashboard')); ?>">Administracion</a>
            <span class="breadcrumb-sep">&rsaquo;</span>
            <span>Pedidos de servicio</span>
        </nav>
        <div class="candidate-inline-meta">
            <div>
                <h1 class="page-title">Pedidos de servicio</h1>
                <p class="page-subtitle">Capacitaciones, coaching y otros servicios solicitados por empresas o candidatos.</p>
            </div>
            <div class="toolbar-wrap">
                <a href="<?php echo e(route('admin.tareas.exportar.csv', request()->query())); ?>" class="btn btn-secondary" style="font-size:13px;">Excel</a>
                <a href="<?php echo e(route('admin.tareas.exportar.pdf', request()->query())); ?>" target="_blank" class="btn btn-secondary" style="font-size:13px;">PDF</a>
                <a href="<?php echo e(route('admin.tareas.kanban', request()->only(['servicio_id', 'solicitante_tipo', 'interno_id', 'buscar']))); ?>" class="btn btn-secondary" style="font-size:13px;">Kanban</a>
                <a href="<?php echo e(route('admin.tareas.crear')); ?>" class="btn btn-primary">+ Registrar pedido</a>
            </div>
        </div>
     <?php $__env->endSlot(); ?>

    <?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if BLOCK]><![endif]--><?php endif; ?><?php if(session('success')): ?>
        <div class="alert alert-success mb-4"><?php echo e(session('success')); ?></div>
    <?php endif; ?><?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if ENDBLOCK]><![endif]--><?php endif; ?>
    <?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if BLOCK]><![endif]--><?php endif; ?><?php if(session('error')): ?>
        <div class="alert alert-danger mb-4"><?php echo e(session('error')); ?></div>
    <?php endif; ?><?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if ENDBLOCK]><![endif]--><?php endif; ?>

    <div style="display:flex; gap:6px; margin-bottom:14px; flex-wrap:wrap;">
        <?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if BLOCK]><![endif]--><?php \Livewire\Features\SupportCompiledWireKeys\SupportCompiledWireKeys::openLoop(); ?><?php endif; ?><?php $__currentLoopData = $tabs; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $estadoKey => $cfg): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?><?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><?php \Livewire\Features\SupportCompiledWireKeys\SupportCompiledWireKeys::startLoopIteration(); ?><?php endif; ?>
            <?php $activo = $estadoActual === $estadoKey; ?>
            <a href="<?php echo e($linkTab($estadoKey)); ?>"
               style="padding:6px 14px; border-radius:6px; font-size:13px; font-weight:500; text-decoration:none;
                      background:<?php echo e($activo ? $cfg['bg'] : 'transparent'); ?>;
                      color:<?php echo e($activo ? $cfg['fg'] : 'var(--text-muted)'); ?>;
                      border:1px solid <?php echo e($activo ? $cfg['br'] : 'transparent'); ?>;">
                <?php echo e($cfg['label']); ?>

                <?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if BLOCK]><![endif]--><?php endif; ?><?php if($cfg['count'] !== null && $cfg['count'] > 0): ?>
                    <span style="margin-left:6px; background:<?php echo e($cfg['fg']); ?>; color:#fff; border-radius:20px; padding:1px 7px; font-size:11px;"><?php echo e($cfg['count']); ?></span>
                <?php endif; ?><?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if ENDBLOCK]><![endif]--><?php endif; ?>
            </a>
        <?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><?php \Livewire\Features\SupportCompiledWireKeys\SupportCompiledWireKeys::endLoop(); ?><?php endif; ?><?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?><?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if ENDBLOCK]><![endif]--><?php \Livewire\Features\SupportCompiledWireKeys\SupportCompiledWireKeys::closeLoop(); ?><?php endif; ?>
    </div>

    <form method="GET" style="background:var(--surface-2); border:1px solid var(--border); border-radius:10px; padding:14px; margin-bottom:14px; display:grid; grid-template-columns:repeat(auto-fit, minmax(180px, 1fr)); gap:10px; align-items:end;">
        <?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if BLOCK]><![endif]--><?php endif; ?><?php if($estadoActual): ?>
            <input type="hidden" name="estado" value="<?php echo e($estadoActual); ?>">
        <?php endif; ?><?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if ENDBLOCK]><![endif]--><?php endif; ?>
        <?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if BLOCK]><![endif]--><?php endif; ?><?php if(request('sort')): ?>
            <input type="hidden" name="sort" value="<?php echo e(request('sort')); ?>">
        <?php endif; ?><?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if ENDBLOCK]><![endif]--><?php endif; ?>
        <?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if BLOCK]><![endif]--><?php endif; ?><?php if(request('dir')): ?>
            <input type="hidden" name="dir" value="<?php echo e(request('dir')); ?>">
        <?php endif; ?><?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if ENDBLOCK]><![endif]--><?php endif; ?>

        <div>
            <label class="form-label" style="font-size:11px;">Servicio</label>
            <select name="servicio_id" class="form-input" style="font-size:13px; padding:7px 10px;" onchange="this.form.submit()">
                <option value="">Todos</option>
                <?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if BLOCK]><![endif]--><?php \Livewire\Features\SupportCompiledWireKeys\SupportCompiledWireKeys::openLoop(); ?><?php endif; ?><?php $__currentLoopData = $serviciosCatalogo; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $s): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?><?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><?php \Livewire\Features\SupportCompiledWireKeys\SupportCompiledWireKeys::startLoopIteration(); ?><?php endif; ?>
                    <option value="<?php echo e($s->id); ?>" <?php if(request('servicio_id') == $s->id): echo 'selected'; endif; ?>><?php echo e($s->nombre); ?></option>
                <?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><?php \Livewire\Features\SupportCompiledWireKeys\SupportCompiledWireKeys::endLoop(); ?><?php endif; ?><?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?><?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if ENDBLOCK]><![endif]--><?php \Livewire\Features\SupportCompiledWireKeys\SupportCompiledWireKeys::closeLoop(); ?><?php endif; ?>
            </select>
        </div>

        <div>
            <label class="form-label" style="font-size:11px;">Solicitante</label>
            <select name="solicitante_tipo" class="form-input" style="font-size:13px; padding:7px 10px;" onchange="this.form.submit()">
                <option value="">Todos</option>
                <option value="empresa" <?php if(request('solicitante_tipo') === 'empresa'): echo 'selected'; endif; ?>>Empresas</option>
                <option value="candidato" <?php if(request('solicitante_tipo') === 'candidato'): echo 'selected'; endif; ?>>Candidatos</option>
                <option value="interno" <?php if(request('solicitante_tipo') === 'interno'): echo 'selected'; endif; ?>>Internos</option>
            </select>
        </div>

        <div>
            <label class="form-label" style="font-size:11px;">Responsable interno</label>
            <select name="interno_id" class="form-input" style="font-size:13px; padding:7px 10px;" onchange="this.form.submit()">
                <option value="">Todos</option>
                <option value="sin" <?php if(request('interno_id') === 'sin'): echo 'selected'; endif; ?>>Sin asignar</option>
                <?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if BLOCK]><![endif]--><?php \Livewire\Features\SupportCompiledWireKeys\SupportCompiledWireKeys::openLoop(); ?><?php endif; ?><?php $__currentLoopData = $internosLista; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $i): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?><?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><?php \Livewire\Features\SupportCompiledWireKeys\SupportCompiledWireKeys::startLoopIteration(); ?><?php endif; ?>
                    <option value="<?php echo e($i->id); ?>" <?php if(request('interno_id') == $i->id): echo 'selected'; endif; ?>><?php echo e($i->name); ?></option>
                <?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><?php \Livewire\Features\SupportCompiledWireKeys\SupportCompiledWireKeys::endLoop(); ?><?php endif; ?><?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?><?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if ENDBLOCK]><![endif]--><?php \Livewire\Features\SupportCompiledWireKeys\SupportCompiledWireKeys::closeLoop(); ?><?php endif; ?>
            </select>
        </div>

        <div>
            <label class="form-label" style="font-size:11px;">Urgencia (sin avanzar)</label>
            <select name="urgencia" class="form-input" style="font-size:13px; padding:7px 10px;" onchange="this.form.submit()">
                <option value="">Todas</option>
                <option value="3" <?php if(request('urgencia') === '3'): echo 'selected'; endif; ?>>Mas de 3 dias</option>
                <option value="7" <?php if(request('urgencia') === '7'): echo 'selected'; endif; ?>>Mas de 7 dias</option>
                <option value="14" <?php if(request('urgencia') === '14'): echo 'selected'; endif; ?>>Mas de 14 dias</option>
            </select>
        </div>

        <div style="grid-column:span 2;">
            <label class="form-label" style="font-size:11px;">Buscar</label>
            <div style="display:flex; gap:6px; flex-wrap:wrap;">
                <input type="text" name="buscar" value="<?php echo e(request('buscar')); ?>" placeholder="Servicio, interno, empresa..." class="form-input" style="flex:1; min-width:200px; font-size:13px; padding:7px 10px;" spellcheck="true" autocorrect="on" autocapitalize="sentences" lang="es-MX">
                <button type="submit" class="btn btn-primary" style="font-size:13px;">Buscar</button>
                <?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if BLOCK]><![endif]--><?php endif; ?><?php if(request()->hasAny(['buscar', 'servicio_id', 'solicitante_tipo', 'interno_id', 'urgencia'])): ?>
                    <a href="<?php echo e(route('admin.tareas.index', $estadoActual ? ['estado' => $estadoActual] : [])); ?>" class="btn btn-secondary" style="font-size:13px;">Limpiar</a>
                <?php endif; ?><?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if ENDBLOCK]><![endif]--><?php endif; ?>
            </div>
        </div>
    </form>

    <div class="table-wrapper">
        <?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if BLOCK]><![endif]--><?php endif; ?><?php if($tareas->isEmpty()): ?>
            <div style="text-align:center; padding:48px; color:#475569;">
                <?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if BLOCK]><![endif]--><?php endif; ?><?php if($estadoActual === 'pendiente'): ?>
                    No hay pedidos pendientes. Todo al dia.
                <?php else: ?>
                    No hay pedidos que coincidan con los filtros.
                <?php endif; ?><?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if ENDBLOCK]><![endif]--><?php endif; ?>
            </div>
        <?php else: ?>
            <div class="desktop-only table-scroll">
                <table class="table">
                    <thead>
                        <tr>
                            <th><a href="<?php echo e($linkOrden('servicio')); ?>" style="color:inherit; text-decoration:none;">Servicio<?php echo e($flecha('servicio')); ?></a></th>
                            <th>Solicitante</th>
                            <th>Responsable</th>
                            <th><a href="<?php echo e($linkOrden('estado')); ?>" style="color:inherit; text-decoration:none;">Estado<?php echo e($flecha('estado')); ?></a></th>
                            <th style="text-align:center;"><a href="<?php echo e($linkOrden('dias')); ?>" style="color:inherit; text-decoration:none;">Dias<?php echo e($flecha('dias')); ?></a></th>
                            <th style="text-align:right;">Acciones</th>
                        </tr>
                    </thead>
                    <tbody>
                        <?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if BLOCK]><![endif]--><?php \Livewire\Features\SupportCompiledWireKeys\SupportCompiledWireKeys::openLoop(); ?><?php endif; ?><?php $__currentLoopData = $tareas; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $tarea): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?><?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><?php \Livewire\Features\SupportCompiledWireKeys\SupportCompiledWireKeys::startLoopIteration(); ?><?php endif; ?>
                            <?php
                                $dias = $tarea->created_at ? (int) $tarea->created_at->diffInDays(now()) : 0;
                                $urgente = in_array($tarea->estado, ['pendiente', 'activo'], true) && $dias >= 3;
                                $tipo = \App\Models\ServicioAsignado::asignableTipoLabel($tarea->asignable_type);
                                $avatarSolicitante = match($tarea->asignable_type) {
                                    \App\Models\Empresa::class, \App\Models\Candidato::class => $tarea->asignable?->usuario?->avatar_url,
                                    \App\Models\User::class => $tarea->asignable?->avatar_url,
                                    default => null,
                                };
                            ?>
                            <tr style="<?php echo e($urgente ? 'background:rgba(254,226,226,.25);' : ''); ?>">
                                <td>
                                    <div style="font-weight:600;">
                                        <?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if BLOCK]><![endif]--><?php endif; ?><?php if($urgente): ?>
                                            <span title="Urgente: <?php echo e($dias); ?> dias sin avanzar" style="color:#dc2626;">!</span>
                                        <?php endif; ?><?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if ENDBLOCK]><![endif]--><?php endif; ?>
                                        <?php echo e($tarea->servicio?->nombre ?? 'Servicio'); ?>

                                    </div>
                                    <div style="font-size:11px; color:#94a3b8; margin-top:2px;"><?php echo e(\App\Models\CatalogoServicio::nivelJerarquicoLabel($tarea->servicio?->nivel_jerarquico)); ?></div>
                                </td>
                                <td style="font-size:13px;">
                                    <div style="display:flex; align-items:center; gap:8px;">
                                        <?php if (isset($component)) { $__componentOriginal8ca5b43b8fff8bb34ab2ba4eb4bdd67b = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginal8ca5b43b8fff8bb34ab2ba4eb4bdd67b = $attributes; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.avatar','data' => ['src' => $avatarSolicitante,'nombre' => $tarea->asignableNombre(),'tamano' => 28]] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('avatar'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\Illuminate\View\AnonymousComponent::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes(['src' => \Illuminate\View\Compilers\BladeCompiler::sanitizeComponentAttribute($avatarSolicitante),'nombre' => \Illuminate\View\Compilers\BladeCompiler::sanitizeComponentAttribute($tarea->asignableNombre()),'tamano' => 28]); ?>
<?php \Livewire\Features\SupportCompiledWireKeys\SupportCompiledWireKeys::processComponentKey($component); ?>

<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginal8ca5b43b8fff8bb34ab2ba4eb4bdd67b)): ?>
<?php $attributes = $__attributesOriginal8ca5b43b8fff8bb34ab2ba4eb4bdd67b; ?>
<?php unset($__attributesOriginal8ca5b43b8fff8bb34ab2ba4eb4bdd67b); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal8ca5b43b8fff8bb34ab2ba4eb4bdd67b)): ?>
<?php $component = $__componentOriginal8ca5b43b8fff8bb34ab2ba4eb4bdd67b; ?>
<?php unset($__componentOriginal8ca5b43b8fff8bb34ab2ba4eb4bdd67b); ?>
<?php endif; ?>
                                        <div style="min-width:0;">
                                            <div style="font-weight:500;"><?php echo e($tarea->asignableNombre()); ?></div>
                                            <div style="font-size:11px; color:#94a3b8; margin-top:2px;"><?php echo e($tipo); ?></div>
                                        </div>
                                    </div>
                                </td>
                                <td style="font-size:13px;">
                                    <?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if BLOCK]><![endif]--><?php endif; ?><?php if($tarea->asignadoA): ?>
                                        <div style="display:flex; align-items:center; gap:8px;">
                                            <?php if (isset($component)) { $__componentOriginal8ca5b43b8fff8bb34ab2ba4eb4bdd67b = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginal8ca5b43b8fff8bb34ab2ba4eb4bdd67b = $attributes; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.avatar','data' => ['src' => $tarea->asignadoA->avatar_url,'nombre' => $tarea->asignadoA->name,'tamano' => 28]] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('avatar'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\Illuminate\View\AnonymousComponent::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes(['src' => \Illuminate\View\Compilers\BladeCompiler::sanitizeComponentAttribute($tarea->asignadoA->avatar_url),'nombre' => \Illuminate\View\Compilers\BladeCompiler::sanitizeComponentAttribute($tarea->asignadoA->name),'tamano' => 28]); ?>
<?php \Livewire\Features\SupportCompiledWireKeys\SupportCompiledWireKeys::processComponentKey($component); ?>

<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginal8ca5b43b8fff8bb34ab2ba4eb4bdd67b)): ?>
<?php $attributes = $__attributesOriginal8ca5b43b8fff8bb34ab2ba4eb4bdd67b; ?>
<?php unset($__attributesOriginal8ca5b43b8fff8bb34ab2ba4eb4bdd67b); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal8ca5b43b8fff8bb34ab2ba4eb4bdd67b)): ?>
<?php $component = $__componentOriginal8ca5b43b8fff8bb34ab2ba4eb4bdd67b; ?>
<?php unset($__componentOriginal8ca5b43b8fff8bb34ab2ba4eb4bdd67b); ?>
<?php endif; ?>
                                            <div style="font-weight:500;"><?php echo e($tarea->asignadoA->name); ?></div>
                                        </div>
                                    <?php else: ?>
                                        <span class="badge badge-orange" style="font-size:11px;">Sin asignar</span>
                                    <?php endif; ?><?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if ENDBLOCK]><![endif]--><?php endif; ?>
                                </td>
                                <td>
                                    <span class="badge <?php echo e(\App\Models\ServicioAsignado::estadoBadgeClass($tarea->estado)); ?>">
                                        <?php echo e(\App\Models\ServicioAsignado::estadoLabel($tarea->estado)); ?>

                                    </span>
                                </td>
                                <td style="text-align:center; font-size:12px;">
                                    <span style="color:<?php echo e($urgente ? '#dc2626' : '#64748b'); ?>; font-weight:<?php echo e($urgente ? '600' : 'normal'); ?>;"><?php echo e($dias); ?>d</span>
                                    <div style="font-size:10px; color:#94a3b8;"><?php echo e($tarea->created_at?->format('d/m/Y') ?? '—'); ?></div>
                                </td>
                                <td style="white-space:nowrap; text-align:right;">
                                    <div class="toolbar-wrap" style="justify-content:flex-end;">
                                        <?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if BLOCK]><![endif]--><?php endif; ?><?php if($tarea->estado === 'pendiente' && ! $tarea->asignado_a): ?>
                                            <a href="<?php echo e(route('admin.tareas.matching', $tarea)); ?>" class="btn btn-primary btn-sm">Asignar</a>
                                        <?php elseif($tarea->estado === 'activo'): ?>
                                            <form method="POST" action="<?php echo e(route('admin.tareas.estado', $tarea)); ?>">
                                                <?php echo csrf_field(); ?>
                                                <?php echo method_field('PATCH'); ?>
                                                <input type="hidden" name="estado" value="en_proceso">
                                                <button type="submit" class="btn btn-primary btn-sm">Iniciar</button>
                                            </form>
                                        <?php elseif($tarea->estado === 'en_proceso'): ?>
                                            <form method="POST" action="<?php echo e(route('admin.tareas.estado', $tarea)); ?>">
                                                <?php echo csrf_field(); ?>
                                                <?php echo method_field('PATCH'); ?>
                                                <input type="hidden" name="estado" value="completado">
                                                <button type="submit" class="btn btn-success btn-sm">Completar</button>
                                            </form>
                                        <?php elseif(in_array($tarea->estado, ['completado', 'cancelado'], true)): ?>
                                            <button type="button" onclick="rhModal('<?php echo e(route('admin.tareas.accion.modal', [$tarea, 'reabrir'])); ?>')" class="btn btn-secondary btn-sm">Reabrir</button>
                                        <?php endif; ?><?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if ENDBLOCK]><![endif]--><?php endif; ?>

                                        <?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if BLOCK]><![endif]--><?php endif; ?><?php if($tarea->estado !== 'pendiente' || $tarea->asignado_a): ?>
                                            <a href="<?php echo e(route('admin.tareas.matching', $tarea)); ?>" class="btn btn-secondary btn-sm">Interno</a>
                                        <?php endif; ?><?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if ENDBLOCK]><![endif]--><?php endif; ?>

                                        <a href="<?php echo e(route('admin.tareas.show', $tarea)); ?>" class="btn btn-ghost" style="padding:4px 10px; font-size:12px;">Ver</a>
                                    </div>
                                </td>
                            </tr>
                        <?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><?php \Livewire\Features\SupportCompiledWireKeys\SupportCompiledWireKeys::endLoop(); ?><?php endif; ?><?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?><?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if ENDBLOCK]><![endif]--><?php \Livewire\Features\SupportCompiledWireKeys\SupportCompiledWireKeys::closeLoop(); ?><?php endif; ?>
                    </tbody>
                </table>
            </div>

            <div class="mobile-only">
                <div class="candidate-mobile-list">
                    <?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if BLOCK]><![endif]--><?php \Livewire\Features\SupportCompiledWireKeys\SupportCompiledWireKeys::openLoop(); ?><?php endif; ?><?php $__currentLoopData = $tareas; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $tarea): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?><?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><?php \Livewire\Features\SupportCompiledWireKeys\SupportCompiledWireKeys::startLoopIteration(); ?><?php endif; ?>
                        <?php
                            $dias = $tarea->created_at ? (int) $tarea->created_at->diffInDays(now()) : 0;
                            $urgente = in_array($tarea->estado, ['pendiente', 'activo'], true) && $dias >= 3;
                            $tipo = \App\Models\ServicioAsignado::asignableTipoLabel($tarea->asignable_type);
                        ?>
                        <article class="candidate-mobile-card" style="<?php echo e($urgente ? 'border-color:rgba(239,68,68,.35); box-shadow:0 0 0 1px rgba(239,68,68,.06);' : ''); ?>">
                            <div class="candidate-inline-meta">
                                <div style="min-width:0;">
                                    <h3 class="candidate-mobile-card-title">
                                        <?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if BLOCK]><![endif]--><?php endif; ?><?php if($urgente): ?>
                                            <span style="color:#dc2626;">!</span>
                                        <?php endif; ?><?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if ENDBLOCK]><![endif]--><?php endif; ?>
                                        <?php echo e($tarea->servicio?->nombre ?? 'Servicio'); ?>

                                    </h3>
                                    <p class="candidate-mobile-card-subtitle"><?php echo e($tipo); ?> · <?php echo e($tarea->asignableNombre()); ?></p>
                                </div>
                                <span class="badge <?php echo e(\App\Models\ServicioAsignado::estadoBadgeClass($tarea->estado)); ?>">
                                    <?php echo e(\App\Models\ServicioAsignado::estadoLabel($tarea->estado)); ?>

                                </span>
                            </div>

                            <div class="candidate-mobile-meta">
                                <div>
                                    <p class="candidate-mobile-meta-label">Nivel</p>
                                    <p class="candidate-mobile-meta-value"><?php echo e(\App\Models\CatalogoServicio::nivelJerarquicoLabel($tarea->servicio?->nivel_jerarquico)); ?></p>
                                </div>
                                <div>
                                    <p class="candidate-mobile-meta-label">Solicitante</p>
                                    <p class="candidate-mobile-meta-value"><?php echo e($tarea->asignableNombre()); ?></p>
                                </div>
                                <div>
                                    <p class="candidate-mobile-meta-label">Responsable</p>
                                    <p class="candidate-mobile-meta-value"><?php echo e($tarea->asignadoA?->name ?? 'Sin asignar'); ?></p>
                                </div>
                                <div>
                                    <p class="candidate-mobile-meta-label">Dias abiertos</p>
                                    <p class="candidate-mobile-meta-value"><?php echo e($dias); ?> dia(s)</p>
                                </div>
                                <div>
                                    <p class="candidate-mobile-meta-label">Creado</p>
                                    <p class="candidate-mobile-meta-value"><?php echo e($tarea->created_at?->format('d/m/Y') ?? '—'); ?></p>
                                </div>
                            </div>

                            <?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if BLOCK]><![endif]--><?php endif; ?><?php if($urgente): ?>
                                <div style="margin-top:12px; padding:10px 12px; border-radius:10px; background:rgba(254,226,226,.45); color:#b91c1c; font-size:0.82rem;">
                                    Este pedido lleva <?php echo e($dias); ?> dias sin avanzar.
                                </div>
                            <?php endif; ?><?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if ENDBLOCK]><![endif]--><?php endif; ?>

                            <div class="candidate-actions" style="margin-top:14px;">
                                <?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if BLOCK]><![endif]--><?php endif; ?><?php if($tarea->estado === 'pendiente' && ! $tarea->asignado_a): ?>
                                    <a href="<?php echo e(route('admin.tareas.matching', $tarea)); ?>" class="btn btn-primary btn-sm">Asignar</a>
                                <?php elseif($tarea->estado === 'activo'): ?>
                                    <form method="POST" action="<?php echo e(route('admin.tareas.estado', $tarea)); ?>">
                                        <?php echo csrf_field(); ?>
                                        <?php echo method_field('PATCH'); ?>
                                        <input type="hidden" name="estado" value="en_proceso">
                                        <button type="submit" class="btn btn-primary btn-sm">Iniciar</button>
                                    </form>
                                <?php elseif($tarea->estado === 'en_proceso'): ?>
                                    <form method="POST" action="<?php echo e(route('admin.tareas.estado', $tarea)); ?>">
                                        <?php echo csrf_field(); ?>
                                        <?php echo method_field('PATCH'); ?>
                                        <input type="hidden" name="estado" value="completado">
                                        <button type="submit" class="btn btn-success btn-sm">Completar</button>
                                    </form>
                                <?php elseif(in_array($tarea->estado, ['completado', 'cancelado'], true)): ?>
                                    <button type="button" onclick="rhModal('<?php echo e(route('admin.tareas.accion.modal', [$tarea, 'reabrir'])); ?>')" class="btn btn-secondary btn-sm">Reabrir</button>
                                <?php endif; ?><?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if ENDBLOCK]><![endif]--><?php endif; ?>

                                <?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if BLOCK]><![endif]--><?php endif; ?><?php if($tarea->estado !== 'pendiente' || $tarea->asignado_a): ?>
                                    <a href="<?php echo e(route('admin.tareas.matching', $tarea)); ?>" class="btn btn-secondary btn-sm">Interno</a>
                                <?php endif; ?><?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if ENDBLOCK]><![endif]--><?php endif; ?>

                                <a href="<?php echo e(route('admin.tareas.show', $tarea)); ?>" class="btn btn-secondary btn-sm">Ver</a>
                            </div>
                        </article>
                    <?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><?php \Livewire\Features\SupportCompiledWireKeys\SupportCompiledWireKeys::endLoop(); ?><?php endif; ?><?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?><?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if ENDBLOCK]><![endif]--><?php \Livewire\Features\SupportCompiledWireKeys\SupportCompiledWireKeys::closeLoop(); ?><?php endif; ?>
                </div>
            </div>

            <div style="margin-top:16px; display:flex; justify-content:space-between; align-items:center; gap:12px; flex-wrap:wrap;">
                <span style="font-size:12px; color:#64748b;">Mostrando <?php echo e($tareas->firstItem()); ?>-<?php echo e($tareas->lastItem()); ?> de <?php echo e($tareas->total()); ?></span>
                <?php echo e($tareas->links()); ?>

            </div>
        <?php endif; ?><?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if ENDBLOCK]><![endif]--><?php endif; ?>
    </div>
 <?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginal9ac128a9029c0e4701924bd2d73d7f54)): ?>
<?php $attributes = $__attributesOriginal9ac128a9029c0e4701924bd2d73d7f54; ?>
<?php unset($__attributesOriginal9ac128a9029c0e4701924bd2d73d7f54); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal9ac128a9029c0e4701924bd2d73d7f54)): ?>
<?php $component = $__componentOriginal9ac128a9029c0e4701924bd2d73d7f54; ?>
<?php unset($__componentOriginal9ac128a9029c0e4701924bd2d73d7f54); ?>
<?php endif; ?>
<?php /**PATH C:\Dev\Web\SistemaRH_Laravel\resources\views/admin/servicios-asignados/index.blade.php ENDPATH**/ ?>