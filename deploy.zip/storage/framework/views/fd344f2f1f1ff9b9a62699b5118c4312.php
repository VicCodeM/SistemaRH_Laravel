<div style="display:flex; flex-direction:column; height:100%;">
    
    <div class="chat-conv-header">
        <a href="<?php echo e(route('chat.index')); ?>" class="chat-back-btn" title="Volver a conversaciones">
            <svg width="20" height="20" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><path d="M15 18l-6-6 6-6"/></svg>
        </a>
        <?php if (isset($component)) { $__componentOriginal8ca5b43b8fff8bb34ab2ba4eb4bdd67b = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginal8ca5b43b8fff8bb34ab2ba4eb4bdd67b = $attributes; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.avatar','data' => ['src' => $otroUsuario?->avatar_url,'nombre' => $otroUsuario?->name ?? ($room->nombre ?? 'Chat'),'tamano' => 42]] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('avatar'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\Illuminate\View\AnonymousComponent::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes(['src' => \Illuminate\View\Compilers\BladeCompiler::sanitizeComponentAttribute($otroUsuario?->avatar_url),'nombre' => \Illuminate\View\Compilers\BladeCompiler::sanitizeComponentAttribute($otroUsuario?->name ?? ($room->nombre ?? 'Chat')),'tamano' => 42]); ?>
<?php \Livewire\Features\SupportCompiledWireKeys\SupportCompiledWireKeys::processComponentKey($component); ?>

<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginal8ca5b43b8fff8bb34ab2ba4eb4bdd67b)): ?>
<?php $attributes = $__attributesOriginal8ca5b43b8fff8bb34ab2ba4eb4bdd67b; ?>
<?php unset($__attributesOriginal8ca5b43b8fff8bb34ab2ba4eb4bdd67b); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal8ca5b43b8fff8bb34ab2ba4eb4bdd67b)): ?>
<?php $component = $__componentOriginal8ca5b43b8fff8bb34ab2ba4eb4bdd67b; ?>
<?php unset($__componentOriginal8ca5b43b8fff8bb34ab2ba4eb4bdd67b); ?>
<?php endif; ?>
        <div class="header-info">
            <p class="header-name"><?php echo e($otroUsuario?->name ?? ($room->nombre ?? 'Chat')); ?></p>
            <p class="header-status">
                <?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if BLOCK]><![endif]--><?php endif; ?><?php if($otroEscribiendo): ?>
                    <span class="chat-typing-label">escribiendo…</span>
                <?php elseif($otroEnLinea): ?>
                    <span class="status-dot"></span> en línea
                <?php elseif($otroUltimaVez): ?>
                    <span class="status-dot offline"></span> últ. vez <?php echo e($otroUltimaVez); ?>

                <?php elseif($otroUsuario): ?>
                    <?php echo e(ucfirst($otroUsuario->rol)); ?>

                <?php else: ?>
                    <?php echo e(\App\Models\ChatRoom::tipoLabel($room->tipo)); ?>

                <?php endif; ?><?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if ENDBLOCK]><![endif]--><?php endif; ?>
            </p>
        </div>
    </div>

    
    <div id="chat-mensajes">
        <?php $fechaAnterior = null; $emisorAnterior = null; ?>
        <?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if BLOCK]><![endif]--><?php \Livewire\Features\SupportCompiledWireKeys\SupportCompiledWireKeys::openLoop(); ?><?php endif; ?><?php $__empty_1 = true; $__currentLoopData = $mensajes; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $msg): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?><?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><?php \Livewire\Features\SupportCompiledWireKeys\SupportCompiledWireKeys::startLoopIteration(); ?><?php endif; ?>
            <?php
                $esMio = $msg->sender_user_id === auth()->id();
                $fechaMsg = $msg->created_at->startOfDay();
                $puedeBorrar = $esMio || auth()->user()->esAdmin();
                $mismoEmisor = ($emisorAnterior === $msg->sender_user_id);
                $leido = $otroLeyoHasta >= $msg->id;
            ?>

            <?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if BLOCK]><![endif]--><?php endif; ?><?php if($fechaAnterior === null || !$fechaAnterior->equalTo($fechaMsg)): ?>
                <?php $fechaAnterior = $fechaMsg; $emisorAnterior = null; $mismoEmisor = false; ?>
                <div class="chat-date-separator">
                    <span>
                        <?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if BLOCK]><![endif]--><?php endif; ?><?php if($fechaMsg->isToday()): ?> Hoy
                        <?php elseif($fechaMsg->isYesterday()): ?> Ayer
                        <?php else: ?> <?php echo e($fechaMsg->translatedFormat('d \d\e F')); ?>

                        <?php endif; ?><?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if ENDBLOCK]><![endif]--><?php endif; ?>
                    </span>
                </div>
            <?php endif; ?><?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if ENDBLOCK]><![endif]--><?php endif; ?>

            <div class="chat-bubble-wrap <?php echo e($esMio ? 'mine' : 'theirs'); ?>">
                
                <?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if BLOCK]><![endif]--><?php endif; ?><?php if(!$esMio): ?>
                    <?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if BLOCK]><![endif]--><?php endif; ?><?php if($mismoEmisor): ?>
                        <span class="chat-bubble-av-spacer"></span>
                    <?php else: ?>
                        <?php if (isset($component)) { $__componentOriginal8ca5b43b8fff8bb34ab2ba4eb4bdd67b = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginal8ca5b43b8fff8bb34ab2ba4eb4bdd67b = $attributes; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.avatar','data' => ['src' => $msg->sender?->avatar_url,'nombre' => $msg->sender?->name ?? 'Usuario','tamano' => 30,'class' => 'chat-bubble-av']] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('avatar'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\Illuminate\View\AnonymousComponent::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes(['src' => \Illuminate\View\Compilers\BladeCompiler::sanitizeComponentAttribute($msg->sender?->avatar_url),'nombre' => \Illuminate\View\Compilers\BladeCompiler::sanitizeComponentAttribute($msg->sender?->name ?? 'Usuario'),'tamano' => 30,'class' => 'chat-bubble-av']); ?>
<?php \Livewire\Features\SupportCompiledWireKeys\SupportCompiledWireKeys::processComponentKey($component); ?>

<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginal8ca5b43b8fff8bb34ab2ba4eb4bdd67b)): ?>
<?php $attributes = $__attributesOriginal8ca5b43b8fff8bb34ab2ba4eb4bdd67b; ?>
<?php unset($__attributesOriginal8ca5b43b8fff8bb34ab2ba4eb4bdd67b); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal8ca5b43b8fff8bb34ab2ba4eb4bdd67b)): ?>
<?php $component = $__componentOriginal8ca5b43b8fff8bb34ab2ba4eb4bdd67b; ?>
<?php unset($__componentOriginal8ca5b43b8fff8bb34ab2ba4eb4bdd67b); ?>
<?php endif; ?>
                    <?php endif; ?><?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if ENDBLOCK]><![endif]--><?php endif; ?>
                <?php endif; ?><?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if ENDBLOCK]><![endif]--><?php endif; ?>

                <div class="chat-bubble">
                    <?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if BLOCK]><![endif]--><?php endif; ?><?php if(!$esMio && $room->tipo === 'grupal' && !$mismoEmisor): ?>
                        <p class="chat-bubble-sender"><?php echo e($msg->sender?->name ?? 'Usuario'); ?></p>
                    <?php endif; ?><?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if ENDBLOCK]><![endif]--><?php endif; ?>
                    <div class="chat-bubble-text"><?php echo e($msg->contenido); ?></div>
                    <div class="chat-bubble-time">
                        <?php echo e($msg->created_at->format('H:i')); ?>

                        <?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if BLOCK]><![endif]--><?php endif; ?><?php if($esMio): ?>
                            <span class="chat-ticks <?php echo e($leido ? 'leido' : ''); ?>" title="<?php echo e($leido ? 'Leído' : 'Entregado'); ?>">
                                <svg viewBox="0 0 16 11" width="16" height="11" fill="none" stroke="currentColor" stroke-width="1.5" stroke-linecap="round" stroke-linejoin="round">
                                    <path d="M1 6.2 3.6 8.8 8.1 3.2"/>
                                    <path d="M6.4 8.8 10.9 3.2"/>
                                </svg>
                            </span>
                        <?php endif; ?><?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if ENDBLOCK]><![endif]--><?php endif; ?>
                    </div>

                    <?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if BLOCK]><![endif]--><?php endif; ?><?php if($puedeBorrar): ?>
                        <div class="chat-msg-actions">
                            <button type="button" wire:click="eliminarMensaje(<?php echo e($msg->id); ?>)"
                                wire:confirm="¿Eliminar este mensaje?" title="Eliminar mensaje">×</button>
                        </div>
                    <?php endif; ?><?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if ENDBLOCK]><![endif]--><?php endif; ?>
                </div>
            </div>

            <?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if BLOCK]><![endif]--><?php endif; ?><?php if($loop->last && $esMio && $leido): ?>
                <div class="chat-visto">Visto</div>
            <?php endif; ?><?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if ENDBLOCK]><![endif]--><?php endif; ?>

            <?php $emisorAnterior = $msg->sender_user_id; ?>
        <?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><?php \Livewire\Features\SupportCompiledWireKeys\SupportCompiledWireKeys::endLoop(); ?><?php endif; ?><?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?><?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><?php \Livewire\Features\SupportCompiledWireKeys\SupportCompiledWireKeys::closeLoop(); ?><?php endif; ?>
            <div style="flex:1; display:flex; align-items:center; justify-content:center;">
                <div style="text-align:center;">
                    <p style="color:var(--text-muted); font-size:14px; margin:0 0 4px;">Sé el primero en escribir</p>
                    <p style="color:var(--text-muted); font-size:12px; margin:0; opacity:0.7;">Los mensajes se guardan de forma segura</p>
                </div>
            </div>
        <?php endif; ?><?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if ENDBLOCK]><![endif]--><?php endif; ?>

        
        <?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if BLOCK]><![endif]--><?php endif; ?><?php if($otroEscribiendo): ?>
            <div class="chat-typing-wrap">
                <?php if (isset($component)) { $__componentOriginal8ca5b43b8fff8bb34ab2ba4eb4bdd67b = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginal8ca5b43b8fff8bb34ab2ba4eb4bdd67b = $attributes; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.avatar','data' => ['src' => $otroUsuario?->avatar_url,'nombre' => $otroUsuario?->name ?? 'Usuario','tamano' => 30,'class' => 'chat-bubble-av']] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('avatar'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\Illuminate\View\AnonymousComponent::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes(['src' => \Illuminate\View\Compilers\BladeCompiler::sanitizeComponentAttribute($otroUsuario?->avatar_url),'nombre' => \Illuminate\View\Compilers\BladeCompiler::sanitizeComponentAttribute($otroUsuario?->name ?? 'Usuario'),'tamano' => 30,'class' => 'chat-bubble-av']); ?>
<?php \Livewire\Features\SupportCompiledWireKeys\SupportCompiledWireKeys::processComponentKey($component); ?>

<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginal8ca5b43b8fff8bb34ab2ba4eb4bdd67b)): ?>
<?php $attributes = $__attributesOriginal8ca5b43b8fff8bb34ab2ba4eb4bdd67b; ?>
<?php unset($__attributesOriginal8ca5b43b8fff8bb34ab2ba4eb4bdd67b); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal8ca5b43b8fff8bb34ab2ba4eb4bdd67b)): ?>
<?php $component = $__componentOriginal8ca5b43b8fff8bb34ab2ba4eb4bdd67b; ?>
<?php unset($__componentOriginal8ca5b43b8fff8bb34ab2ba4eb4bdd67b); ?>
<?php endif; ?>
                <div class="chat-typing-bubble"><span></span><span></span><span></span></div>
            </div>
        <?php endif; ?><?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if ENDBLOCK]><![endif]--><?php endif; ?>
    </div>

    
    <div class="chat-input-area">
        <form id="chat-form" wire:submit="enviar" class="chat-input-form">
            <textarea id="chat-textarea" wire:model="mensaje" rows="1" autocomplete="off"
                placeholder="Escribe un mensaje..." class="chat-input-textarea" spellcheck="true" autocorrect="on" autocapitalize="sentences" lang="es-MX"></textarea>
            <button type="submit" class="chat-input-btn" title="Enviar (Enter)">
                <svg width="18" height="18" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><path d="M22 2 11 13M22 2l-7 20-4-9-9-4 20-7z"/></svg>
            </button>
        </form>
        <?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if BLOCK]><![endif]--><?php endif; ?><?php $__errorArgs = ['mensaje'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> <p style="color:var(--danger); font-size:12px; margin-top:4px;"><?php echo e($message); ?></p> <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?><?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if ENDBLOCK]><![endif]--><?php endif; ?>
    </div>

        <?php
        $__scriptKey = '669344583-0';
        ob_start();
    ?>
    <script>
        const cont = document.getElementById('chat-mensajes');
        const ta = document.getElementById('chat-textarea');
        let cerca = true;
        let listo = false;
        let ultimoPing = 0;
        const snd = window.rhSonido || {};

        function abajo() { if (cont) cont.scrollTop = cont.scrollHeight; }

        // Muestra el mensaje inmediatamente sin esperar al servidor
        function chatOptimisticSend(txt) {
            if (!cont) return;
            const hora = new Date().toLocaleTimeString('es-MX', { hour: '2-digit', minute: '2-digit', hour12: false });
            const wrap = document.createElement('div');
            wrap.className = 'chat-bubble-wrap mine chat-optimistic';
            wrap.innerHTML = '<div class="chat-bubble"><div class="chat-bubble-text">' + txt.replace(/&/g,'&amp;').replace(/</g,'&lt;') + '</div><div class="chat-bubble-time">' + hora + '</div></div>';
            cont.appendChild(wrap);
            abajo();
        }

        if (cont) {
            cont.addEventListener('scroll', () => {
                cerca = (cont.scrollHeight - cont.scrollTop - cont.clientHeight) < 90;
            });

            requestAnimationFrame(abajo);
            setTimeout(() => { listo = true; }, 600);

            new MutationObserver((muts) => {
                let mio = false, ajeno = false, escribiendo = false;
                muts.forEach(m => m.addedNodes.forEach(n => {
                    if (n.nodeType !== 1 || !n.classList) return;
                    if (n.classList.contains('chat-bubble-wrap') && !n.classList.contains('chat-optimistic')) {
                        n.classList.contains('mine') ? (mio = true) : (ajeno = true);
                    } else if (n.classList.contains('chat-typing-wrap')) {
                        escribiendo = true;
                    }
                }));

                // Limpiar burbujas optimistas cuando llega la respuesta real
                if (mio) document.querySelectorAll('.chat-optimistic').forEach(el => el.remove());

                if (ajeno) { sondeoTouch(); if (listo && snd.recibido) snd.recibido(); }
                if (escribiendo && listo && snd.escribiendo) snd.escribiendo();
                if (mio || escribiendo || cerca) abajo();
                if (mio && ta) ta.focus();
            }).observe(cont, { childList: true });
        }

        function chatEnviarRapido() {
            if (!ta) return;
            const txt = ta.value.trim();
            if (txt === '') return;
            chatOptimisticSend(txt);
            ta.value = '';
            if (snd.enviado) snd.enviado();
            $wire.set('mensaje', txt);
            $wire.enviar();
        }

        if (ta) {
            ta.focus();
            ta.addEventListener('keydown', (e) => {
                if (e.key === 'Enter' && !e.shiftKey) {
                    e.preventDefault();
                    chatEnviarRapido();
                }
            });
            ta.addEventListener('input', () => {
                const ahora = Date.now();
                if (ahora - ultimoPing > 2000) {
                    ultimoPing = ahora;
                    $wire.escribiendo();
                }
            });
        }

        const chatForm = document.getElementById('chat-form');
        if (chatForm) chatForm.addEventListener('submit', (e) => {
            e.preventDefault();
            chatEnviarRapido();
        });

        // ── Sondeo adaptativo (reemplaza wire:poll) ──────────────────
        // Activo: 500ms · Idle 15s: 2s · Idle 60s: 5s · Tab oculta: pausa
        let sondeoTimer = null;
        let sondeoActividad = Date.now();
        let sondeoThrottle = 0;

        function sondeoPoll() {
            if (document.hidden) { sondeoSchedule(); return; }
            $wire.actualizarMensajes()
                .then(() => sondeoSchedule())
                .catch(() => setTimeout(sondeoSchedule, 3000));
        }

        function sondeoSchedule() {
            if (sondeoTimer) clearTimeout(sondeoTimer);
            const idle = Date.now() - sondeoActividad;
            const delay = idle < 15000 ? 500 : idle < 60000 ? 2000 : 5000;
            sondeoTimer = setTimeout(sondeoPoll, delay);
        }

        function sondeoTouch() {
            const now = Date.now();
            if (now - sondeoThrottle < 2000) return;
            sondeoThrottle = now;
            const estabaInactivo = (now - sondeoActividad) > 15000;
            sondeoActividad = now;
            if (estabaInactivo) { clearTimeout(sondeoTimer); sondeoPoll(); }
        }

        document.addEventListener('mousemove', sondeoTouch, { passive: true });
        document.addEventListener('keydown', sondeoTouch);
        document.addEventListener('visibilitychange', () => {
            if (document.hidden) {
                clearTimeout(sondeoTimer);
            } else {
                sondeoActividad = Date.now();
                sondeoPoll();
            }
        });

        sondeoSchedule();
    </script>
        <?php
        $__output = ob_get_clean();

        \Livewire\store($this)->push('scripts', $__output, $__scriptKey)
    ?>
</div>
<?php /**PATH C:\Dev\Web\SistemaRH_Laravel\resources\views/livewire/chat/chat-conversacion.blade.php ENDPATH**/ ?>