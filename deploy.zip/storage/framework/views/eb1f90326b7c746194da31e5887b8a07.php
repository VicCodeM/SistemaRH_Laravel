<?php if (isset($component)) { $__componentOriginal9ac128a9029c0e4701924bd2d73d7f54 = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginal9ac128a9029c0e4701924bd2d73d7f54 = $attributes; } ?>
<?php $component = App\View\Components\AppLayout::resolve([] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('app-layout'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\App\View\Components\AppLayout::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes([]); ?>
<?php \Livewire\Features\SupportCompiledWireKeys\SupportCompiledWireKeys::processComponentKey($component); ?>

     <?php $__env->slot('header', null, []); ?> 
        <nav class="breadcrumbs">
            <a href="<?php echo e(route('admin.dashboard')); ?>">Administración</a>
            <span class="breadcrumb-sep">&rsaquo;</span>
            <a href="<?php echo e(route('admin.empresas')); ?>">Empresas</a>
            <span class="breadcrumb-sep">&rsaquo;</span>
            <span>Editar</span>
        </nav>
        <div style="display:flex; justify-content:space-between; align-items:flex-start; gap:16px;">
            <div>
                <h1 class="page-title">Editar empresa</h1>
                <p class="page-subtitle"><?php echo e($empresa->nombre_empresa); ?> · <?php echo e($empresa->usuario?->email); ?></p>
            </div>
            <div style="display:flex; gap:10px;">
                <a href="<?php echo e(route('admin.empresas.pdf', $empresa)); ?>" target="_blank" class="btn btn-secondary" title="Descargar ficha completa en PDF">📄 Descargar PDF</a>
                <a href="<?php echo e(route('admin.empresas')); ?>" class="btn btn-secondary">&larr; Volver</a>
            </div>
     <?php $__env->endSlot(); ?>

    <?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if BLOCK]><![endif]--><?php endif; ?><?php if($errors->any()): ?>
        <div style="margin-bottom:16px; padding:12px 16px; background:var(--danger-light); color:var(--danger); border-radius:8px; border-left:4px solid var(--danger); max-width:840px;">
            <ul style="margin:0; padding-left:16px;">
                <?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if BLOCK]><![endif]--><?php \Livewire\Features\SupportCompiledWireKeys\SupportCompiledWireKeys::openLoop(); ?><?php endif; ?><?php $__currentLoopData = $errors->all(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $error): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?><?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><?php \Livewire\Features\SupportCompiledWireKeys\SupportCompiledWireKeys::startLoopIteration(); ?><?php endif; ?>
                    <li><?php echo e($error); ?></li>
                <?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><?php \Livewire\Features\SupportCompiledWireKeys\SupportCompiledWireKeys::endLoop(); ?><?php endif; ?><?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?><?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if ENDBLOCK]><![endif]--><?php \Livewire\Features\SupportCompiledWireKeys\SupportCompiledWireKeys::closeLoop(); ?><?php endif; ?>
            </ul>
        </div>
    <?php endif; ?><?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if ENDBLOCK]><![endif]--><?php endif; ?>

    <form method="POST" action="<?php echo e(route('admin.empresas.actualizar', $empresa)); ?>" style="max-width:840px; display:flex; flex-direction:column; gap:18px;">
        <?php echo csrf_field(); ?>
        <?php echo method_field('PUT'); ?>

        
        <div class="card" style="padding:24px;">
            <h2 style="margin:0 0 16px; font-size:14px; font-weight:700; text-transform:uppercase; letter-spacing:.04em; color:#475569;">Datos generales</h2>

            <div style="display:grid; grid-template-columns:1fr 1fr; gap:14px;">
                <div>
                    <label class="form-label">Nombre comercial *</label>
                    <input type="text" name="nombre_empresa" value="<?php echo e(old('nombre_empresa', $empresa->nombre_empresa)); ?>" required class="form-input" spellcheck="true" autocorrect="on" autocapitalize="sentences" lang="es-MX">
                </div>
                <div>
                    <label class="form-label">Razón social</label>
                    <input type="text" name="razon_social" value="<?php echo e(old('razon_social', $empresa->razon_social)); ?>" class="form-input" spellcheck="true" autocorrect="on" autocapitalize="sentences" lang="es-MX">
                </div>
                <div>
                    <label class="form-label">RFC</label>
                    <input type="text" name="rfc" value="<?php echo e(old('rfc', $empresa->rfc)); ?>" class="form-input" spellcheck="true" autocorrect="on" autocapitalize="none" lang="es-MX">
                </div>
                <div>
                    <label class="form-label">Estado</label>
                    <select name="estado" class="form-input" required>
                        <?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if BLOCK]><![endif]--><?php \Livewire\Features\SupportCompiledWireKeys\SupportCompiledWireKeys::openLoop(); ?><?php endif; ?><?php $__currentLoopData = \App\Models\Empresa::estados(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key => $label): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?><?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><?php \Livewire\Features\SupportCompiledWireKeys\SupportCompiledWireKeys::startLoopIteration(); ?><?php endif; ?>
                            <option value="<?php echo e($key); ?>" <?php if(old('estado', $empresa->estado) === $key): echo 'selected'; endif; ?>><?php echo e($label); ?></option>
                        <?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><?php \Livewire\Features\SupportCompiledWireKeys\SupportCompiledWireKeys::endLoop(); ?><?php endif; ?><?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?><?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if ENDBLOCK]><![endif]--><?php \Livewire\Features\SupportCompiledWireKeys\SupportCompiledWireKeys::closeLoop(); ?><?php endif; ?>
                    </select>
                </div>
            </div>
        </div>

        
        <div class="card" style="padding:24px;">
            <h2 style="margin:0 0 16px; font-size:14px; font-weight:700; text-transform:uppercase; letter-spacing:.04em; color:#475569;">Contacto</h2>

            <div style="display:grid; grid-template-columns:1fr 1fr; gap:14px;">
                <div>
                    <label class="form-label">Nombre del responsable RH</label>
                    <input type="text" name="nombre_rh" value="<?php echo e(old('nombre_rh', $empresa->nombre_rh)); ?>" class="form-input" spellcheck="true" autocorrect="on" autocapitalize="words" lang="es-MX">
                </div>
                <div>
                    <label class="form-label">Teléfono general</label>
                    <input type="text" name="telefono" value="<?php echo e(old('telefono', $empresa->telefono)); ?>" class="form-input" spellcheck="true" autocorrect="on" autocapitalize="off" lang="es-MX">
                </div>
                <div>
                    <label class="form-label">Teléfono directo</label>
                    <input type="text" name="telefono_directo" value="<?php echo e(old('telefono_directo', $empresa->telefono_directo)); ?>" class="form-input" spellcheck="true" autocorrect="on" autocapitalize="off" lang="es-MX">
                </div>
                <div>
                    <label class="form-label">Página web</label>
                    <input type="text" name="pagina_web" value="<?php echo e(old('pagina_web', $empresa->pagina_web)); ?>" placeholder="https://..." class="form-input" spellcheck="true" autocorrect="on" autocapitalize="none" lang="es-MX">
                </div>
            </div>
        </div>

        
        <div class="card" style="padding:24px;">
            <h2 style="margin:0 0 16px; font-size:14px; font-weight:700; text-transform:uppercase; letter-spacing:.04em; color:#475569;">Ubicación</h2>

            <div style="display:grid; grid-template-columns:2fr 1fr 1fr 100px; gap:14px;">
                <div>
                    <label class="form-label">Dirección</label>
                    <input type="text" name="direccion" value="<?php echo e(old('direccion', $empresa->direccion)); ?>" class="form-input" spellcheck="true" autocorrect="on" autocapitalize="sentences" lang="es-MX">
                </div>
                <div>
                    <label class="form-label">Ciudad</label>
                    <input type="text" name="ciudad" value="<?php echo e(old('ciudad', $empresa->ciudad)); ?>" class="form-input" spellcheck="true" autocorrect="on" autocapitalize="sentences" lang="es-MX">
                </div>
                <div>
                    <label class="form-label">Municipio</label>
                    <input type="text" name="municipio" value="<?php echo e(old('municipio', $empresa->municipio)); ?>" class="form-input" spellcheck="true" autocorrect="on" autocapitalize="sentences" lang="es-MX">
                </div>
                <div>
                    <label class="form-label">CP</label>
                    <input type="text" name="codigo_postal" value="<?php echo e(old('codigo_postal', $empresa->codigo_postal)); ?>" class="form-input" spellcheck="true" autocorrect="on" autocapitalize="none" lang="es-MX">
                </div>
            </div>
        </div>

        
        <div class="card" style="padding:24px;">
            <h2 style="margin:0 0 16px; font-size:14px; font-weight:700; text-transform:uppercase; letter-spacing:.04em; color:#475569;">Descripción</h2>
            <textarea name="descripcion" rows="4" class="form-input" placeholder="Sector, tamaño, actividad principal..." spellcheck="true" autocorrect="on" autocapitalize="sentences" lang="es-MX"><?php echo e(old('descripcion', $empresa->descripcion)); ?></textarea>
        </div>

        <div style="display:flex; gap:10px; justify-content:flex-end;">
            <a href="<?php echo e(route('admin.empresas')); ?>" class="btn btn-secondary">Cancelar</a>
            <button type="submit" class="btn btn-primary">Guardar cambios</button>
        </div>
    </form>
 <?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginal9ac128a9029c0e4701924bd2d73d7f54)): ?>
<?php $attributes = $__attributesOriginal9ac128a9029c0e4701924bd2d73d7f54; ?>
<?php unset($__attributesOriginal9ac128a9029c0e4701924bd2d73d7f54); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal9ac128a9029c0e4701924bd2d73d7f54)): ?>
<?php $component = $__componentOriginal9ac128a9029c0e4701924bd2d73d7f54; ?>
<?php unset($__componentOriginal9ac128a9029c0e4701924bd2d73d7f54); ?>
<?php endif; ?>
<?php /**PATH C:\Dev\Web\SistemaRH_Laravel\resources\views/admin/empresas/editar.blade.php ENDPATH**/ ?>