<span wire:poll.5s.visible>
    <?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if BLOCK]><![endif]--><?php endif; ?><?php if($this->noLeidos > 0): ?>
        <span style="position:absolute; top:6px; right:6px; min-width:18px; height:18px; background:var(--danger); color:#fff; font-size:10px; font-weight:700; border-radius:9px; display:flex; align-items:center; justify-content:center; padding:0 5px;">
            <?php echo e($this->noLeidos > 99 ? '99+' : $this->noLeidos); ?>

        </span>
    <?php endif; ?><?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if ENDBLOCK]><![endif]--><?php endif; ?>
</span>
<?php /**PATH C:\Dev\Web\SistemaRH_Laravel\resources\views/livewire/chat/chat-notificaciones.blade.php ENDPATH**/ ?>