<?php if (isset($component)) { $__componentOriginal9ac128a9029c0e4701924bd2d73d7f54 = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginal9ac128a9029c0e4701924bd2d73d7f54 = $attributes; } ?>
<?php $component = App\View\Components\AppLayout::resolve([] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('app-layout'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\App\View\Components\AppLayout::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes([]); ?>
<?php \Livewire\Features\SupportCompiledWireKeys\SupportCompiledWireKeys::processComponentKey($component); ?>

     <?php $__env->slot('header', null, []); ?> 
        <nav class="breadcrumbs">
            <a href="<?php echo e(route('admin.dashboard')); ?>">Administracion</a>
            <span class="breadcrumb-sep">&rsaquo;</span>
            <span>Empresas</span>
        </nav>
        <h1 class="page-title">Aprobaciones de acceso - Empresas</h1>
        <p class="page-subtitle"><?php echo e($empresas->total()); ?> empresa(s) registrada(s). Aqui autorizas o rechazas empresas que solicitan usar la plataforma. Esto NO es solicitudes de servicio.</p>
     <?php $__env->endSlot(); ?>

    <?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if BLOCK]><![endif]--><?php endif; ?><?php if(session('success')): ?>
        <div style="margin-bottom:16px; padding:12px 16px; background:var(--success-light); color:var(--success); border-radius:8px; border-left:4px solid var(--success);">
            <?php echo e(session('success')); ?>

        </div>
    <?php endif; ?><?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if ENDBLOCK]><![endif]--><?php endif; ?>
    <?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if BLOCK]><![endif]--><?php endif; ?><?php if(session('error')): ?>
        <div style="margin-bottom:16px; padding:12px 16px; background:var(--danger-light); color:var(--danger); border-radius:8px; border-left:4px solid var(--danger);">
            <?php echo e(session('error')); ?>

        </div>
    <?php endif; ?><?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if ENDBLOCK]><![endif]--><?php endif; ?>

    <?php
        $totalPendientes = \App\Models\Empresa::where('estado', 'pendiente')->count();
        $totalActivas = \App\Models\Empresa::where('estado', 'activa')->count();
        $totalOtras = \App\Models\Empresa::whereIn('estado', ['rechazada', 'suspendida'])->count();
        $estadoActual = request('estado', '');
    ?>

    <div class="toolbar-wrap" style="margin-bottom:20px; align-items:flex-start;">
        <a href="<?php echo e(route('admin.empresas')); ?>"
           style="padding:8px 16px; border-radius:8px; font-size:13px; font-weight:500; text-decoration:none;
                  background:<?php echo e($estadoActual === '' ? 'var(--accent)' : 'var(--surface-2)'); ?>;
                  color:<?php echo e($estadoActual === '' ? '#fff' : 'var(--text-muted)'); ?>;
                  border:1px solid <?php echo e($estadoActual === '' ? 'var(--accent)' : 'var(--border)'); ?>;">
            Todas
        </a>
        <a href="<?php echo e(route('admin.empresas', ['estado' => 'pendiente'])); ?>"
           style="padding:8px 16px; border-radius:8px; font-size:13px; font-weight:500; text-decoration:none;
                  background:<?php echo e($estadoActual === 'pendiente' ? '#f59e0b' : 'var(--surface-2)'); ?>;
                  color:<?php echo e($estadoActual === 'pendiente' ? '#fff' : 'var(--text-muted)'); ?>;
                  border:1px solid <?php echo e($estadoActual === 'pendiente' ? '#f59e0b' : 'var(--border)'); ?>;">
            Pendientes
            <?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if BLOCK]><![endif]--><?php endif; ?><?php if($totalPendientes > 0): ?>
                <span style="margin-left:6px; background:<?php echo e($estadoActual === 'pendiente' ? 'rgba(255,255,255,0.3)' : '#f59e0b'); ?>; color:#fff; border-radius:20px; padding:1px 7px; font-size:11px;"><?php echo e($totalPendientes); ?></span>
            <?php endif; ?><?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if ENDBLOCK]><![endif]--><?php endif; ?>
        </a>
        <a href="<?php echo e(route('admin.empresas', ['estado' => 'activa'])); ?>"
           style="padding:8px 16px; border-radius:8px; font-size:13px; font-weight:500; text-decoration:none;
                  background:<?php echo e($estadoActual === 'activa' ? '#22c55e' : 'var(--surface-2)'); ?>;
                  color:<?php echo e($estadoActual === 'activa' ? '#fff' : 'var(--text-muted)'); ?>;
                  border:1px solid <?php echo e($estadoActual === 'activa' ? '#22c55e' : 'var(--border)'); ?>;">
            Activas
            <?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if BLOCK]><![endif]--><?php endif; ?><?php if($totalActivas > 0): ?>
                <span style="margin-left:6px; background:<?php echo e($estadoActual === 'activa' ? 'rgba(255,255,255,0.3)' : '#22c55e'); ?>; color:#fff; border-radius:20px; padding:1px 7px; font-size:11px;"><?php echo e($totalActivas); ?></span>
            <?php endif; ?><?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if ENDBLOCK]><![endif]--><?php endif; ?>
        </a>
        <?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if BLOCK]><![endif]--><?php endif; ?><?php if($totalOtras > 0): ?>
            <a href="<?php echo e(route('admin.empresas', ['estado' => 'rechazada'])); ?>"
               style="padding:8px 16px; border-radius:8px; font-size:13px; font-weight:500; text-decoration:none;
                      background:<?php echo e(in_array($estadoActual, ['rechazada', 'suspendida']) ? '#ef4444' : 'var(--surface-2)'); ?>;
                      color:<?php echo e(in_array($estadoActual, ['rechazada', 'suspendida']) ? '#fff' : 'var(--text-muted)'); ?>;
                      border:1px solid <?php echo e(in_array($estadoActual, ['rechazada', 'suspendida']) ? '#ef4444' : 'var(--border)'); ?>;">
                Inactivas
                <span style="margin-left:6px; background:rgba(239,68,68,0.15); color:#ef4444; border-radius:20px; padding:1px 7px; font-size:11px;"><?php echo e($totalOtras); ?></span>
            </a>
        <?php endif; ?><?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if ENDBLOCK]><![endif]--><?php endif; ?>

        <form method="GET" class="form-inline toolbar-end">
            <?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if BLOCK]><![endif]--><?php endif; ?><?php if($estadoActual): ?>
                <input type="hidden" name="estado" value="<?php echo e($estadoActual); ?>">
            <?php endif; ?><?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if ENDBLOCK]><![endif]--><?php endif; ?>
            <input type="text" name="buscar" value="<?php echo e(request('buscar')); ?>" placeholder="Nombre o RFC..."
                   style="padding:8px 12px; border:1px solid var(--border); border-radius:8px; font-size:13px; background:var(--surface); min-width:200px;" spellcheck="true" autocorrect="on" autocapitalize="sentences" lang="es-MX">
            <button type="submit" class="btn btn-secondary" style="padding:8px 14px; font-size:13px;">Buscar</button>
            <?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if BLOCK]><![endif]--><?php endif; ?><?php if(request('buscar')): ?>
                <a href="<?php echo e(route('admin.empresas', $estadoActual ? ['estado' => $estadoActual] : [])); ?>" class="btn btn-secondary" style="padding:8px 12px; font-size:13px;">Limpiar</a>
            <?php endif; ?><?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if ENDBLOCK]><![endif]--><?php endif; ?>
        </form>
    </div>

    <div class="table-wrapper">
        <?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if BLOCK]><![endif]--><?php endif; ?><?php if($empresas->isEmpty()): ?>
            <div style="text-align:center; padding:48px; color:#475569;">
                <?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if BLOCK]><![endif]--><?php endif; ?><?php if($estadoActual === 'pendiente'): ?>
                    No hay empresas pendientes de aprobacion. Todo al dia.
                <?php elseif($estadoActual === 'activa'): ?>
                    No hay empresas activas aun.
                <?php else: ?>
                    No hay empresas que coincidan.
                <?php endif; ?><?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if ENDBLOCK]><![endif]--><?php endif; ?>
            </div>
        <?php else: ?>
            <div class="desktop-only table-scroll">
                <table class="table">
                    <thead>
                        <tr>
                            <th>Empresa</th>
                            <th>RFC</th>
                            <th>Contacto</th>
                            <th>Estado</th>
                            <th>Registro</th>
                            <th></th>
                        </tr>
                    </thead>
                    <tbody>
                        <?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if BLOCK]><![endif]--><?php \Livewire\Features\SupportCompiledWireKeys\SupportCompiledWireKeys::openLoop(); ?><?php endif; ?><?php $__currentLoopData = $empresas; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $empresa): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?><?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><?php \Livewire\Features\SupportCompiledWireKeys\SupportCompiledWireKeys::startLoopIteration(); ?><?php endif; ?>
                            <?php
                                $colors = ['pendiente' => 'warning', 'activa' => 'success', 'rechazada' => 'danger', 'suspendida' => 'danger'];
                            ?>
                            <tr>
                                <td>
                                    <div style="display:flex; align-items:center; gap:10px;">
                                        <?php if (isset($component)) { $__componentOriginal8ca5b43b8fff8bb34ab2ba4eb4bdd67b = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginal8ca5b43b8fff8bb34ab2ba4eb4bdd67b = $attributes; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.avatar','data' => ['src' => $empresa->usuario?->avatar_url,'nombre' => $empresa->nombre_empresa,'tamano' => 36]] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('avatar'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\Illuminate\View\AnonymousComponent::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes(['src' => \Illuminate\View\Compilers\BladeCompiler::sanitizeComponentAttribute($empresa->usuario?->avatar_url),'nombre' => \Illuminate\View\Compilers\BladeCompiler::sanitizeComponentAttribute($empresa->nombre_empresa),'tamano' => 36]); ?>
<?php \Livewire\Features\SupportCompiledWireKeys\SupportCompiledWireKeys::processComponentKey($component); ?>

<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginal8ca5b43b8fff8bb34ab2ba4eb4bdd67b)): ?>
<?php $attributes = $__attributesOriginal8ca5b43b8fff8bb34ab2ba4eb4bdd67b; ?>
<?php unset($__attributesOriginal8ca5b43b8fff8bb34ab2ba4eb4bdd67b); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal8ca5b43b8fff8bb34ab2ba4eb4bdd67b)): ?>
<?php $component = $__componentOriginal8ca5b43b8fff8bb34ab2ba4eb4bdd67b; ?>
<?php unset($__componentOriginal8ca5b43b8fff8bb34ab2ba4eb4bdd67b); ?>
<?php endif; ?>
                                        <div>
                                            <div style="font-weight:600; color:var(--text);"><?php echo e($empresa->nombre_empresa); ?></div>
                                            <div style="font-size:12px; color:#64748b;"><?php echo e($empresa->ciudad); ?></div>
                                        </div>
                                    </div>
                                </td>
                                <td style="color:#94a3b8; font-size:0.85rem;"><?php echo e($empresa->rfc ?? '—'); ?></td>
                                <td>
                                    <div style="font-size:13px;"><?php echo e($empresa->usuario?->email); ?></div>
                                    <div style="font-size:12px; color:#64748b;"><?php echo e($empresa->telefono); ?></div>
                                </td>
                                <td>
                                    <span class="badge badge-<?php echo e($colors[$empresa->estado] ?? 'secondary'); ?>">
                                        <?php echo e(\App\Models\Empresa::estadoLabel($empresa->estado)); ?>

                                    </span>
                                </td>
                                <td style="font-size:13px; color:#64748b;"><?php echo e($empresa->created_at?->format('d/m/Y') ?? '—'); ?></td>
                                <td style="white-space:nowrap;">
                                    <div class="toolbar-wrap" style="justify-content:flex-end;">
                                        <button type="button" onclick="rhModal('<?php echo e(route('admin.empresas.modal', $empresa)); ?>')" title="Ver detalle" class="btn btn-ghost" style="width:30px;height:30px;padding:0;">
                                            <svg fill="none" viewBox="0 0 24 24" stroke-width="1.5" stroke="currentColor" style="width:15px;height:15px;"><path stroke-linecap="round" stroke-linejoin="round" d="M2.036 12.322a1.012 1.012 0 010-.639C3.423 7.51 7.36 4.5 12 4.5c4.638 0 8.573 3.007 9.963 7.178.07.207.07.431 0 .639C20.577 16.49 16.64 19.5 12 19.5c-4.638 0-8.573-3.007-9.963-7.178z"/><path stroke-linecap="round" stroke-linejoin="round" d="M15 12a3 3 0 11-6 0 3 3 0 016 0z"/></svg>
                                        </button>
                                        <a href="<?php echo e(route('admin.empresas.pdf', $empresa)); ?>" target="_blank" title="Descargar ficha en PDF" class="btn btn-ghost" style="width:30px; height:30px; padding:0; display:inline-flex; align-items:center; justify-content:center;">PDF</a>
                                        <a href="<?php echo e(route('admin.empresas.editar', $empresa)); ?>" title="Editar datos" class="btn btn-secondary btn-sm">Editar</a>
                                        <?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if BLOCK]><![endif]--><?php endif; ?><?php if($empresa->estado === 'pendiente'): ?>
                                            <form method="POST" action="<?php echo e(route('admin.empresas.aprobar', $empresa)); ?>">
                                                <?php echo csrf_field(); ?>
                                                <?php echo method_field('PATCH'); ?>
                                                <button type="submit" class="btn btn-success btn-sm">Aprobar</button>
                                            </form>
                                            <button type="button" onclick="rhModal('<?php echo e(route('admin.empresas.accion.modal', [$empresa, 'rechazar'])); ?>')" class="btn btn-danger btn-sm">Rechazar</button>
                                        <?php elseif(in_array($empresa->estado, ['rechazada', 'suspendida'])): ?>
                                            <form method="POST" action="<?php echo e(route('admin.empresas.aprobar', $empresa)); ?>">
                                                <?php echo csrf_field(); ?>
                                                <?php echo method_field('PATCH'); ?>
                                                <button type="submit" class="btn btn-success btn-sm">Reactivar</button>
                                            </form>
                                        <?php elseif($empresa->estado === 'activa'): ?>
                                            <button type="button" onclick="rhModal('<?php echo e(route('admin.empresas.accion.modal', [$empresa, 'suspender'])); ?>')" class="btn btn-secondary btn-sm">Suspender</button>
                                        <?php endif; ?><?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if ENDBLOCK]><![endif]--><?php endif; ?>
                                        <button type="button" onclick="rhModal('<?php echo e(route('admin.empresas.accion.modal', [$empresa, 'eliminar'])); ?>')" class="btn btn-danger" style="width:30px;height:30px;padding:0;" title="Eliminar">
                                            <svg fill="none" viewBox="0 0 24 24" stroke-width="1.5" stroke="currentColor" style="width:15px;height:15px;"><path stroke-linecap="round" stroke-linejoin="round" d="M14.74 9l-.346 9m-4.788 0L9.26 9m9.968-3.21c.342.052.682.107 1.022.166m-1.022-.165L18.16 19.673a2.25 2.25 0 01-2.244 2.077H8.084a2.25 2.25 0 01-2.244-2.077L4.772 5.79m14.456 0a48.108 48.108 0 00-3.478-.397M4.772 5.79c.342-.052.682-.107 1.022-.166m1.022.165l.346 9"/></svg>
                                        </button>
                                    </div>
                                </td>
                            </tr>
                        <?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><?php \Livewire\Features\SupportCompiledWireKeys\SupportCompiledWireKeys::endLoop(); ?><?php endif; ?><?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?><?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if ENDBLOCK]><![endif]--><?php \Livewire\Features\SupportCompiledWireKeys\SupportCompiledWireKeys::closeLoop(); ?><?php endif; ?>
                    </tbody>
                </table>
            </div>

            <div class="mobile-only">
                <div class="candidate-mobile-list">
                    <?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if BLOCK]><![endif]--><?php \Livewire\Features\SupportCompiledWireKeys\SupportCompiledWireKeys::openLoop(); ?><?php endif; ?><?php $__currentLoopData = $empresas; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $empresa): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?><?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><?php \Livewire\Features\SupportCompiledWireKeys\SupportCompiledWireKeys::startLoopIteration(); ?><?php endif; ?>
                        <?php
                            $colors = ['pendiente' => 'warning', 'activa' => 'success', 'rechazada' => 'danger', 'suspendida' => 'danger'];
                        ?>
                        <article class="candidate-mobile-card">
                            <div class="candidate-inline-meta">
                                <div style="display:flex; align-items:center; gap:10px; min-width:0;">
                                    <?php if (isset($component)) { $__componentOriginal8ca5b43b8fff8bb34ab2ba4eb4bdd67b = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginal8ca5b43b8fff8bb34ab2ba4eb4bdd67b = $attributes; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.avatar','data' => ['src' => $empresa->usuario?->avatar_url,'nombre' => $empresa->nombre_empresa,'tamano' => 40]] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('avatar'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\Illuminate\View\AnonymousComponent::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes(['src' => \Illuminate\View\Compilers\BladeCompiler::sanitizeComponentAttribute($empresa->usuario?->avatar_url),'nombre' => \Illuminate\View\Compilers\BladeCompiler::sanitizeComponentAttribute($empresa->nombre_empresa),'tamano' => 40]); ?>
<?php \Livewire\Features\SupportCompiledWireKeys\SupportCompiledWireKeys::processComponentKey($component); ?>

<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginal8ca5b43b8fff8bb34ab2ba4eb4bdd67b)): ?>
<?php $attributes = $__attributesOriginal8ca5b43b8fff8bb34ab2ba4eb4bdd67b; ?>
<?php unset($__attributesOriginal8ca5b43b8fff8bb34ab2ba4eb4bdd67b); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal8ca5b43b8fff8bb34ab2ba4eb4bdd67b)): ?>
<?php $component = $__componentOriginal8ca5b43b8fff8bb34ab2ba4eb4bdd67b; ?>
<?php unset($__componentOriginal8ca5b43b8fff8bb34ab2ba4eb4bdd67b); ?>
<?php endif; ?>
                                    <div style="min-width:0;">
                                        <h3 class="candidate-mobile-card-title"><?php echo e($empresa->nombre_empresa); ?></h3>
                                        <p class="candidate-mobile-card-subtitle"><?php echo e($empresa->ciudad ?: 'Sin ciudad'); ?></p>
                                    </div>
                                </div>
                                <span class="badge badge-<?php echo e($colors[$empresa->estado] ?? 'secondary'); ?>">
                                    <?php echo e(\App\Models\Empresa::estadoLabel($empresa->estado)); ?>

                                </span>
                            </div>

                            <div class="candidate-mobile-meta">
                                <div>
                                    <p class="candidate-mobile-meta-label">Contacto</p>
                                    <p class="candidate-mobile-meta-value"><?php echo e($empresa->usuario?->email ?? '—'); ?></p>
                                </div>
                                <div>
                                    <p class="candidate-mobile-meta-label">Telefono</p>
                                    <p class="candidate-mobile-meta-value"><?php echo e($empresa->telefono ?: '—'); ?></p>
                                </div>
                                <div>
                                    <p class="candidate-mobile-meta-label">RFC</p>
                                    <p class="candidate-mobile-meta-value"><?php echo e($empresa->rfc ?: '—'); ?></p>
                                </div>
                                <div>
                                    <p class="candidate-mobile-meta-label">Registro</p>
                                    <p class="candidate-mobile-meta-value"><?php echo e($empresa->created_at?->format('d/m/Y') ?? '—'); ?></p>
                                </div>
                            </div>

                            <div class="candidate-actions" style="margin-top:14px;">
                                <button type="button" onclick="rhModal('<?php echo e(route('admin.empresas.modal', $empresa)); ?>')" class="btn btn-secondary btn-sm">Ver</button>
                                <a href="<?php echo e(route('admin.empresas.pdf', $empresa)); ?>" target="_blank" class="btn btn-secondary btn-sm">PDF</a>
                                <a href="<?php echo e(route('admin.empresas.editar', $empresa)); ?>" class="btn btn-secondary btn-sm">Editar</a>
                                <?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if BLOCK]><![endif]--><?php endif; ?><?php if($empresa->estado === 'pendiente'): ?>
                                    <form method="POST" action="<?php echo e(route('admin.empresas.aprobar', $empresa)); ?>">
                                        <?php echo csrf_field(); ?>
                                        <?php echo method_field('PATCH'); ?>
                                        <button type="submit" class="btn btn-success btn-sm">Aprobar</button>
                                    </form>
                                    <button type="button" onclick="rhModal('<?php echo e(route('admin.empresas.accion.modal', [$empresa, 'rechazar'])); ?>')" class="btn btn-danger btn-sm">Rechazar</button>
                                <?php elseif(in_array($empresa->estado, ['rechazada', 'suspendida'])): ?>
                                    <form method="POST" action="<?php echo e(route('admin.empresas.aprobar', $empresa)); ?>">
                                        <?php echo csrf_field(); ?>
                                        <?php echo method_field('PATCH'); ?>
                                        <button type="submit" class="btn btn-success btn-sm">Reactivar</button>
                                    </form>
                                <?php elseif($empresa->estado === 'activa'): ?>
                                    <button type="button" onclick="rhModal('<?php echo e(route('admin.empresas.accion.modal', [$empresa, 'suspender'])); ?>')" class="btn btn-secondary btn-sm">Suspender</button>
                                <?php endif; ?><?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if ENDBLOCK]><![endif]--><?php endif; ?>
                                <button type="button" onclick="rhModal('<?php echo e(route('admin.empresas.accion.modal', [$empresa, 'eliminar'])); ?>')" class="btn btn-danger btn-sm">Eliminar</button>
                            </div>
                        </article>
                    <?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><?php \Livewire\Features\SupportCompiledWireKeys\SupportCompiledWireKeys::endLoop(); ?><?php endif; ?><?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?><?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if ENDBLOCK]><![endif]--><?php \Livewire\Features\SupportCompiledWireKeys\SupportCompiledWireKeys::closeLoop(); ?><?php endif; ?>
                </div>
            </div>

            <div style="margin-top:16px;">
                <?php echo e($empresas->links()); ?>

            </div>
        <?php endif; ?><?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if ENDBLOCK]><![endif]--><?php endif; ?>
    </div>
 <?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginal9ac128a9029c0e4701924bd2d73d7f54)): ?>
<?php $attributes = $__attributesOriginal9ac128a9029c0e4701924bd2d73d7f54; ?>
<?php unset($__attributesOriginal9ac128a9029c0e4701924bd2d73d7f54); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal9ac128a9029c0e4701924bd2d73d7f54)): ?>
<?php $component = $__componentOriginal9ac128a9029c0e4701924bd2d73d7f54; ?>
<?php unset($__componentOriginal9ac128a9029c0e4701924bd2d73d7f54); ?>
<?php endif; ?>
<?php /**PATH C:\Dev\Web\SistemaRH_Laravel\resources\views/admin/empresas/index.blade.php ENDPATH**/ ?>