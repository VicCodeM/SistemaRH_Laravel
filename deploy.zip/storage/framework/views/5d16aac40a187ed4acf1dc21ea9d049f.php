<?php if (isset($component)) { $__componentOriginal9ac128a9029c0e4701924bd2d73d7f54 = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginal9ac128a9029c0e4701924bd2d73d7f54 = $attributes; } ?>
<?php $component = App\View\Components\AppLayout::resolve([] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('app-layout'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\App\View\Components\AppLayout::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes([]); ?>
<?php \Livewire\Features\SupportCompiledWireKeys\SupportCompiledWireKeys::processComponentKey($component); ?>

     <?php $__env->slot('header', null, []); ?> 
        <nav class="breadcrumbs">
            <a href="<?php echo e(route('admin.dashboard')); ?>">Inicio</a>
            <span class="breadcrumb-sep">&rsaquo;</span>
            <span>Reportes</span>
        </nav>
        <h1 class="page-title">Reportes</h1>
        <p class="page-subtitle">Indicadores rapidos: aprobaciones de acceso y operacion de vacantes y servicios.</p>
     <?php $__env->endSlot(); ?>

    <div class="card fade-in" style="margin-bottom:18px;">
        <form method="GET" style="display:flex; gap:12px; align-items:end; flex-wrap:wrap;">
            <div>
                <label class="form-label" style="font-size:12px;">Desde</label>
                <input type="date" name="desde" value="<?php echo e(request('desde', now()->startOfMonth()->format('Y-m-d'))); ?>" class="form-input" style="font-size:13px;">
            </div>
            <div>
                <label class="form-label" style="font-size:12px;">Hasta</label>
                <input type="date" name="hasta" value="<?php echo e(request('hasta', now()->format('Y-m-d'))); ?>" class="form-input" style="font-size:13px;">
            </div>
            <button type="submit" class="btn btn-primary" style="font-size:13px;">Filtrar</button>
            <?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if BLOCK]><![endif]--><?php endif; ?><?php if(request('desde') || request('hasta')): ?>
                <a href="<?php echo e(route('admin.reportes')); ?>" class="btn btn-secondary" style="font-size:13px;">Limpiar</a>
            <?php endif; ?><?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if ENDBLOCK]><![endif]--><?php endif; ?>
            <a href="<?php echo e(route('admin.reportes.exportar')); ?>" class="btn btn-secondary" style="font-size:13px; margin-left:auto;">Exportar resumen</a>
        </form>
    </div>

    <h2 style="font-size:1rem; font-weight:700; margin:18px 0 12px; color:var(--text);">Resumen del periodo (<?php echo e($kpis['desde']); ?> -> <?php echo e($kpis['hasta']); ?>)</h2>
    <div class="metrics-grid fade-in" style="margin-bottom:24px;">
        <div class="metric-card" style="border-left:3px solid #22c55e;">
            <div class="metric-top">
                <span class="metric-label">Vacantes cubiertas</span>
            </div>
            <div class="metric-value" style="color:#22c55e;"><?php echo e($kpis['vacantes_cerradas']); ?></div>
            <span class="metric-change" style="font-size:12px; color:#64748b;"><?php echo e($kpis['vacantes_nuevas']); ?> nuevas publicadas</span>
        </div>
        <div class="metric-card" style="border-left:3px solid #3b82f6;">
            <div class="metric-top">
                <span class="metric-label">Servicios completados</span>
            </div>
            <div class="metric-value" style="color:#3b82f6;"><?php echo e($kpis['servicios_completados']); ?></div>
            <span class="metric-change" style="font-size:12px; color:#64748b;"><?php echo e($kpis['servicios_nuevos']); ?> pedidos nuevos</span>
        </div>
        <div class="metric-card" style="border-left:3px solid #a855f7;">
            <div class="metric-top">
                <span class="metric-label">Nuevos candidatos</span>
            </div>
            <div class="metric-value" style="color:#a855f7;"><?php echo e($kpis['candidatos_nuevos']); ?></div>
            <span class="metric-change" style="font-size:12px; color:#64748b;"><?php echo e($kpis['empresas_nuevas']); ?> empresas nuevas</span>
        </div>
        <div class="metric-card" style="border-left:3px solid #f59e0b;">
            <div class="metric-top">
                <span class="metric-label">Promedio para cerrar vacante</span>
            </div>
            <div class="metric-value" style="color:#f59e0b;"><?php echo e($kpis['dias_promedio_cierre'] ?? '—'); ?></div>
            <span class="metric-change" style="font-size:12px; color:#64748b;">Dias desde publicacion hasta cierre</span>
        </div>
    </div>

    <div style="display:grid; grid-template-columns:repeat(auto-fit, minmax(300px, 1fr)); gap:20px; margin-bottom:24px;">
        <div class="card fade-in">
            <h3 style="margin:0 0 14px; font-size:0.95rem; font-weight:700;">Top internos del periodo</h3>
            <?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if BLOCK]><![endif]--><?php endif; ?><?php if($internosTop->isEmpty()): ?>
                <p style="color:#94a3b8; font-size:0.85rem; text-align:center; padding:20px;">Aun no hay servicios completados en este periodo.</p>
            <?php else: ?>
                <div class="desktop-only table-scroll">
                    <table class="table" style="width:100%;">
                        <thead>
                            <tr>
                                <th>Interno</th>
                                <th style="text-align:center;">Completados</th>
                                <th style="text-align:center;">Activos</th>
                            </tr>
                        </thead>
                        <tbody>
                            <?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if BLOCK]><![endif]--><?php \Livewire\Features\SupportCompiledWireKeys\SupportCompiledWireKeys::openLoop(); ?><?php endif; ?><?php $__currentLoopData = $internosTop; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $i): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?><?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><?php \Livewire\Features\SupportCompiledWireKeys\SupportCompiledWireKeys::startLoopIteration(); ?><?php endif; ?>
                                <tr>
                                    <td>
                                        <div style="display:flex; align-items:center; gap:8px;">
                                            <?php if (isset($component)) { $__componentOriginal8ca5b43b8fff8bb34ab2ba4eb4bdd67b = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginal8ca5b43b8fff8bb34ab2ba4eb4bdd67b = $attributes; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.avatar','data' => ['src' => $i->avatar_url,'nombre' => $i->name,'tamano' => 26]] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('avatar'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\Illuminate\View\AnonymousComponent::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes(['src' => \Illuminate\View\Compilers\BladeCompiler::sanitizeComponentAttribute($i->avatar_url),'nombre' => \Illuminate\View\Compilers\BladeCompiler::sanitizeComponentAttribute($i->name),'tamano' => 26]); ?>
<?php \Livewire\Features\SupportCompiledWireKeys\SupportCompiledWireKeys::processComponentKey($component); ?>

<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginal8ca5b43b8fff8bb34ab2ba4eb4bdd67b)): ?>
<?php $attributes = $__attributesOriginal8ca5b43b8fff8bb34ab2ba4eb4bdd67b; ?>
<?php unset($__attributesOriginal8ca5b43b8fff8bb34ab2ba4eb4bdd67b); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal8ca5b43b8fff8bb34ab2ba4eb4bdd67b)): ?>
<?php $component = $__componentOriginal8ca5b43b8fff8bb34ab2ba4eb4bdd67b; ?>
<?php unset($__componentOriginal8ca5b43b8fff8bb34ab2ba4eb4bdd67b); ?>
<?php endif; ?>
                                            <span style="font-weight:500;"><?php echo e($i->name); ?></span>
                                        </div>
                                    </td>
                                    <td style="text-align:center;"><span class="badge badge-green"><?php echo e($i->completados); ?></span></td>
                                    <td style="text-align:center; color:#64748b;"><?php echo e($i->activos); ?></td>
                                </tr>
                            <?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><?php \Livewire\Features\SupportCompiledWireKeys\SupportCompiledWireKeys::endLoop(); ?><?php endif; ?><?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?><?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if ENDBLOCK]><![endif]--><?php \Livewire\Features\SupportCompiledWireKeys\SupportCompiledWireKeys::closeLoop(); ?><?php endif; ?>
                        </tbody>
                    </table>
                </div>
                <div class="mobile-only">
                    <div class="candidate-mobile-list">
                        <?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if BLOCK]><![endif]--><?php \Livewire\Features\SupportCompiledWireKeys\SupportCompiledWireKeys::openLoop(); ?><?php endif; ?><?php $__currentLoopData = $internosTop; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $i): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?><?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><?php \Livewire\Features\SupportCompiledWireKeys\SupportCompiledWireKeys::startLoopIteration(); ?><?php endif; ?>
                            <article class="candidate-mobile-card">
                                <div class="candidate-inline-meta">
                                    <div style="display:flex; align-items:center; gap:10px; min-width:0;">
                                        <?php if (isset($component)) { $__componentOriginal8ca5b43b8fff8bb34ab2ba4eb4bdd67b = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginal8ca5b43b8fff8bb34ab2ba4eb4bdd67b = $attributes; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.avatar','data' => ['src' => $i->avatar_url,'nombre' => $i->name,'tamano' => 40]] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('avatar'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\Illuminate\View\AnonymousComponent::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes(['src' => \Illuminate\View\Compilers\BladeCompiler::sanitizeComponentAttribute($i->avatar_url),'nombre' => \Illuminate\View\Compilers\BladeCompiler::sanitizeComponentAttribute($i->name),'tamano' => 40]); ?>
<?php \Livewire\Features\SupportCompiledWireKeys\SupportCompiledWireKeys::processComponentKey($component); ?>

<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginal8ca5b43b8fff8bb34ab2ba4eb4bdd67b)): ?>
<?php $attributes = $__attributesOriginal8ca5b43b8fff8bb34ab2ba4eb4bdd67b; ?>
<?php unset($__attributesOriginal8ca5b43b8fff8bb34ab2ba4eb4bdd67b); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal8ca5b43b8fff8bb34ab2ba4eb4bdd67b)): ?>
<?php $component = $__componentOriginal8ca5b43b8fff8bb34ab2ba4eb4bdd67b; ?>
<?php unset($__componentOriginal8ca5b43b8fff8bb34ab2ba4eb4bdd67b); ?>
<?php endif; ?>
                                        <div style="min-width:0;">
                                            <h3 class="candidate-mobile-card-title"><?php echo e($i->name); ?></h3>
                                            <p class="candidate-mobile-card-subtitle"><?php echo e($i->email); ?></p>
                                        </div>
                                    </div>
                                    <span class="badge badge-green"><?php echo e($i->completados); ?></span>
                                </div>
                                <div class="candidate-mobile-meta">
                                    <div>
                                        <p class="candidate-mobile-meta-label">Completados</p>
                                        <p class="candidate-mobile-meta-value"><?php echo e($i->completados); ?></p>
                                    </div>
                                    <div>
                                        <p class="candidate-mobile-meta-label">Activos</p>
                                        <p class="candidate-mobile-meta-value"><?php echo e($i->activos); ?></p>
                                    </div>
                                </div>
                            </article>
                        <?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><?php \Livewire\Features\SupportCompiledWireKeys\SupportCompiledWireKeys::endLoop(); ?><?php endif; ?><?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?><?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if ENDBLOCK]><![endif]--><?php \Livewire\Features\SupportCompiledWireKeys\SupportCompiledWireKeys::closeLoop(); ?><?php endif; ?>
                    </div>
                </div>
            <?php endif; ?><?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if ENDBLOCK]><![endif]--><?php endif; ?>
        </div>

        <div class="card fade-in">
            <h3 style="margin:0 0 14px; font-size:0.95rem; font-weight:700;">Top empresas del periodo</h3>
            <?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if BLOCK]><![endif]--><?php endif; ?><?php if($empresasTop->isEmpty()): ?>
                <p style="color:#94a3b8; font-size:0.85rem; text-align:center; padding:20px;">Sin empresas activas en este periodo.</p>
            <?php else: ?>
                <div class="desktop-only table-scroll">
                    <table class="table" style="width:100%;">
                        <thead>
                            <tr>
                                <th>Empresa</th>
                                <th style="text-align:center;">Vacantes</th>
                            </tr>
                        </thead>
                        <tbody>
                            <?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if BLOCK]><![endif]--><?php \Livewire\Features\SupportCompiledWireKeys\SupportCompiledWireKeys::openLoop(); ?><?php endif; ?><?php $__currentLoopData = $empresasTop; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $e): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?><?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><?php \Livewire\Features\SupportCompiledWireKeys\SupportCompiledWireKeys::startLoopIteration(); ?><?php endif; ?>
                                <tr>
                                    <td>
                                        <div style="display:flex; align-items:center; gap:8px;">
                                            <?php if (isset($component)) { $__componentOriginal8ca5b43b8fff8bb34ab2ba4eb4bdd67b = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginal8ca5b43b8fff8bb34ab2ba4eb4bdd67b = $attributes; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.avatar','data' => ['src' => $e->usuario?->avatar_url,'nombre' => $e->nombre_empresa,'tamano' => 26]] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('avatar'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\Illuminate\View\AnonymousComponent::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes(['src' => \Illuminate\View\Compilers\BladeCompiler::sanitizeComponentAttribute($e->usuario?->avatar_url),'nombre' => \Illuminate\View\Compilers\BladeCompiler::sanitizeComponentAttribute($e->nombre_empresa),'tamano' => 26]); ?>
<?php \Livewire\Features\SupportCompiledWireKeys\SupportCompiledWireKeys::processComponentKey($component); ?>

<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginal8ca5b43b8fff8bb34ab2ba4eb4bdd67b)): ?>
<?php $attributes = $__attributesOriginal8ca5b43b8fff8bb34ab2ba4eb4bdd67b; ?>
<?php unset($__attributesOriginal8ca5b43b8fff8bb34ab2ba4eb4bdd67b); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal8ca5b43b8fff8bb34ab2ba4eb4bdd67b)): ?>
<?php $component = $__componentOriginal8ca5b43b8fff8bb34ab2ba4eb4bdd67b; ?>
<?php unset($__componentOriginal8ca5b43b8fff8bb34ab2ba4eb4bdd67b); ?>
<?php endif; ?>
                                            <span style="font-weight:500;"><?php echo e($e->nombre_empresa); ?></span>
                                        </div>
                                    </td>
                                    <td style="text-align:center;"><span class="badge badge-blue"><?php echo e($e->vacantes_periodo); ?></span></td>
                                </tr>
                            <?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><?php \Livewire\Features\SupportCompiledWireKeys\SupportCompiledWireKeys::endLoop(); ?><?php endif; ?><?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?><?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if ENDBLOCK]><![endif]--><?php \Livewire\Features\SupportCompiledWireKeys\SupportCompiledWireKeys::closeLoop(); ?><?php endif; ?>
                        </tbody>
                    </table>
                </div>
                <div class="mobile-only">
                    <div class="candidate-mobile-list">
                        <?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if BLOCK]><![endif]--><?php \Livewire\Features\SupportCompiledWireKeys\SupportCompiledWireKeys::openLoop(); ?><?php endif; ?><?php $__currentLoopData = $empresasTop; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $e): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?><?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><?php \Livewire\Features\SupportCompiledWireKeys\SupportCompiledWireKeys::startLoopIteration(); ?><?php endif; ?>
                            <article class="candidate-mobile-card">
                                <div class="candidate-inline-meta">
                                    <div style="display:flex; align-items:center; gap:10px; min-width:0;">
                                        <?php if (isset($component)) { $__componentOriginal8ca5b43b8fff8bb34ab2ba4eb4bdd67b = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginal8ca5b43b8fff8bb34ab2ba4eb4bdd67b = $attributes; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.avatar','data' => ['src' => $e->usuario?->avatar_url,'nombre' => $e->nombre_empresa,'tamano' => 40]] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('avatar'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\Illuminate\View\AnonymousComponent::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes(['src' => \Illuminate\View\Compilers\BladeCompiler::sanitizeComponentAttribute($e->usuario?->avatar_url),'nombre' => \Illuminate\View\Compilers\BladeCompiler::sanitizeComponentAttribute($e->nombre_empresa),'tamano' => 40]); ?>
<?php \Livewire\Features\SupportCompiledWireKeys\SupportCompiledWireKeys::processComponentKey($component); ?>

<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginal8ca5b43b8fff8bb34ab2ba4eb4bdd67b)): ?>
<?php $attributes = $__attributesOriginal8ca5b43b8fff8bb34ab2ba4eb4bdd67b; ?>
<?php unset($__attributesOriginal8ca5b43b8fff8bb34ab2ba4eb4bdd67b); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal8ca5b43b8fff8bb34ab2ba4eb4bdd67b)): ?>
<?php $component = $__componentOriginal8ca5b43b8fff8bb34ab2ba4eb4bdd67b; ?>
<?php unset($__componentOriginal8ca5b43b8fff8bb34ab2ba4eb4bdd67b); ?>
<?php endif; ?>
                                        <div style="min-width:0;">
                                            <h3 class="candidate-mobile-card-title"><?php echo e($e->nombre_empresa); ?></h3>
                                            <p class="candidate-mobile-card-subtitle">Vacantes del periodo</p>
                                        </div>
                                    </div>
                                    <span class="badge badge-blue"><?php echo e($e->vacantes_periodo); ?></span>
                                </div>
                            </article>
                        <?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><?php \Livewire\Features\SupportCompiledWireKeys\SupportCompiledWireKeys::endLoop(); ?><?php endif; ?><?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?><?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if ENDBLOCK]><![endif]--><?php \Livewire\Features\SupportCompiledWireKeys\SupportCompiledWireKeys::closeLoop(); ?><?php endif; ?>
                    </div>
                </div>
            <?php endif; ?><?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if ENDBLOCK]><![endif]--><?php endif; ?>
        </div>
    </div>

    <h2 style="font-size:1rem; font-weight:700; margin:18px 0 12px; color:var(--text);">Totales del sistema</h2>
    <div class="metrics-grid fade-in" style="margin-bottom:24px;">
        <div class="metric-card">
            <div class="metric-top">
                <span class="metric-label">Empresas</span>
            </div>
            <div class="metric-value"><?php echo e($resumen['empresas_total']); ?></div>
            <span class="metric-change" style="font-size:12px;color:#64748b;"><?php echo e($resumen['empresas_activas']); ?> activas / <?php echo e($resumen['empresas_pendientes']); ?> pendientes</span>
        </div>
        <div class="metric-card">
            <div class="metric-top">
                <span class="metric-label">Candidatos</span>
            </div>
            <div class="metric-value"><?php echo e($resumen['candidatos_total']); ?></div>
            <span class="metric-change" style="font-size:12px;color:#64748b;"><?php echo e($resumen['candidatos_aprobados']); ?> aprobados / <?php echo e($resumen['candidatos_pendientes']); ?> por revisar</span>
        </div>
        <div class="metric-card">
            <div class="metric-top">
                <span class="metric-label">Vacantes</span>
            </div>
            <div class="metric-value"><?php echo e($resumen['solicitudes_total']); ?></div>
            <span class="metric-change" style="font-size:12px;color:#64748b;"><?php echo e($resumen['solicitudes_activas']); ?> activas / <?php echo e($resumen['solicitudes_pendientes']); ?> pendientes</span>
        </div>
        <div class="metric-card">
            <div class="metric-top">
                <span class="metric-label">Tareas</span>
            </div>
            <div class="metric-value"><?php echo e($resumen['tareas_total']); ?></div>
            <span class="metric-change" style="font-size:12px;color:#64748b;"><?php echo e($resumen['tareas_activas']); ?> activas o en proceso</span>
        </div>
    </div>

    <div style="display:grid; grid-template-columns:repeat(auto-fit, minmax(300px, 1fr)); gap:24px; margin-top:24px;">
        <div class="card fade-in">
            <div class="candidate-inline-meta" style="margin-bottom:16px;">
                <h3 style="font-weight:700;margin:0;font-size:1rem;">Empresas destacadas</h3>
                <a href="<?php echo e(route('admin.empresas')); ?>" style="font-size:12px;color:var(--accent);text-decoration:none;">Ir a empresas</a>
            </div>
            <?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if BLOCK]><![endif]--><?php endif; ?><?php if($empresasTop->isNotEmpty()): ?>
                <div class="desktop-only table-scroll">
                    <table class="table" style="width:100%;">
                        <thead>
                            <tr>
                                <th>Empresa</th>
                                <th>Estado</th>
                                <th style="text-align:center;">Vacantes</th>
                            </tr>
                        </thead>
                        <tbody>
                            <?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if BLOCK]><![endif]--><?php \Livewire\Features\SupportCompiledWireKeys\SupportCompiledWireKeys::openLoop(); ?><?php endif; ?><?php $__currentLoopData = $empresasTop; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $empresa): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?><?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><?php \Livewire\Features\SupportCompiledWireKeys\SupportCompiledWireKeys::startLoopIteration(); ?><?php endif; ?>
                                <tr>
                                    <td>
                                        <div style="display:flex; align-items:center; gap:8px;">
                                            <?php if (isset($component)) { $__componentOriginal8ca5b43b8fff8bb34ab2ba4eb4bdd67b = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginal8ca5b43b8fff8bb34ab2ba4eb4bdd67b = $attributes; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.avatar','data' => ['src' => $empresa->usuario?->avatar_url,'nombre' => $empresa->nombre_empresa,'tamano' => 26]] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('avatar'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\Illuminate\View\AnonymousComponent::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes(['src' => \Illuminate\View\Compilers\BladeCompiler::sanitizeComponentAttribute($empresa->usuario?->avatar_url),'nombre' => \Illuminate\View\Compilers\BladeCompiler::sanitizeComponentAttribute($empresa->nombre_empresa),'tamano' => 26]); ?>
<?php \Livewire\Features\SupportCompiledWireKeys\SupportCompiledWireKeys::processComponentKey($component); ?>

<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginal8ca5b43b8fff8bb34ab2ba4eb4bdd67b)): ?>
<?php $attributes = $__attributesOriginal8ca5b43b8fff8bb34ab2ba4eb4bdd67b; ?>
<?php unset($__attributesOriginal8ca5b43b8fff8bb34ab2ba4eb4bdd67b); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal8ca5b43b8fff8bb34ab2ba4eb4bdd67b)): ?>
<?php $component = $__componentOriginal8ca5b43b8fff8bb34ab2ba4eb4bdd67b; ?>
<?php unset($__componentOriginal8ca5b43b8fff8bb34ab2ba4eb4bdd67b); ?>
<?php endif; ?>
                                            <span style="font-weight:500;"><?php echo e($empresa->nombre_empresa); ?></span>
                                        </div>
                                    </td>
                                    <td>
                                        <span class="badge <?php echo e(\App\Models\Empresa::estadoBadgeClass($empresa->estado)); ?>"><?php echo e(\App\Models\Empresa::estadoLabel($empresa->estado)); ?></span>
                                    </td>
                                    <td style="text-align:center; color:#64748b;"><?php echo e($empresa->vacantes_periodo ?? $empresa->vacantes_count ?? 0); ?></td>
                                </tr>
                            <?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><?php \Livewire\Features\SupportCompiledWireKeys\SupportCompiledWireKeys::endLoop(); ?><?php endif; ?><?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?><?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if ENDBLOCK]><![endif]--><?php \Livewire\Features\SupportCompiledWireKeys\SupportCompiledWireKeys::closeLoop(); ?><?php endif; ?>
                        </tbody>
                    </table>
                </div>
                <div class="mobile-only">
                    <div class="candidate-mobile-list">
                        <?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if BLOCK]><![endif]--><?php \Livewire\Features\SupportCompiledWireKeys\SupportCompiledWireKeys::openLoop(); ?><?php endif; ?><?php $__currentLoopData = $empresasTop; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $empresa): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?><?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><?php \Livewire\Features\SupportCompiledWireKeys\SupportCompiledWireKeys::startLoopIteration(); ?><?php endif; ?>
                            <article class="candidate-mobile-card">
                                <div class="candidate-inline-meta">
                                    <div style="display:flex; align-items:center; gap:10px; min-width:0;">
                                        <?php if (isset($component)) { $__componentOriginal8ca5b43b8fff8bb34ab2ba4eb4bdd67b = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginal8ca5b43b8fff8bb34ab2ba4eb4bdd67b = $attributes; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.avatar','data' => ['src' => $empresa->usuario?->avatar_url,'nombre' => $empresa->nombre_empresa,'tamano' => 40]] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('avatar'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\Illuminate\View\AnonymousComponent::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes(['src' => \Illuminate\View\Compilers\BladeCompiler::sanitizeComponentAttribute($empresa->usuario?->avatar_url),'nombre' => \Illuminate\View\Compilers\BladeCompiler::sanitizeComponentAttribute($empresa->nombre_empresa),'tamano' => 40]); ?>
<?php \Livewire\Features\SupportCompiledWireKeys\SupportCompiledWireKeys::processComponentKey($component); ?>

<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginal8ca5b43b8fff8bb34ab2ba4eb4bdd67b)): ?>
<?php $attributes = $__attributesOriginal8ca5b43b8fff8bb34ab2ba4eb4bdd67b; ?>
<?php unset($__attributesOriginal8ca5b43b8fff8bb34ab2ba4eb4bdd67b); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal8ca5b43b8fff8bb34ab2ba4eb4bdd67b)): ?>
<?php $component = $__componentOriginal8ca5b43b8fff8bb34ab2ba4eb4bdd67b; ?>
<?php unset($__componentOriginal8ca5b43b8fff8bb34ab2ba4eb4bdd67b); ?>
<?php endif; ?>
                                        <div style="min-width:0;">
                                            <h3 class="candidate-mobile-card-title"><?php echo e($empresa->nombre_empresa); ?></h3>
                                            <p class="candidate-mobile-card-subtitle"><?php echo e(\App\Models\Empresa::estadoLabel($empresa->estado)); ?></p>
                                        </div>
                                    </div>
                                    <span class="badge <?php echo e(\App\Models\Empresa::estadoBadgeClass($empresa->estado)); ?>"><?php echo e($empresa->vacantes_periodo ?? $empresa->vacantes_count ?? 0); ?></span>
                                </div>
                            </article>
                        <?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><?php \Livewire\Features\SupportCompiledWireKeys\SupportCompiledWireKeys::endLoop(); ?><?php endif; ?><?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?><?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if ENDBLOCK]><![endif]--><?php \Livewire\Features\SupportCompiledWireKeys\SupportCompiledWireKeys::closeLoop(); ?><?php endif; ?>
                    </div>
                </div>
            <?php else: ?>
                <div style="text-align:center;padding:24px 0;color:#475569;">
                    <p style="margin:0;font-size:13px;">Aun no hay empresas con solicitudes.</p>
                </div>
            <?php endif; ?><?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if ENDBLOCK]><![endif]--><?php endif; ?>
        </div>

        <div class="card fade-in">
            <div class="candidate-inline-meta" style="margin-bottom:16px;">
                <h3 style="font-weight:700;margin:0;font-size:1rem;">Solicitudes activas</h3>
                <a href="<?php echo e(route('admin.vacantes')); ?>" style="font-size:12px;color:var(--accent);text-decoration:none;">Ir a solicitudes</a>
            </div>
            <?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if BLOCK]><![endif]--><?php endif; ?><?php if($solicitudesActivas->isNotEmpty()): ?>
                <div class="desktop-only table-scroll">
                    <table class="table" style="width:100%;">
                        <thead>
                            <tr>
                                <th>Solicitud</th>
                                <th>Empresa</th>
                                <th>Nivel</th>
                                <th>Estado</th>
                            </tr>
                        </thead>
                        <tbody>
                            <?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if BLOCK]><![endif]--><?php \Livewire\Features\SupportCompiledWireKeys\SupportCompiledWireKeys::openLoop(); ?><?php endif; ?><?php $__currentLoopData = $solicitudesActivas; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $solicitud): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?><?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><?php \Livewire\Features\SupportCompiledWireKeys\SupportCompiledWireKeys::startLoopIteration(); ?><?php endif; ?>
                                <tr>
                                    <td style="font-weight:500;"><?php echo e($solicitud->titulo); ?></td>
                                    <td>
                                        <div style="display:flex; align-items:center; gap:8px;">
                                            <?php if (isset($component)) { $__componentOriginal8ca5b43b8fff8bb34ab2ba4eb4bdd67b = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginal8ca5b43b8fff8bb34ab2ba4eb4bdd67b = $attributes; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.avatar','data' => ['src' => $solicitud->empresa?->usuario?->avatar_url,'nombre' => $solicitud->empresa?->nombre_empresa ?? '?','tamano' => 24]] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('avatar'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\Illuminate\View\AnonymousComponent::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes(['src' => \Illuminate\View\Compilers\BladeCompiler::sanitizeComponentAttribute($solicitud->empresa?->usuario?->avatar_url),'nombre' => \Illuminate\View\Compilers\BladeCompiler::sanitizeComponentAttribute($solicitud->empresa?->nombre_empresa ?? '?'),'tamano' => 24]); ?>
<?php \Livewire\Features\SupportCompiledWireKeys\SupportCompiledWireKeys::processComponentKey($component); ?>

<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginal8ca5b43b8fff8bb34ab2ba4eb4bdd67b)): ?>
<?php $attributes = $__attributesOriginal8ca5b43b8fff8bb34ab2ba4eb4bdd67b; ?>
<?php unset($__attributesOriginal8ca5b43b8fff8bb34ab2ba4eb4bdd67b); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal8ca5b43b8fff8bb34ab2ba4eb4bdd67b)): ?>
<?php $component = $__componentOriginal8ca5b43b8fff8bb34ab2ba4eb4bdd67b; ?>
<?php unset($__componentOriginal8ca5b43b8fff8bb34ab2ba4eb4bdd67b); ?>
<?php endif; ?>
                                            <span><?php echo e($solicitud->empresa?->nombre_empresa ?? '—'); ?></span>
                                        </div>
                                    </td>
                                    <td><?php echo e(\App\Models\CatalogoServicio::nivelJerarquicoLabel($solicitud->nivel_jerarquico)); ?></td>
                                    <td><span class="badge <?php echo e(\App\Models\Vacante::estadoBadgeClass($solicitud->estado)); ?>"><?php echo e(\App\Models\Vacante::estadoLabel($solicitud->estado)); ?></span></td>
                                </tr>
                            <?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><?php \Livewire\Features\SupportCompiledWireKeys\SupportCompiledWireKeys::endLoop(); ?><?php endif; ?><?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?><?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if ENDBLOCK]><![endif]--><?php \Livewire\Features\SupportCompiledWireKeys\SupportCompiledWireKeys::closeLoop(); ?><?php endif; ?>
                        </tbody>
                    </table>
                </div>
                <div class="mobile-only">
                    <div class="candidate-mobile-list">
                        <?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if BLOCK]><![endif]--><?php \Livewire\Features\SupportCompiledWireKeys\SupportCompiledWireKeys::openLoop(); ?><?php endif; ?><?php $__currentLoopData = $solicitudesActivas; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $solicitud): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?><?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><?php \Livewire\Features\SupportCompiledWireKeys\SupportCompiledWireKeys::startLoopIteration(); ?><?php endif; ?>
                            <article class="candidate-mobile-card">
                                <div class="candidate-inline-meta">
                                    <div>
                                        <h3 class="candidate-mobile-card-title"><?php echo e($solicitud->titulo); ?></h3>
                                        <p class="candidate-mobile-card-subtitle"><?php echo e($solicitud->empresa?->nombre_empresa ?? '—'); ?></p>
                                    </div>
                                    <span class="badge <?php echo e(\App\Models\Vacante::estadoBadgeClass($solicitud->estado)); ?>"><?php echo e(\App\Models\Vacante::estadoLabel($solicitud->estado)); ?></span>
                                </div>
                                <div class="candidate-mobile-meta">
                                    <div>
                                        <p class="candidate-mobile-meta-label">Nivel</p>
                                        <p class="candidate-mobile-meta-value"><?php echo e(\App\Models\CatalogoServicio::nivelJerarquicoLabel($solicitud->nivel_jerarquico)); ?></p>
                                    </div>
                                </div>
                            </article>
                        <?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><?php \Livewire\Features\SupportCompiledWireKeys\SupportCompiledWireKeys::endLoop(); ?><?php endif; ?><?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?><?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if ENDBLOCK]><![endif]--><?php \Livewire\Features\SupportCompiledWireKeys\SupportCompiledWireKeys::closeLoop(); ?><?php endif; ?>
                    </div>
                </div>
            <?php else: ?>
                <div style="text-align:center;padding:24px 0;color:#475569;">
                    <p style="margin:0;font-size:13px;">No hay solicitudes activas para mostrar.</p>
                </div>
            <?php endif; ?><?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if ENDBLOCK]><![endif]--><?php endif; ?>
        </div>

        <div class="card fade-in">
            <div class="candidate-inline-meta" style="margin-bottom:16px;">
                <h3 style="font-weight:700;margin:0;font-size:1rem;">Tareas recientes</h3>
                <a href="<?php echo e(route('admin.tareas.index')); ?>" style="font-size:12px;color:var(--accent);text-decoration:none;">Ir a tareas</a>
            </div>
            <?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if BLOCK]><![endif]--><?php endif; ?><?php if($tareasRecientes->isNotEmpty()): ?>
                <div class="desktop-only table-scroll">
                    <table class="table" style="width:100%;">
                        <thead>
                            <tr>
                                <th>Servicio</th>
                                <th>Asignado</th>
                                <th>Estado</th>
                            </tr>
                        </thead>
                        <tbody>
                            <?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if BLOCK]><![endif]--><?php \Livewire\Features\SupportCompiledWireKeys\SupportCompiledWireKeys::openLoop(); ?><?php endif; ?><?php $__currentLoopData = $tareasRecientes; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $tarea): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?><?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><?php \Livewire\Features\SupportCompiledWireKeys\SupportCompiledWireKeys::startLoopIteration(); ?><?php endif; ?>
                                <tr>
                                    <td>
                                        <?php echo e($tarea->servicio?->nombre ?? 'Servicio'); ?>

                                        <div style="font-size:11px;color:#64748b;"><?php echo e($tarea->servicio?->nivel_jerarquico ? \App\Models\CatalogoServicio::nivelJerarquicoLabel($tarea->servicio->nivel_jerarquico) : 'Sin nivel'); ?></div>
                                    </td>
                                    <td>
                                        <?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if BLOCK]><![endif]--><?php endif; ?><?php if($tarea->asignadoA): ?>
                                            <div style="display:flex; align-items:center; gap:8px;">
                                                <?php if (isset($component)) { $__componentOriginal8ca5b43b8fff8bb34ab2ba4eb4bdd67b = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginal8ca5b43b8fff8bb34ab2ba4eb4bdd67b = $attributes; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.avatar','data' => ['src' => $tarea->asignadoA->avatar_url,'nombre' => $tarea->asignadoA->name,'tamano' => 24]] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('avatar'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\Illuminate\View\AnonymousComponent::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes(['src' => \Illuminate\View\Compilers\BladeCompiler::sanitizeComponentAttribute($tarea->asignadoA->avatar_url),'nombre' => \Illuminate\View\Compilers\BladeCompiler::sanitizeComponentAttribute($tarea->asignadoA->name),'tamano' => 24]); ?>
<?php \Livewire\Features\SupportCompiledWireKeys\SupportCompiledWireKeys::processComponentKey($component); ?>

<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginal8ca5b43b8fff8bb34ab2ba4eb4bdd67b)): ?>
<?php $attributes = $__attributesOriginal8ca5b43b8fff8bb34ab2ba4eb4bdd67b; ?>
<?php unset($__attributesOriginal8ca5b43b8fff8bb34ab2ba4eb4bdd67b); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal8ca5b43b8fff8bb34ab2ba4eb4bdd67b)): ?>
<?php $component = $__componentOriginal8ca5b43b8fff8bb34ab2ba4eb4bdd67b; ?>
<?php unset($__componentOriginal8ca5b43b8fff8bb34ab2ba4eb4bdd67b); ?>
<?php endif; ?>
                                                <span><?php echo e($tarea->asignadoA->name); ?></span>
                                            </div>
                                        <?php else: ?>
                                            <span style="color:#94a3b8;">Sin asignar</span>
                                        <?php endif; ?><?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if ENDBLOCK]><![endif]--><?php endif; ?>
                                    </td>
                                    <td><span class="badge <?php echo e(\App\Models\ServicioAsignado::estadoBadgeClass($tarea->estado)); ?>"><?php echo e(\App\Models\ServicioAsignado::estadoLabel($tarea->estado)); ?></span></td>
                                </tr>
                            <?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><?php \Livewire\Features\SupportCompiledWireKeys\SupportCompiledWireKeys::endLoop(); ?><?php endif; ?><?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?><?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if ENDBLOCK]><![endif]--><?php \Livewire\Features\SupportCompiledWireKeys\SupportCompiledWireKeys::closeLoop(); ?><?php endif; ?>
                        </tbody>
                    </table>
                </div>
                <div class="mobile-only">
                    <div class="candidate-mobile-list">
                        <?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if BLOCK]><![endif]--><?php \Livewire\Features\SupportCompiledWireKeys\SupportCompiledWireKeys::openLoop(); ?><?php endif; ?><?php $__currentLoopData = $tareasRecientes; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $tarea): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?><?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><?php \Livewire\Features\SupportCompiledWireKeys\SupportCompiledWireKeys::startLoopIteration(); ?><?php endif; ?>
                            <article class="candidate-mobile-card">
                                <div class="candidate-inline-meta">
                                    <div>
                                        <h3 class="candidate-mobile-card-title"><?php echo e($tarea->servicio?->nombre ?? 'Servicio'); ?></h3>
                                        <p class="candidate-mobile-card-subtitle"><?php echo e($tarea->asignadoA?->name ?? 'Sin asignar'); ?></p>
                                    </div>
                                    <span class="badge <?php echo e(\App\Models\ServicioAsignado::estadoBadgeClass($tarea->estado)); ?>"><?php echo e(\App\Models\ServicioAsignado::estadoLabel($tarea->estado)); ?></span>
                                </div>
                                <div class="candidate-mobile-meta">
                                    <div>
                                        <p class="candidate-mobile-meta-label">Nivel</p>
                                        <p class="candidate-mobile-meta-value"><?php echo e($tarea->servicio?->nivel_jerarquico ? \App\Models\CatalogoServicio::nivelJerarquicoLabel($tarea->servicio->nivel_jerarquico) : 'Sin nivel'); ?></p>
                                    </div>
                                </div>
                            </article>
                        <?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><?php \Livewire\Features\SupportCompiledWireKeys\SupportCompiledWireKeys::endLoop(); ?><?php endif; ?><?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?><?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if ENDBLOCK]><![endif]--><?php \Livewire\Features\SupportCompiledWireKeys\SupportCompiledWireKeys::closeLoop(); ?><?php endif; ?>
                    </div>
                </div>
            <?php else: ?>
                <div style="text-align:center;padding:24px 0;color:#475569;">
                    <p style="margin:0;font-size:13px;">No hay tareas recientes.</p>
                </div>
            <?php endif; ?><?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if ENDBLOCK]><![endif]--><?php endif; ?>
        </div>
    </div>
 <?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginal9ac128a9029c0e4701924bd2d73d7f54)): ?>
<?php $attributes = $__attributesOriginal9ac128a9029c0e4701924bd2d73d7f54; ?>
<?php unset($__attributesOriginal9ac128a9029c0e4701924bd2d73d7f54); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal9ac128a9029c0e4701924bd2d73d7f54)): ?>
<?php $component = $__componentOriginal9ac128a9029c0e4701924bd2d73d7f54; ?>
<?php unset($__componentOriginal9ac128a9029c0e4701924bd2d73d7f54); ?>
<?php endif; ?>
<?php /**PATH C:\Dev\Web\SistemaRH_Laravel\resources\views/admin/reportes/index.blade.php ENDPATH**/ ?>