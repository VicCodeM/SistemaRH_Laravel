<?php if (isset($component)) { $__componentOriginal9ac128a9029c0e4701924bd2d73d7f54 = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginal9ac128a9029c0e4701924bd2d73d7f54 = $attributes; } ?>
<?php $component = App\View\Components\AppLayout::resolve([] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('app-layout'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\App\View\Components\AppLayout::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes([]); ?>
<?php \Livewire\Features\SupportCompiledWireKeys\SupportCompiledWireKeys::processComponentKey($component); ?>

    <?php
        $estado = $candidato->solicitud_estado ?? 'borrador';
        $badgeClass = \App\Models\Candidato::solicitudEstadoBadgeClass($estado) ?? 'badge-gray';
        $estadoLabel = \App\Models\Candidato::solicitudEstadoLabel($estado);
        $aprobado = $estado === 'aprobada';
    ?>

     <?php $__env->slot('header', null, []); ?> 
        <nav class="breadcrumbs">
            <a href="<?php echo e(route('dashboard')); ?>">Inicio</a>
            <span class="breadcrumb-sep">&rsaquo;</span>
            <span>Mi cuenta</span>
        </nav>
        <h1 class="page-title">Panel del candidato</h1>
        <p class="page-subtitle">Revisa tu estado, corrige tu solicitud y consulta tus solicitudes aprobadas.</p>
     <?php $__env->endSlot(); ?>

    <?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if BLOCK]><![endif]--><?php endif; ?><?php if(session('success')): ?>
        <div class="alert alert-success fade-in" style="margin-bottom:16px;"><?php echo e(session('success')); ?></div>
    <?php endif; ?><?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if ENDBLOCK]><![endif]--><?php endif; ?>
    <?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if BLOCK]><![endif]--><?php endif; ?><?php if(session('error')): ?>
        <div class="alert alert-danger fade-in" style="margin-bottom:16px;"><?php echo e(session('error')); ?></div>
    <?php endif; ?><?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if ENDBLOCK]><![endif]--><?php endif; ?>

    <?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if BLOCK]><![endif]--><?php endif; ?><?php if(isset($acciones)): ?>
        <?php if (isset($component)) { $__componentOriginald7446a54d3561f4e6a0f2dc0370a9e36 = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginald7446a54d3561f4e6a0f2dc0370a9e36 = $attributes; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.acciones-pendientes','data' => ['titulo' => '¿Qué sigue?','acciones' => $acciones]] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('acciones-pendientes'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\Illuminate\View\AnonymousComponent::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes(['titulo' => '¿Qué sigue?','acciones' => \Illuminate\View\Compilers\BladeCompiler::sanitizeComponentAttribute($acciones)]); ?>
<?php \Livewire\Features\SupportCompiledWireKeys\SupportCompiledWireKeys::processComponentKey($component); ?>

<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginald7446a54d3561f4e6a0f2dc0370a9e36)): ?>
<?php $attributes = $__attributesOriginald7446a54d3561f4e6a0f2dc0370a9e36; ?>
<?php unset($__attributesOriginald7446a54d3561f4e6a0f2dc0370a9e36); ?>
<?php endif; ?>
<?php if (isset($__componentOriginald7446a54d3561f4e6a0f2dc0370a9e36)): ?>
<?php $component = $__componentOriginald7446a54d3561f4e6a0f2dc0370a9e36; ?>
<?php unset($__componentOriginald7446a54d3561f4e6a0f2dc0370a9e36); ?>
<?php endif; ?>
    <?php endif; ?><?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if ENDBLOCK]><![endif]--><?php endif; ?>

    <div class="metrics-grid fade-in">
        <div class="metric-card">
            <div class="metric-top">
                <span class="metric-label">Estado de la solicitud</span>
                <div class="metric-icon" style="background:rgba(59,130,246,.12);color:#3b82f6;">
                    <svg fill="none" viewBox="0 0 24 24" stroke-width="1.5" stroke="currentColor" style="width:18px;height:18px;">
                        <path stroke-linecap="round" stroke-linejoin="round" d="M9 12h3.75M9 15h3.75M9 18h3.75m3 .75H18a2.25 2.25 0 002.25-2.25V6.108c0-1.135-.845-2.098-1.976-2.192a48.424 48.424 0 00-1.123-.08m-5.801 0c-.065.21-.1.433-.1.664 0 .414.336.75.75.75h4.5a.75.75 0 00.75-.75 2.25 2.25 0 00-.1-.664m-5.8 0A2.251 2.251 0 0113.5 2.25H15c1.012 0 1.867.668 2.15 1.586m-5.8 0c-.376.023-.75.05-1.124.08C9.095 4.01 8.25 4.973 8.25 6.108V8.25m0 0H4.875c-.621 0-1.125.504-1.125 1.125v11.25c0 .621.504 1.125 1.125 1.125h9.75c.621 0 1.125-.504 1.125-1.125V9.375c0-.621-.504-1.125-1.125-1.125H8.25z"/>
                    </svg>
                </div>
            </div>
            <div class="metric-value">
                <span class="badge <?php echo e($badgeClass); ?>"><?php echo e($estadoLabel); ?></span>
            </div>
            <div class="metric-change" style="color:#64748b;font-size:12px;">
                <?php echo e($aprobado ? 'Ya puedes consultar y solicitar vacantes.' : 'Primero termina el proceso de revisión.'); ?>

            </div>
        </div>

        <div class="metric-card">
            <div class="metric-top">
                <span class="metric-label">Postulaciones</span>
                <div class="metric-icon" style="background:rgba(16,185,129,.12);color:#10b981;">
                    <svg fill="none" viewBox="0 0 24 24" stroke-width="1.5" stroke="currentColor" style="width:18px;height:18px;">
                        <path stroke-linecap="round" stroke-linejoin="round" d="M9 12h3.75M9 15h3.75M9 18h3.75m3 .75H18a2.25 2.25 0 002.25-2.25V6.108c0-1.135-.845-2.098-1.976-2.192a48.424 48.424 0 00-1.123-.08m-5.801 0c-.065.21-.1.433-.1.664 0 .414.336.75.75.75h4.5a.75.75 0 00.75-.75 2.25 2.25 0 00-.1-.664m-5.8 0A2.251 2.251 0 0113.5 2.25H15c1.012 0 1.867.668 2.15 1.586m-5.8 0c-.376.023-.75.05-1.124.08C9.095 4.01 8.25 4.973 8.25 6.108V8.25m0 0H4.875c-.621 0-1.125.504-1.125 1.125v11.25c0 .621.504 1.125 1.125 1.125h9.75c.621 0 1.125-.504 1.125-1.125V9.375c0-.621-.504-1.125-1.125-1.125H8.25z"/>
                    </svg>
                </div>
            </div>
            <div class="metric-value"><?php echo e($postulacionesRecientes->count()); ?></div>
            <div class="metric-change" style="color:#64748b;font-size:12px;">
                Últimas <?php echo e(min(4, $postulacionesRecientes->count())); ?> solicitudes visibles
            </div>
        </div>

        <div class="metric-card">
            <div class="metric-top">
                <span class="metric-label">Vacantes activas</span>
                <div class="metric-icon" style="background:rgba(245,158,11,.12);color:#d97706;">
                    <svg fill="none" viewBox="0 0 24 24" stroke-width="1.5" stroke="currentColor" style="width:18px;height:18px;">
                        <path stroke-linecap="round" stroke-linejoin="round" d="M3.75 21h16.5M4.5 3h15M5.25 3v18m13.5-18v18M9 6.75h1.5m-1.5 3h1.5m-1.5 3h1.5m3-6H15m-1.5 3H15m-1.5 3H15M9 21v-3.375c0-.621.504-1.125 1.125-1.125h3.75c.621 0 1.125.504 1.125 1.125V21"/>
                    </svg>
                </div>
            </div>
            <div class="metric-value"><?php echo e($vacantesRecientes->count()); ?></div>
            <div class="metric-change" style="color:#64748b;font-size:12px;">
                Solo visible después de tu aprobación
            </div>
        </div>
    </div>

    <?php
        $ultimaPostulacion = $postulacionesRecientes->first();
    ?>

    <div class="card fade-in" style="margin-top:24px;">
        <div style="display:flex; justify-content:space-between; align-items:flex-start; gap:14px; flex-wrap:wrap;">
            <div>
                <h3 style="font-weight:700; margin:0 0 4px; font-size:1rem;">Estado de tu última postulación</h3>
                <p style="margin:0; color:#64748b; font-size:13px;">
                    Revisa aquí el avance más reciente sin abrir el detalle.
                </p>
            </div>

            <?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if BLOCK]><![endif]--><?php endif; ?><?php if($ultimaPostulacion): ?>
                <span class="badge <?php echo e(\App\Models\Postulacion::estadoBadgeClass($ultimaPostulacion->estado)); ?>">
                    <?php echo e(\App\Models\Postulacion::estadoLabel($ultimaPostulacion->estado)); ?>

                </span>
            <?php endif; ?><?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if ENDBLOCK]><![endif]--><?php endif; ?>
        </div>

        <?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if BLOCK]><![endif]--><?php endif; ?><?php if($ultimaPostulacion): ?>
            <div style="display:grid; grid-template-columns:1fr auto; gap:12px; align-items:center; margin-top:16px; padding:14px 16px; border:1px solid var(--border); border-radius:10px; background:var(--surface-2);">
                <div>
                    <div style="font-weight:600;"><?php echo e($ultimaPostulacion->vacante?->titulo ?? 'Vacante'); ?></div>
                    <div style="font-size:12px; color:#64748b; margin-top:4px;">
                        <?php echo e($ultimaPostulacion->vacante?->empresa?->nombre_empresa ?? 'Empresa'); ?>

                        <?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if BLOCK]><![endif]--><?php endif; ?><?php if($ultimaPostulacion->fecha_postulacion): ?>
                            · <?php echo e($ultimaPostulacion->fecha_postulacion->format('d/m/Y H:i')); ?>

                        <?php endif; ?><?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if ENDBLOCK]><![endif]--><?php endif; ?>
                    </div>
                </div>
                <a href="<?php echo e(route('candidato.postulaciones')); ?>" class="btn btn-secondary btn-sm">Ver seguimiento</a>
            </div>
        <?php else: ?>
            <div style="margin-top:16px; padding:16px; border:1px dashed var(--border); border-radius:10px; color:#64748b; font-size:13px;">
                Todavía no has enviado postulaciones. Cuando apliques a una vacante, aquí verás su estatus.
            </div>
        <?php endif; ?><?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if ENDBLOCK]><![endif]--><?php endif; ?>
    </div>

    <div class="candidate-actions">
        <a href="<?php echo e(route('candidato.solicitud')); ?>" class="btn btn-primary">Mi solicitud</a>
        <?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if BLOCK]><![endif]--><?php endif; ?><?php if($aprobado): ?>
            <a href="<?php echo e(route('candidato.vacantes')); ?>" class="btn btn-secondary">Solicitudes disponibles</a>
            <a href="<?php echo e(route('candidato.postulaciones')); ?>" class="btn btn-secondary">Seguimiento</a>
        <?php endif; ?><?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if ENDBLOCK]><![endif]--><?php endif; ?>
    </div>

    <div class="content-split" style="margin-top:24px;">
        <div class="card fade-in">
            <div style="display:flex; justify-content:space-between; align-items:center; margin-bottom:16px;">
                <h3 style="font-weight:700; margin:0; font-size:1rem;">Progreso de tu perfil</h3>
                <span style="font-size:12px; color:#64748b;"><?php echo e($candidato->nombreCompleto() ?: 'Perfil sin nombre'); ?></span>
            </div>

            <div style="display:grid; gap:12px;">
                <div style="padding:14px 16px; border:1px solid var(--border); border-radius:10px; background:var(--surface-2);">
                    <div style="display:flex; justify-content:space-between; gap:12px; flex-wrap:wrap;">
                        <div>
                            <div style="font-weight:600;">Solicitud capturada</div>
                            <div style="font-size:12px; color:#64748b;">Datos personales, contacto y perfil laboral.</div>
                        </div>
                        <span class="badge badge-blue">Listo</span>
                    </div>
                </div>

                <div style="padding:14px 16px; border:1px solid var(--border); border-radius:10px; background:var(--surface-2);">
                    <div style="display:flex; justify-content:space-between; gap:12px; flex-wrap:wrap;">
                        <div>
                            <div style="font-weight:600;">Revisión administrativa</div>
                            <div style="font-size:12px; color:#64748b;">Admin valida tu perfil y te da acceso a solicitudes.</div>
                        </div>
                        <span class="badge <?php echo e($aprobado ? 'badge-green' : 'badge-yellow'); ?>"><?php echo e($aprobado ? 'Aprobado' : 'En revisión'); ?></span>
                    </div>
                </div>

                <div style="padding:14px 16px; border:1px solid var(--border); border-radius:10px; background:var(--surface-2);">
                    <div style="display:flex; justify-content:space-between; gap:12px; flex-wrap:wrap;">
                        <div>
                            <div style="font-weight:600;">Solicitudes y seguimiento</div>
                            <div style="font-size:12px; color:#64748b;">Solo se activa cuando tu perfil ya está aprobado.</div>
                        </div>
                        <span class="badge <?php echo e($aprobado ? 'badge-green' : 'badge-gray'); ?>"><?php echo e($aprobado ? 'Activo' : 'Bloqueado'); ?></span>
                    </div>
                </div>
            </div>
        </div>

        <div class="card fade-in">
            <div style="display:flex; justify-content:space-between; align-items:center; margin-bottom:16px;">
                <h3 style="font-weight:700; margin:0; font-size:1rem;">Datos rápidos</h3>
                <span style="font-size:12px; color:#64748b;">Actualizado <?php echo e($candidato->updated_at?->diffForHumans() ?? 'hace poco'); ?></span>
            </div>

            <div style="display:grid; gap:10px; font-size:13px;">
                <div>
                    <p style="color:var(--text-muted); margin:0 0 2px; font-size:11px; text-transform:uppercase; letter-spacing:.05em;">Correo</p>
                    <span style="font-weight:500;"><?php echo e(auth()->user()->email); ?></span>
                </div>
                <div>
                    <p style="color:var(--text-muted); margin:0 0 2px; font-size:11px; text-transform:uppercase; letter-spacing:.05em;">Estudios</p>
                    <span><?php echo e(\App\Models\Vacante::nivelEstudiosLabel($candidato->escolaridad)); ?></span>
                </div>
                <div>
                    <p style="color:var(--text-muted); margin:0 0 2px; font-size:11px; text-transform:uppercase; letter-spacing:.05em;">Experiencia</p>
                    <span><?php echo e((int) ($candidato->experiencia_anios ?? 0)); ?> año(s)</span>
                </div>
                <div>
                    <p style="color:var(--text-muted); margin:0 0 2px; font-size:11px; text-transform:uppercase; letter-spacing:.05em;">Aspiración</p>
                    <span><?php echo e($candidato->puesto_deseado ?: 'Sin definir'); ?></span>
                </div>
            </div>
        </div>
    </div>

    <div class="card fade-in" style="margin-top:24px;">
        <div style="display:flex; justify-content:space-between; align-items:center; flex-wrap:wrap; gap:8px; margin-bottom:16px;">
            <h3 style="font-weight:700; margin:0; font-size:1rem;">Últimas postulaciones</h3>
            <a href="<?php echo e(route('candidato.postulaciones')); ?>" style="font-size:12px; color:var(--accent); text-decoration:none;">Ver todo →</a>
        </div>

        <?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if BLOCK]><![endif]--><?php endif; ?><?php if($postulacionesRecientes->isEmpty()): ?>
            <div style="text-align:center; padding:36px 0; color:#64748b;">
                Aún no tienes postulaciones registradas.
            </div>
        <?php else: ?>
            <div class="desktop-only table-scroll">
                <table style="width:100%; border-collapse:collapse; font-size:13px;">
                    <thead>
                        <tr style="border-bottom:1px solid var(--border);">
                            <th style="text-align:left; padding:8px 10px; color:#475569; font-weight:500;">Solicitud</th>
                            <th style="text-align:left; padding:8px 10px; color:#475569; font-weight:500;">Empresa</th>
                            <th style="text-align:left; padding:8px 10px; color:#475569; font-weight:500;">Estado</th>
                            <th style="text-align:left; padding:8px 10px; color:#475569; font-weight:500;">Fecha</th>
                        </tr>
                    </thead>
                    <tbody>
                        <?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if BLOCK]><![endif]--><?php \Livewire\Features\SupportCompiledWireKeys\SupportCompiledWireKeys::openLoop(); ?><?php endif; ?><?php $__currentLoopData = $postulacionesRecientes; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $postulacion): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?><?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><?php \Livewire\Features\SupportCompiledWireKeys\SupportCompiledWireKeys::startLoopIteration(); ?><?php endif; ?>
                            <tr style="border-bottom:1px solid var(--border);">
                                <td style="padding:9px 10px;">
                                    <div style="font-weight:600;"><?php echo e($postulacion->vacante?->titulo ?? '—'); ?></div>
                                    <div style="font-size:11px; color:#64748b;"><?php echo e($postulacion->vacante?->requisitoResumen() ?? 'Sin requisitos'); ?></div>
                                </td>
                                <td style="padding:9px 10px; color:#64748b;">
                                    <?php echo e($postulacion->vacante?->empresa?->nombre_empresa ?? '—'); ?>

                                </td>
                                <td style="padding:9px 10px;">
                                    <span class="badge <?php echo e(\App\Models\Postulacion::estadoBadgeClass($postulacion->estado)); ?>">
                                        <?php echo e(\App\Models\Postulacion::estadoLabel($postulacion->estado)); ?>

                                    </span>
                                </td>
                                <td style="padding:9px 10px; color:#64748b; font-size:12px;">
                                    <?php echo e($postulacion->fecha_postulacion?->format('d/m/Y H:i') ?? '—'); ?>

                                </td>
                            </tr>
                        <?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><?php \Livewire\Features\SupportCompiledWireKeys\SupportCompiledWireKeys::endLoop(); ?><?php endif; ?><?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?><?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if ENDBLOCK]><![endif]--><?php \Livewire\Features\SupportCompiledWireKeys\SupportCompiledWireKeys::closeLoop(); ?><?php endif; ?>
                    </tbody>
                </table>
            </div>

            <div class="mobile-only">
                <div class="candidate-mobile-list">
                    <?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if BLOCK]><![endif]--><?php \Livewire\Features\SupportCompiledWireKeys\SupportCompiledWireKeys::openLoop(); ?><?php endif; ?><?php $__currentLoopData = $postulacionesRecientes; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $postulacion): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?><?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><?php \Livewire\Features\SupportCompiledWireKeys\SupportCompiledWireKeys::startLoopIteration(); ?><?php endif; ?>
                        <div class="candidate-mobile-card">
                            <h4 class="candidate-mobile-card-title"><?php echo e($postulacion->vacante?->titulo ?? '—'); ?></h4>
                            <p class="candidate-mobile-card-subtitle"><?php echo e($postulacion->vacante?->empresa?->nombre_empresa ?? '—'); ?></p>

                            <div class="candidate-mobile-meta">
                                <div>
                                    <p class="candidate-mobile-meta-label">Requisitos</p>
                                    <p class="candidate-mobile-meta-value"><?php echo e($postulacion->vacante?->requisitoResumen() ?? 'Sin requisitos'); ?></p>
                                </div>
                                <div>
                                    <p class="candidate-mobile-meta-label">Estado</p>
                                    <span class="badge <?php echo e(\App\Models\Postulacion::estadoBadgeClass($postulacion->estado)); ?>">
                                        <?php echo e(\App\Models\Postulacion::estadoLabel($postulacion->estado)); ?>

                                    </span>
                                </div>
                                <div>
                                    <p class="candidate-mobile-meta-label">Fecha</p>
                                    <p class="candidate-mobile-meta-value"><?php echo e($postulacion->fecha_postulacion?->format('d/m/Y H:i') ?? '—'); ?></p>
                                </div>
                            </div>
                        </div>
                    <?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><?php \Livewire\Features\SupportCompiledWireKeys\SupportCompiledWireKeys::endLoop(); ?><?php endif; ?><?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?><?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if ENDBLOCK]><![endif]--><?php \Livewire\Features\SupportCompiledWireKeys\SupportCompiledWireKeys::closeLoop(); ?><?php endif; ?>
                </div>
            </div>
        <?php endif; ?><?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if ENDBLOCK]><![endif]--><?php endif; ?>
    </div>

    <?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if BLOCK]><![endif]--><?php endif; ?><?php if($aprobado && $vacantesRecientes->isNotEmpty()): ?>
        <div class="card fade-in" style="margin-top:24px;">
            <div style="display:flex; justify-content:space-between; align-items:center; flex-wrap:wrap; gap:8px; margin-bottom:16px;">
                <h3 style="font-weight:700; margin:0; font-size:1rem;">Solicitudes activas recomendadas</h3>
                <span style="font-size:12px; color:#64748b;">Disponible para ti</span>
            </div>

            <div class="candidate-compact-list">
                <?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if BLOCK]><![endif]--><?php \Livewire\Features\SupportCompiledWireKeys\SupportCompiledWireKeys::openLoop(); ?><?php endif; ?><?php $__currentLoopData = $vacantesRecientes; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $vacante): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?><?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><?php \Livewire\Features\SupportCompiledWireKeys\SupportCompiledWireKeys::startLoopIteration(); ?><?php endif; ?>
                    <div class="candidate-compact-item">
                        <div class="candidate-inline-meta">
                            <div style="min-width:0;">
                                <div class="candidate-compact-item-title"><?php echo e($vacante->titulo); ?></div>
                                <div class="candidate-compact-item-subtitle" style="white-space:nowrap; overflow:hidden; text-overflow:ellipsis;">
                                    <?php echo e($vacante->empresa?->nombre_empresa ?? 'Empresa'); ?>

                                </div>
                            </div>
                            <div style="flex-shrink:0;">
                                <div class="candidate-compact-item-trailing"><?php echo e(\App\Models\CatalogoServicio::nivelJerarquicoLabel($vacante->nivel_jerarquico)); ?></div>
                                <div style="margin-top:4px;">
                                    <button type="button" onclick="rhModal('<?php echo e(route('candidato.vacantes.modal', $vacante)); ?>')" class="btn btn-secondary" style="padding:4px 10px; font-size:12px;">Ver detalle</button>
                                </div>
                            </div>
                        </div>
                    </div>
                <?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><?php \Livewire\Features\SupportCompiledWireKeys\SupportCompiledWireKeys::endLoop(); ?><?php endif; ?><?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?><?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if ENDBLOCK]><![endif]--><?php \Livewire\Features\SupportCompiledWireKeys\SupportCompiledWireKeys::closeLoop(); ?><?php endif; ?>
            </div>
        </div>
    <?php endif; ?><?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if ENDBLOCK]><![endif]--><?php endif; ?>
 <?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginal9ac128a9029c0e4701924bd2d73d7f54)): ?>
<?php $attributes = $__attributesOriginal9ac128a9029c0e4701924bd2d73d7f54; ?>
<?php unset($__attributesOriginal9ac128a9029c0e4701924bd2d73d7f54); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal9ac128a9029c0e4701924bd2d73d7f54)): ?>
<?php $component = $__componentOriginal9ac128a9029c0e4701924bd2d73d7f54; ?>
<?php unset($__componentOriginal9ac128a9029c0e4701924bd2d73d7f54); ?>
<?php endif; ?>
<?php /**PATH C:\Dev\Web\SistemaRH_Laravel\resources\views/candidato/dashboard.blade.php ENDPATH**/ ?>