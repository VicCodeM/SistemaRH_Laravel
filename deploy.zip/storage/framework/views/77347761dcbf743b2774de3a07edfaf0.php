<!DOCTYPE html>
<html lang="<?php echo e(app()->getLocale() === 'es' ? 'es' : str_replace('_', '-', app()->getLocale())); ?>">
    <head>
        <meta charset="utf-8">
        <meta name="viewport" content="width=device-width, initial-scale=1">
        <meta name="csrf-token" content="<?php echo e(csrf_token()); ?>">
        <title><?php echo $__env->yieldContent('title', ($sitio['sitio_nombre'] ?? config('app.name', 'SistemaRH')) . (!empty($sitio['sitio_subtitulo']) ? ' — ' . $sitio['sitio_subtitulo'] : '')); ?></title>
        <meta name="description" content="<?php echo $__env->yieldContent('meta_description', $sitio['sitio_descripcion'] ?? ''); ?>">
        <?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if BLOCK]><![endif]--><?php endif; ?><?php if(!empty($sitio['sitio_favicon'])): ?>
            <?php $favExt = pathinfo($sitio['sitio_favicon'], PATHINFO_EXTENSION); ?>
            <link rel="icon" type="<?php echo e($favExt === 'svg' ? 'image/svg+xml' : ($favExt === 'ico' ? 'image/x-icon' : 'image/' . $favExt)); ?>" href="<?php echo e(asset('storage/' . $sitio['sitio_favicon'])); ?>">
        <?php else: ?>
            <link rel="icon" type="image/x-icon" href="<?php echo e(asset('favicon.ico')); ?>">
        <?php endif; ?><?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if ENDBLOCK]><![endif]--><?php endif; ?>
        <?php echo app('Illuminate\Foundation\Vite')(['resources/css/app.css', 'resources/js/app.js']); ?>
    </head>
    <body class="landing-page">
        <?php echo $__env->yieldContent('content'); ?>
    </body>
</html>
<?php /**PATH C:\Dev\Web\SistemaRH_Laravel\resources\views/layouts/landing.blade.php ENDPATH**/ ?>