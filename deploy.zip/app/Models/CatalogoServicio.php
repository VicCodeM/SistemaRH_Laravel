<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Model;
use Illuminate\Database\Eloquent\Relations\HasMany;
use Illuminate\Support\Str;

class CatalogoServicio extends Model
{
    protected $table = 'catalogo_servicios';

    protected $fillable = [
        'nombre',
        'descripcion',
        'tipo',
        'nivel_jerarquico',
        'para_quien',
        'activo',
        'orden',
    ];

    protected $casts = [
        'activo' => 'boolean',
    ];

    public function asignaciones(): HasMany
    {
        return $this->hasMany(ServicioAsignado::class, 'servicio_id');
    }

    public function tieneSolicitudesActivas(): bool
    {
        return $this->asignaciones()
            ->whereIn('estado', ['activo', 'en_proceso'])
            ->exists();
    }

    public function tieneSolicitudesRelacionadas(): bool
    {
        return $this->asignaciones()->exists();
    }

    public function puedeDesactivarse(): bool
    {
        return ! $this->tieneSolicitudesActivas();
    }

    public static function nivelesJerarquicos(): array
    {
        return CatalogoOpcion::opciones('niveles_jerarquicos', [
            'todos' => 'Todos los niveles',
            'operativo' => 'Operativo',
            'supervision' => 'Supervisión',
            'gerencia' => 'Gerencia',
            'direccion' => 'Dirección',
        ]);
    }

    public static function nivelesJerarquicosCompatibles(): array
    {
        $niveles = self::nivelesJerarquicos();

        $fallback = [
            'todos' => 'Todos los niveles',
            'operativo' => 'Operativo',
            'analista' => 'Analista',
            'supervision' => 'Supervisión',
            'gerencia' => 'Gerencia',
            'direccion' => 'Dirección',
        ];

        $aliases = [
            'auxiliar' => 'Operativo',
            'tecnico' => 'Operativo',
            'administrativo' => 'Operativo',
            'supervisor' => 'Supervisión',
            'coordinador' => 'Supervisión',
            'gerente' => 'Gerencia',
            'director' => 'Dirección',
            'directivo' => 'Dirección',
        ];

        foreach (array_merge($fallback, $aliases) as $clave => $label) {
            $niveles[$clave] ??= $label;
        }

        return $niveles;
    }

    public static function nivelesJerarquicosFormulario(bool $incluirTodos = false): array
    {
        $niveles = self::nivelesJerarquicos();

        if ($incluirTodos) {
            return $niveles;
        }

        return array_filter(
            $niveles,
            fn ($label, $key) => $key !== 'todos',
            ARRAY_FILTER_USE_BOTH
        );
    }

    public static function normalizarNivelJerarquico(?string $nivel): ?string
    {
        if ($nivel === null || $nivel === '') {
            return $nivel;
        }

        $nivel = Str::of($nivel)->ascii()->lower()->trim()->value();

        return match ($nivel) {
            'todos' => 'todos',
            'operativo', 'auxiliar', 'tecnico', 'administrativo' => 'operativo',
            'supervision', 'supervisor', 'coordinador' => 'supervision',
            'gerencia', 'gerente' => 'gerencia',
            'direccion', 'director', 'directivo' => 'direccion',
            default => $nivel,
        };
    }

    public static function nivelJerarquicoLabel(?string $nivel): string
    {
        $nivelNormalizado = self::normalizarNivelJerarquico($nivel);

        return CatalogoOpcion::label(
            'niveles_jerarquicos',
            $nivelNormalizado,
            self::nivelesJerarquicosCompatibles()[$nivelNormalizado] ?? ucfirst(str_replace('_', ' ', (string) $nivelNormalizado))
        );
    }

    public static function tipos(): array
    {
        return CatalogoOpcion::opciones('tipos_servicio', [
            'reclutamiento' => 'Reclutamiento',
            'capacitacion' => 'Capacitación',
            'coaching' => 'Coaching',
            'evaluacion' => 'Evaluación / Assessment',
            'outplacement' => 'Outplacement',
            'nomina' => 'Nómina y IMSS',
            'consultoria' => 'Consultoría RH',
            'otro' => 'Otro',
        ]);
    }
}
