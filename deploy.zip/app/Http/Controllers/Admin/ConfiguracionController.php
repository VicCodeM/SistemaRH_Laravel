<?php

namespace App\Http\Controllers\Admin;

use App\Http\Controllers\Controller;
use App\Http\Requests\GuardarSitioRequest;
use App\Models\Bitacora;
use App\Models\ConfiguracionSistema;
use App\Models\User;
use App\Services\AccesoMunicipioService;
use App\Services\BitacoraService;
use App\Services\SitioService;
use Illuminate\Http\RedirectResponse;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\Hash;
use Illuminate\Support\Facades\Password;
use Illuminate\Validation\Rule;
use Illuminate\Validation\Rules\Password as PasswordRule;

class ConfiguracionController extends Controller
{
    public function index(Request $request, SitioService $sitioService, AccesoMunicipioService $accesoMunicipio)
    {
        $tabActivo = $request->string('tab')->toString() ?: 'usuarios';

        $query = User::query();

        if ($request->filled('rol')) {
            $query->where('rol', $request->rol);
        }

        if ($request->filled('estado')) {
            $query->where('estado', $request->estado);
        }

        if ($request->filled('buscar')) {
            $buscar = $request->input('buscar');
            $query->where(function ($q) use ($buscar) {
                $q->where('name', 'like', "%{$buscar}%")
                    ->orWhere('email', 'like', "%{$buscar}%");
            });
        }

        $usuarios = $query
            ->orderByRaw("CASE rol WHEN 'admin' THEN 1 WHEN 'interno' THEN 2 WHEN 'empresa' THEN 3 WHEN 'candidato' THEN 4 ELSE 5 END")
            ->orderBy('name')
            ->paginate(12)
            ->withQueryString();

        $bitacoras = Bitacora::with('usuario')
            ->latest()
            ->limit(20)
            ->get();

        $parametros = [
            'candidato_requiere_aprobacion' => ConfiguracionSistema::boolean('candidato_requiere_aprobacion', false),
            'acceso_municipios_todos' => $accesoMunicipio->permiteTodos(),
            'acceso_municipios_permitidos_texto' => $accesoMunicipio->municipiosPermitidosTexto(),
        ];

        $stats = [
            'total' => User::count(),
            'activos' => User::where('estado', 'activo')->count(),
            'bloqueados' => User::where('estado', 'bloqueado')->count(),
            'internos' => User::where('rol', 'interno')->count(),
            'empresas' => User::where('rol', 'empresa')->count(),
            'candidatos' => User::where('rol', 'candidato')->count(),
        ];

        $sitio = $sitioService->valores();

        return view('admin.configuracion.index', compact('tabActivo', 'usuarios', 'bitacoras', 'stats', 'parametros', 'sitio'));
    }

    public function guardarSitio(GuardarSitioRequest $request, SitioService $sitio, BitacoraService $bitacora): RedirectResponse
    {
        $sitio->guardarTextos($request->validated());

        if ($request->boolean('quitar_logo')) {
            $sitio->eliminarLogo();
        } elseif ($request->hasFile('logo')) {
            $sitio->guardarLogo($request->file('logo'));
        }

        if ($request->boolean('quitar_favicon')) {
            $sitio->eliminarFavicon();
        } elseif ($request->hasFile('favicon')) {
            $sitio->guardarFavicon($request->file('favicon'));
        }

        $bitacora->registrar(
            'configuracion',
            'actualizar',
            'Se actualizó la configuración del sitio (SEO, landing y páginas legales).'
        );

        return redirect()
            ->route('admin.configuracion', ['tab' => 'sitio'])
            ->with('success', 'Configuración del sitio actualizada.');
    }

    public function guardarParametros(Request $request, BitacoraService $bitacora, AccesoMunicipioService $accesoMunicipio): RedirectResponse
    {
        $request->validate([
            'candidato_requiere_aprobacion' => ['nullable', 'boolean'],
            'acceso_municipios_todos' => ['nullable', 'boolean'],
            'acceso_municipios_permitidos' => ['nullable', 'string', 'max:5000'],
        ]);

        $requiereAprobacion = $request->boolean('candidato_requiere_aprobacion');
        $permitirTodosMunicipios = $request->boolean('acceso_municipios_todos', true);
        $municipiosPermitidos = preg_split('/\R/u', (string) $request->input('acceso_municipios_permitidos', '')) ?: [];
        $municipiosPermitidos = $accesoMunicipio->normalizarLista($municipiosPermitidos);

        ConfiguracionSistema::guardar(
            'candidato_requiere_aprobacion',
            $requiereAprobacion,
            [
                'grupo' => 'accesos',
                'tipo' => 'boolean',
                'descripcion' => 'Si se activa, cada candidato debe recibir aprobacion antes de completar su solicitud.',
                'orden' => 10,
            ]
        );

        $accesoMunicipio->guardarConfiguracion($permitirTodosMunicipios, $municipiosPermitidos);

        $bitacora->registrar(
            'configuracion',
            'actualizar',
            'Se actualizaron los parametros de aprobacion previa y acceso por municipio.'
        );

        return back()->with('success', 'Parámetros actualizados correctamente.');
    }

    public function usuarioModal(User $usuario)
    {
        return view('admin.configuracion.usuario-modal', [
            'usuario' => $usuario->load(['candidato', 'empresa']),
            'esNuevo' => false,
        ]);
    }

    public function nuevoUsuarioModal()
    {
        return view('admin.configuracion.usuario-modal', [
            'usuario' => new User([
                'rol' => 'interno',
                'estado' => 'activo',
            ]),
            'esNuevo' => true,
        ]);
    }

    public function accionUsuarioModal(User $usuario, string $accion)
    {
        $config = match ($accion) {
            'bloquear' => [
                'titulo' => 'Bloquear usuario',
                'descripcion' => 'El usuario conservara su cuenta, pero ya no podra entrar al sistema.',
                'mensaje' => 'Confirma si deseas bloquear este acceso.',
                'ruta' => route('admin.configuracion.usuarios.estado', $usuario),
                'metodo' => 'PATCH',
                'boton' => 'Bloquear usuario',
                'clase' => 'btn-danger',
                'permitido' => auth()->id() !== $usuario->id,
                'aviso' => auth()->id() === $usuario->id ? 'No puedes bloquear tu propio acceso.' : null,
            ],
            'desbloquear' => [
                'titulo' => 'Desbloquear usuario',
                'descripcion' => 'El usuario recuperara acceso al sistema.',
                'mensaje' => 'Confirma si deseas desbloquear esta cuenta.',
                'ruta' => route('admin.configuracion.usuarios.estado', $usuario),
                'metodo' => 'PATCH',
                'boton' => 'Desbloquear usuario',
                'clase' => 'btn-success',
            ],
            'recuperar' => [
                'titulo' => 'Reenviar acceso',
                'descripcion' => 'Se generara un nuevo enlace para restablecer la contrasena.',
                'mensaje' => 'Confirma si deseas generar un nuevo enlace de acceso para este usuario.',
                'ruta' => route('admin.configuracion.usuarios.recuperar', $usuario),
                'metodo' => 'POST',
                'boton' => 'Generar enlace',
                'clase' => 'btn-primary',
            ],
            default => null,
        };

        abort_if($config === null, 404);

        $registro = [
            'titulo' => $usuario->name,
            'detalle' => $usuario->email . ' · Rol: ' . User::rolLabel($usuario->rol),
        ];

        return view('admin.partials.modal-accion', compact('config', 'registro'));
    }

    public function guardarUsuario(Request $request, BitacoraService $bitacora): RedirectResponse
    {
        $requiereVerificacion = User::requireEmailVerification();
        $rolesValidos = implode(',', array_keys(User::roles()));
        $estadosValidos = implode(',', array_keys(User::estados()));

        $data = $request->validate([
            'name' => ['required', 'string', 'max:255'],
            'email' => ['required', 'email', 'lowercase', 'unique:users,email'],
            'rol' => ['required', "in:{$rolesValidos}"],
            'estado' => ['required', "in:{$estadosValidos}"],
            'password' => ['required', 'confirmed', PasswordRule::defaults()],
        ]);

        $user = User::create([
            'name' => trim($data['name']),
            'email' => strtolower(trim($data['email'])),
            'rol' => $data['rol'],
            'estado' => $data['estado'],
            'password' => Hash::make($data['password']),
            'email_verified_at' => User::emailVerifiedAtInitial(),
        ]);

        if ($requiereVerificacion) {
            try {
                $user->sendEmailVerificationNotification();
            } catch (\Throwable $e) {
                report($e);
            }
        }

        $bitacora->registrar(
            'usuarios',
            'crear',
            "Se creó el usuario {$user->name} ({$user->email}) con rol {$user->rol}.",
        );

        return redirect()
            ->route('admin.configuracion', ['tab' => 'usuarios'])
            ->with('success', $requiereVerificacion
                ? 'Usuario creado correctamente. Se envio un correo de verificacion.'
                : 'Usuario creado correctamente.');
    }

    public function actualizarUsuario(Request $request, User $usuario, BitacoraService $bitacora): RedirectResponse
    {
        $rolesValidos = implode(',', array_keys(User::roles()));
        $estadosValidos = implode(',', array_keys(User::estados()));

        $data = $request->validate([
            'name' => ['required', 'string', 'max:255'],
            'email' => ['required', 'email', 'lowercase', Rule::unique('users', 'email')->ignore($usuario->id)],
            'rol' => ['required', "in:{$rolesValidos}"],
            'estado' => ['required', "in:{$estadosValidos}"],
            'password' => ['nullable', 'confirmed', PasswordRule::defaults()],
        ]);

        $cambios = [];
        foreach (['name', 'email', 'rol', 'estado'] as $campo) {
            $nuevoValor = $campo === 'email'
                ? strtolower(trim($data[$campo]))
                : trim((string) $data[$campo]);

            if ($usuario->{$campo} !== $nuevoValor) {
                $cambios[] = $campo;
            }
        }

        $usuario->fill([
            'name' => trim($data['name']),
            'email' => strtolower(trim($data['email'])),
            'rol' => $data['rol'],
            'estado' => $data['estado'],
        ]);

        if (! empty($data['password'])) {
            $usuario->password = Hash::make($data['password']);
            $cambios[] = 'password';
        }

        if ($usuario->estado === 'activo' && ! $usuario->email_verified_at && ! User::requireEmailVerification()) {
            $usuario->email_verified_at = now();
        }

        $usuario->save();

        $bitacora->registrar(
            'usuarios',
            'actualizar',
            'Se actualizaron los campos: ' . implode(', ', array_unique($cambios ?: ['sin cambios visibles'])) . ". Usuario: {$usuario->email}."
        );

        return redirect()
            ->route('admin.configuracion', ['tab' => 'usuarios'])
            ->with('success', 'Usuario actualizado correctamente.');
    }

    public function cambiarEstadoUsuario(User $usuario, BitacoraService $bitacora): RedirectResponse
    {
        if (auth()->id() === $usuario->id) {
            return back()->with('error', 'No puedes bloquear tu propio acceso.');
        }

        $nuevoEstado = $usuario->estado === 'bloqueado' ? 'activo' : 'bloqueado';

        $usuario->update(['estado' => $nuevoEstado]);

        $bitacora->registrar(
            'usuarios',
            'cambio_estado',
            "El usuario {$usuario->email} cambió a estado {$nuevoEstado}."
        );

        return redirect()
            ->route('admin.configuracion', ['tab' => 'usuarios'])
            ->with('success', $nuevoEstado === 'activo' ? 'Usuario desbloqueado.' : 'Usuario bloqueado.');
    }

    public function reenviarAcceso(User $usuario, BitacoraService $bitacora): RedirectResponse
    {
        $status = Password::sendResetLink(['email' => $usuario->email]);

        if ($status !== Password::RESET_LINK_SENT) {
            return back()->with('error', 'No fue posible generar el enlace de acceso.');
        }

        $bitacora->registrar(
            'usuarios',
            'recuperacion',
            "Se generó un enlace de restablecimiento para {$usuario->email}."
        );

        return redirect()
            ->route('admin.configuracion', ['tab' => 'usuarios'])
            ->with('success', 'Se generó el enlace de recuperación de acceso.');
    }
}



